"""Builds backend/data/cities.tsv, the city list used to correct misspelt place names.

Source: GeoNames (https://www.geonames.org), licensed CC BY 4.0. Download, then run:

    https://download.geonames.org/export/dump/cities15000.zip      (unzip -> cities15000.txt)
    https://download.geonames.org/export/dump/admin1CodesASCII.txt

    python scripts/build_cities.py cities15000.txt admin1CodesASCII.txt

Output columns (tab separated):
    name, country_code, state_name, lat, lon, population, other_spellings (pipe separated, ASCII only)
"""
import sys
from pathlib import Path

MAX_ALTERNATES = 12


def is_latin(text: str) -> bool:
    return text.isascii() and any(c.isalpha() for c in text)


def main(cities_path: str, admin1_path: str) -> None:
    states = {}
    for line in Path(admin1_path).read_text(encoding="utf-8").splitlines():
        code, name, *_ = line.split("\t")
        states[code] = name  # e.g. "IN.40" -> "Telangana"

    out = Path(__file__).resolve().parent.parent / "data" / "cities.tsv"
    out.parent.mkdir(exist_ok=True)
    rows = 0
    with out.open("w", encoding="utf-8", newline="\n") as fh:
        for line in Path(cities_path).read_text(encoding="utf-8").splitlines():
            f = line.split("\t")
            name, ascii_name, alternates = f[1], f[2], f[3]
            lat, lon, country, admin1, population = f[4], f[5], f[8], f[10], f[14]
            spellings = []
            for s in [name, ascii_name] + alternates.split(","):
                s = s.strip()
                if len(s) >= 3 and is_latin(s) and s.lower() not in (x.lower() for x in spellings):
                    spellings.append(s)
            spellings = spellings[:MAX_ALTERNATES]
            state = states.get(f"{country}.{admin1}", "")
            display = ascii_name if ascii_name else name
            fh.write("\t".join([display, country, state, lat, lon, population or "0", "|".join(spellings)]) + "\n")
            rows += 1
    print(f"wrote {rows} cities to {out} ({out.stat().st_size / 1e6:.1f} MB)")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
