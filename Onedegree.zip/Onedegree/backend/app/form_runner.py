"""The "Form Runner": drives one intake form through a chat session (see FormSession below).

A background browser (headless by default; a real, visible window only for the "handoff" case - a
captcha only a person can tick) is filled in with what the chat already collected, the chat asks for
anything a first pass could not fill from what the user already gave, and the chat itself presses
Submit once the person says to - watching for the site's own confirmation (or best-effort signs of one),
asking for a one-time code or a captcha click along the way when the site needs one.

Playwright's sync API must stay on the one thread that started it, so the whole lifecycle - launch,
fill, submit, watch for the outcome - runs in a single background thread per session, owning its own
browser; the HTTP requests that drive it talk to that thread through a queue (see FormSession.call).
"""
import base64
import logging
import os
import threading

from playwright.sync_api import sync_playwright

from . import form_crawler, web_lookup

log = logging.getLogger("onedegree.form_runner")


def _fill_value(frame, field: dict, value: str) -> bool:
    """Fills one field inside `frame` (the page itself, or the iframe the form lives in)."""
    selector = form_crawler.field_selector(field)
    try:
        if field["type"] == "select":
            try:
                try:
                    frame.select_option(selector, label=value, timeout=3000)
                except Exception:
                    frame.select_option(selector, value=value, timeout=3000)
            except Exception:
                # a hidden <select> behind a dropdown widget (select2, nice-select...): choose the option directly and
                # tell the page (and jQuery, which such widgets listen to) that it changed
                chosen = frame.eval_on_selector(selector, """(s, want) => {
                    const w = String(want).trim().toLowerCase();
                    const o = Array.from(s.options).find(x => x.text.trim().toLowerCase() === w || x.value.toLowerCase() === w);
                    if (!o) return false;
                    s.value = o.value;
                    s.dispatchEvent(new Event('input', {bubbles: true})); s.dispatchEvent(new Event('change', {bubbles: true}));
                    if (window.jQuery) { try { window.jQuery(s).trigger('change'); } catch (e) {} }
                    return true;
                }""", value)
                if not chosen:
                    return False
        elif field["type"] == "checkbox":
            if str(value).strip().lower() in ("yes", "true", "on", "1", "agree"):
                try:
                    frame.check(selector, timeout=3000)   # only ever ticked when the person said yes in the chat
                except Exception:   # a pop-up covering the box: set it directly
                    frame.eval_on_selector(selector, "e => { e.checked = true; e.dispatchEvent(new Event('input', {bubbles: true}));"
                                                     " e.dispatchEvent(new Event('change', {bubbles: true})); }")
                return True
            return False
        elif field["type"] == "radio":
            choices = field.get("choices") or []
            want = str(value).strip().lower()
            pick = next((c for c in choices if c["label"].strip().lower() == want), None) or \
                next((c for c in choices if want in c["label"].lower() or c["label"].lower() in want), None)
            if pick is None:
                return False
            target = f'[data-odf="{pick["uid"]}"]'
            try:
                frame.check(target, timeout=3000)
            except Exception:   # covered by a pop-up, or a styled radio whose real input is hidden: set it directly
                frame.eval_on_selector(target, "e => { e.checked = true; e.click && e.click();"
                                               " e.dispatchEvent(new Event('change', {bubbles: true})); }")
        elif field["type"] == "file":
            return False   # a file cannot be chosen from a chat
        else:
            try:
                frame.fill(selector, value, timeout=3000)
            except Exception:
                # a read-only box that a date picker fills (or one covered by a pop-up): set its value directly
                frame.eval_on_selector(selector, """(e, v) => {
                    e.removeAttribute('readonly'); e.value = v;
                    ['input', 'change', 'blur'].forEach(n => e.dispatchEvent(new Event(n, {bubbles: true})));
                }""", value)
        return True
    except Exception as exc:
        log.warning("[form-run] could not fill field %r: %s", field.get("name"), exc)
        return False


# ---------------------------------------------------------------------------
# An interactive session: fill, submit when the person says so, read the outcome, fix a rejected field, submit
# again. One background thread owns the Playwright browser for the whole session (its sync API must stay on one
# thread); the HTTP requests talk to it through a queue.
# ---------------------------------------------------------------------------
import queue
import re
import time
import uuid

SESSION_IDLE_S = 20 * 60
# The submit-from-chat sessions run WITHOUT a visible window: everything happens in the chat. (Set
# FORM_RUNNER_HEADED=1 to watch the browser while developing.)
_SESSION_HEADLESS = os.getenv("FORM_RUNNER_HEADED") != "1"
SUCCESS_RE = re.compile(r"thank you|thanks for|success(ful|fully)?\b|submitted|we have received|has been received|"
                        r"we will (get back|contact|call|reach)|will get back to you|confirmation|"
                        r"appointment (is |has been )?(booked|confirmed|requested|scheduled)|request (has been )?(sent|received)|"
                        r"registered successfully|application (has been )?(received|submitted)|message (has been |was )?sent|"
                        r"sent successfully|submitted successfully|we.ll be in touch|will be in touch|got your message", re.I)
BY_HAND_RE = re.compile(r"captcha|otp|verification code|i am not a robot", re.I)

# still working: the Submit button or the box that will hold the answer says so with a "loading"-ish class of its
# own (a plugin's own class, e.g. "forminator-loading", never matched by a plain ".loading" selector, since that
# only matches an element whose WHOLE class is "loading" - many unrelated widgets (lazy-loaded images...) have
# "loading" somewhere in a class too, so this only looks at the button and the response box, never the whole page).
# One expression, shared by the field/error reader and by the screenshot picker, so a picture is never taken, or
# judged final, while this is still true.
_BUSY_EXPR = """(() => {
  const busyWord = /(^|[-\\s])(loading|submitting|sending|processing)([-\\s]|\\.\\.\\.|$)/i;
  const btn = document.querySelector('[data-odsubmit="1"]');
  // an <input type=submit>'s own text is its VALUE, not its innerText (inputs have no innerText at all)
  const btnText = btn ? (btn.value || btn.innerText || '') : '';
  const boxes = Array.from(document.querySelectorAll('[role=alert], .alert-danger, .alert-error, .error-summary, .form-error'));
  return (!!btn && (busyWord.test(btn.className || '') || busyWord.test(btnText) || /please wait/i.test(btnText)))
    || boxes.some(b => busyWord.test(b.className || '') || busyWord.test(b.innerText || ''));
})()"""
_BUSY_JS = "() => " + _BUSY_EXPR

_ANALYZE_JS = """(sels) => {
  const vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const found = [];
  sels.forEach(s => {
    const el = document.querySelector(s.sel); if (!el) return;
    // a field the page has since hidden again (an OTP box the site folds away once it is done with it) cannot be
    // rejecting anything any more - its own emptiness is never reported as an error once nobody can even see it
    if (!vis(el)) return;
    let msg = '';
    if (el.validity && !el.validity.valid) msg = el.validationMessage || 'This value is not valid';
    const flagged = el.getAttribute('aria-invalid') === 'true'
      || /(^|\\s)(is-invalid|has-error|error|invalid)(\\s|$)/.test(el.className || '')
      || !!el.closest('.has-error, .is-invalid, .field-error');
    if (!msg) {
      // the field's own wrapper only (never a big container that holds other fields' messages too)
      let box = el.closest('.form-group, .field, .form-field, .input-group, .mb-3, li, p') || el.parentElement;
      if (box && box.querySelectorAll('input,select,textarea').length > 3) box = el.parentElement;
      const cand = box ? box.querySelector('.invalid-feedback, .error-message, .help-block, .text-danger, small.error, '
        + '[class*="error"], [role="alert"]') : null;
      if (cand && cand.innerText && cand.innerText.trim() && vis(cand)) msg = cand.innerText.trim();
      else if (flagged) msg = 'This value was not accepted';
    }
    if (msg) found.push({name: s.name, message: msg.replace(/\\s+/g, ' ').slice(0, 200)});
  });
  // also the popup/modal libraries a lot of sites use for their OWN "please pick a branch" style complaints
  // (SweetAlert2 and its predecessor among them): these are never marked role=alert, just their own class names
  const responseBoxes = Array.from(document.querySelectorAll('[role=alert], .alert-danger, .alert-error, .error-summary, '
    + '.form-error, .swal2-popup, .swal2-html-container, .sweet-alert, dialog[open]'));
  const alerts = responseBoxes.filter(vis).map(a => a.innerText.replace(/\\s+/g, ' ').trim()).filter(Boolean).slice(0, 3);
  const busy = __OD_BUSY_EXPR__;
  return {
    fields: found, alerts: alerts, busy: busy,
    body: (document.body ? document.body.innerText : '').slice(0, 6000),
    captcha: !!document.querySelector('iframe[src*="recaptcha"], iframe[src*="hcaptcha"], .g-recaptcha, .h-captcha'),
    visibleFields: sels.filter(s => { const el = document.querySelector(s.sel); return el && vis(el); }).length
  };
}""".replace("__OD_BUSY_EXPR__", _BUSY_EXPR)


class FormSession:
    """A visible browser window on this machine, kept open while the person works through the chat."""

    def __init__(self, url: str, owner: str, headed: bool = False):
        self.url, self.owner, self.headed = url, owner, headed   # headed: a real window the person works in themselves
        self.meta: list[dict] = []   # what the chat knows about each question: name, label, kind
        self._shots: list[dict] = []    # pictures taken the moment new text appeared after Submit
        self._seen_blocks: set[str] = set()
        self._before_blocks: set[str] = set()
        self._already_thanks = False
        self._was_busy = False
        self.writes: list[float] = []   # when the page sent data to the site (a form being submitted)
        self.moves: list[float] = []    # when the page navigated
        self.id = uuid.uuid4().hex
        self.last_used = time.time()
        self.alive = True
        self.q: queue.Queue = queue.Queue()
        self.page = self.frame = None
        self.fields: list[dict] = []
        threading.Thread(target=self._loop, daemon=True).start()

    # ----- called from the HTTP request threads
    def call(self, cmd: str, payload: dict | None = None, timeout: float = 90) -> dict:
        if not self.alive:
            return {"status": "error", "message": "The browser window was closed."}
        self.last_used = time.time()
        box = {"done": threading.Event()}
        self.q.put((cmd, payload or {}, box))
        if not box["done"].wait(timeout):
            return {"status": "error", "message": "The browser took too long to answer."}
        return box.get("result") or {"status": "error", "message": "No answer from the browser window."}

    # ----- the thread that owns the browser
    def _loop(self) -> None:
        try:
            with sync_playwright() as pw:
                browser = pw.chromium.launch(headless=_SESSION_HEADLESS and not self.headed)
                self.page = browser.new_page(viewport={"width": 1280, "height": 900})
                self.page.on("request", self._on_request)
                self.page.on("framenavigated", lambda _f: self.moves.append(time.time()))
                while True:
                    try:
                        cmd, payload, box = self.q.get(timeout=SESSION_IDLE_S)
                    except queue.Empty:
                        break
                    try:
                        box["result"] = self._handle(cmd, payload)
                    except Exception as exc:   # the window was closed by the person, or the page broke
                        log.warning("[form-session] %s failed: %s", cmd, exc)
                        box["result"] = {"status": "error", "message": "The browser window stopped responding."}
                    box["done"].set()
                    if cmd == "close":
                        break
                try:
                    browser.close()
                except Exception:
                    pass
        except Exception as exc:
            log.warning("[form-session] could not run the browser: %s", exc)
        finally:
            self.alive = False
            while not self.q.empty():   # anyone still waiting gets an answer instead of a timeout
                try:
                    _cmd, _payload, box = self.q.get_nowait()
                    box["result"] = {"status": "error", "message": "The browser window was closed."}
                    box["done"].set()
                except queue.Empty:
                    break

    def _handle(self, cmd: str, payload: dict) -> dict:
        if cmd == "open":
            return self._open()
        if cmd == "fill":
            return self._fill(payload.get("values") or {})
        if cmd == "options":
            return self._options(payload.get("name") or "")
        if cmd == "preflight":
            return self._preflight(payload.get("values") or {})
        if cmd == "captcha":
            return self._captcha(payload.get("click"))
        if cmd == "attach":
            return self._attach(payload.get("name") or "", payload.get("filename") or "file", payload.get("data") or b"")
        if cmd == "block" and os.getenv("FORM_RUNNER_DEBUG") == "1":   # development only: stop anything reaching the site
            self.page.route("**/*", lambda route: route.abort() if ("crm.php" in route.request.url and route.request.method == "POST")
                            else route.continue_())
            return {"status": "ok"}
        if cmd == "debug" and os.getenv("FORM_RUNNER_DEBUG") == "1":   # development only: why can't Submit be pressed?
            self._refresh()
            button = self._find_submit()
            if button is None:
                return {"button": None}
            out = {"fields_live": [(f["name"], f.get("uid"), f.get("gid"), self._current(f)) for f in self.fields],
                   "forms_on_page": self.frame.evaluate("() => Array.from(document.forms).map(f => (f.getAttribute('action') || '') + ' ' + f.method + ' ' + f.querySelectorAll('input,select,textarea').length + ' inputs')"),
                   "count": button.count(), "visible": button.is_visible(), "enabled": button.is_enabled(),
                   "html": button.evaluate("e => e.outerHTML.slice(0, 200)"), "box": button.bounding_box()}
            try:
                button.click(trial=True, timeout=3000)
                out["trial"] = "ok"
            except Exception as exc:
                out["trial"] = "covered"
                out["hidden_by_uncover"] = button.evaluate(self._UNCOVER_JS, timeout=5000)
                try:
                    button.click(trial=True, timeout=3000)   # a trial: checks it could be clicked, without clicking
                    out["trial_after_uncover"] = "ok"
                except Exception as exc2:
                    out["trial_after_uncover"] = str(exc2)[:300]
            out["at_point"] = button.evaluate("""e => { const r = e.getBoundingClientRect();
                const t = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
                return t ? (t.tagName + '.' + t.className + '#' + t.id).slice(0, 120) : null; }""")
            out["form_action"] = button.evaluate("e => e.form ? (e.form.getAttribute('action') || '') + ' ' + e.form.method : 'no form'")
            return out
        if cmd == "submit":
            if payload.get("values"):
                self._fill(payload["values"])   # corrected values first
            return self._submit()
        if cmd == "close":
            return {"status": "ok"}
        return {"status": "error", "message": "Unknown command."}

    def _shot(self) -> str:
        try:
            return base64.b64encode(self.page.screenshot()).decode()
        except Exception:
            return ""

    def _open(self) -> dict:
        try:
            web_lookup._check_public(self.url)
            self.page.goto(self.url, wait_until="load", timeout=25000)
        except Exception as exc:
            return {"status": "error", "message": f"Could not open the page: {exc}"}
        self.frame, self.fields = form_crawler.find_form_in_page(self.page, self.meta)
        if self.frame is None:
            return {"status": "error", "message": "I couldn't find the form on that page."}
        return {"status": "ok"}

    @staticmethod
    def _slug(text: str) -> str:
        return re.sub(r"[^a-z0-9]+", "", re.sub(r"[*:?]+", "", (text or "").lower()))

    def _value_for(self, field: dict, values: dict):
        """The answer for one field of the LIVE form. The chat read the form from its HTML, so a field's name can
        differ here (another copy of the form on the page, a re-drawn widget): fall back to the question's wording,
        then to what kind of field it is (email, phone, name...)."""
        if values.get(field["name"]):
            return values[field["name"]]
        by_label = {self._slug(m.get("label")): m["name"] for m in self.meta if m.get("label")}
        name = by_label.get(self._slug(field.get("label")))
        if name and values.get(name):
            return values[name]
        kind = field.get("kind")
        if kind:
            same = [m["name"] for m in self.meta if m.get("kind") == kind and values.get(m["name"])]
            if len(same) == 1:   # only when it is unambiguous
                return values[same[0]]
        return None

    def _current(self, field: dict) -> str:
        """What the field on the live page holds right now."""
        if field.get("type") == "radio":
            for choice in field.get("choices") or []:
                try:
                    if self.frame.eval_on_selector(f'[data-odf="{choice["uid"]}"]', "e => e.checked"):
                        return choice["label"]
                except Exception:
                    continue
            return ""
        try:
            return self.frame.eval_on_selector(
                form_crawler.field_selector(field),
                "e => e.tagName === 'SELECT' ? (e.selectedOptions[0] ? e.selectedOptions[0].text.trim() : '')"
                " : e.type === 'checkbox' ? (e.checked ? 'yes' : '') : (e.value || '')")
        except Exception:
            return ""

    def _fill(self, values: dict) -> dict:
        self._refresh()
        filled = []
        for field in self.fields:
            value = self._value_for(field, values)
            if not value:
                continue
            # a field that already holds this value is left alone: choosing it again would make a dependent
            # dropdown reload (city > hospital > doctor) and wipe the choices made after it
            if self._current(field).strip().lower() == str(value).strip().lower():
                filled.append(field["name"])
                continue
            if _fill_value(self.frame, field, value):
                filled.append(field["name"])
                if field["type"] == "select":
                    # a chosen dropdown in a cascade (state > city > branch...) often kicks off the site's OWN
                    # AJAX call updating what it privately considers "confirmed" before the next one is touched; a
                    # person naturally leaves that gap by reading the next question, but filled in this fast, one
                    # of the earlier ones can still be mid-update when the next is already changing under it
                    self.page.wait_for_timeout(600)
        # what cannot be done from a chat: a captcha / one-time code, a file, a radio choice
        by_hand = [f.get("label") or f["name"] for f in self.fields
                   if f["required"] and (f["type"] == "file" or (f["type"] == "radio" and not f.get("options"))
                                         or BY_HAND_RE.search(f.get("label") or f["name"]))]
        return {"status": "ok", "filled_fields": filled, "by_hand": by_hand}


    # ---- reading the form again right now, and checking the answers against ITS rules before submitting
    @staticmethod
    def _date_parts(text: str):
        m = re.search(r"(\d{4})-(\d{1,2})-(\d{1,2})", text or "")
        if m:
            return m.group(1), m.group(2).zfill(2), m.group(3).zfill(2)
        m = re.search(r"(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})", text or "")
        if m:
            return m.group(3), m.group(2).zfill(2), m.group(1).zfill(2)   # day first, as typed in most of the world
        return None

    def _normalise(self, field: dict, value: str) -> tuple[str, str | None]:
        """(the value in the shape this field wants, a problem or None). Fixes what can be fixed silently (a date's
        format, a phone number's spaces and country code, the exact spelling of a dropdown choice) and reports
        what cannot (a value the field would reject)."""
        ftype, v = field.get("type") or "text", str(value).strip()
        placeholder = (field.get("placeholder") or "").lower()
        label = (field.get("label") or field["name"]).lower()
        kind = field.get("kind") or ""
        maxlen, minlen = int(field.get("maxlength") or 0), int(field.get("minlength") or 0)
        pattern = field.get("pattern") or ""

        if ftype in ("select", "radio"):
            options = field.get("options") or []
            if not options:
                return v, None
            exact = next((o for o in options if o.strip().lower() == v.lower()), None)
            near = exact or next((o for o in options if v.lower() in o.lower() or o.lower() in v.lower()), None)
            return (near, None) if near else (v, "This is not one of the choices the form offers")

        if ftype == "date" or kind in ("preferred_date", "date_of_birth") or re.search(r"\bdate\b", label):
            parts = self._date_parts(v)
            if not parts:
                return v, "Please give a date"
            y, mo, d = parts
            if ftype == "date":
                v = f"{y}-{mo}-{d}"
            else:
                sep = next((c for c in placeholder if c in "/-."), "-")
                if re.search(r"m+\W*d+\W*y+", placeholder):
                    v = f"{mo}{sep}{d}{sep}{y}"
                elif re.search(r"y+\W*m+\W*d+", placeholder):
                    v = f"{y}{sep}{mo}{sep}{d}"
                elif re.search(r"d+\W*m+\W*y+", placeholder):
                    v = f"{d}{sep}{mo}{sep}{y}"
                # no format hint: the ISO date the person picked is left as it is
        elif ftype == "email" or kind.endswith("email"):
            v = v.replace(" ", "").lower()
            if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]{2,}", v):
                return v, "This doesn't look like an email address"
        elif ftype == "tel" or kind.endswith("phone") or re.search(r"mobile|phone|contact no", label):
            digits = re.sub(r"\D", "", v)
            want = 10 if (re.search(r"\\d\{10\}|\[0-9\]\{10\}", pattern) or maxlen == 10 or minlen == 10) else 0
            if want and len(digits) > want:
                digits = digits[-want:]           # "+91 98765 43210" / "098765 43210" -> the 10 digits
            v = ("+" if v.startswith("+") and not want else "") + digits
            if want and len(digits) != want:
                return v, f"Please give a {want}-digit number"
        elif ftype == "number":
            v = re.sub(r"[,\s]", "", v)
            try:
                number = float(v)
            except ValueError:
                return v, "Please give a number"
            if field.get("min") not in ("", None) and number < float(field["min"]):
                return v, f"Must be at least {field['min']}"
            if field.get("max") not in ("", None) and number > float(field["max"]):
                return v, f"Must be at most {field['max']}"

        if maxlen and len(v) > maxlen:
            return v, f"At most {maxlen} characters"
        if minlen and len(v) < minlen:
            return v, f"At least {minlen} characters"
        if pattern:
            try:
                if not re.fullmatch(pattern, v):
                    return v, field.get("title") or "This isn't in the format the form expects"
            except re.error:
                pass   # a pattern Python cannot read: leave it to the form itself
        return v, None

    def _preflight(self, values: dict) -> dict:
        """Reads the form as it is right now (the page may have changed since it was first read) and checks every
        answer against the fields' own rules. Values that only need reshaping are fixed and filled in; what cannot be
        fixed, and any required question that has no answer yet - even one the first read did not know about - is
        returned as a problem, so the chat can ask BEFORE submitting."""
        self.fields = self._rescan()
        adjusted, problems = {}, []
        for field in self.fields:
            label = field.get("label") or field["name"]
            if field["type"] == "file" or BY_HAND_RE.search(label):
                continue
            value = self._value_for(field, values)
            info = {"type": field["type"], "options": field.get("options") or [], "required": bool(field["required"]),
                    "kind": field.get("kind"), "label": label}
            if field["type"] == "checkbox":
                if field["required"] and str(value or "").strip().lower() not in ("yes", "true", "on", "1", "agree"):
                    problems.append({"name": field["name"], "label": label, "message": "The form requires you to agree", "field": info})
                elif value:
                    adjusted[field["name"]] = value
                continue
            if not value:
                if field["required"]:
                    problems.append({"name": field["name"], "label": label, "message": "The form requires this", "field": info})
                continue
            fixed, problem = self._normalise(field, value)
            if problem:
                problems.append({"name": field["name"], "label": label, "message": problem, "field": info})
            else:
                adjusted[field["name"]] = fixed
        if adjusted:
            self._fill(adjusted)   # the reshaped values, typed into the form
        state = self._captcha_state()
        return {"status": "ok", "problems": problems, "adjusted": adjusted,
                "captcha": bool(state["present"] and not state["solved"]), "captcha_broken": bool(state.get("broken"))}

    def _attach(self, name: str, filename: str, data: bytes) -> dict:
        """Attaches a file the person chose in the chat (a CV, a photo...) to the form's file field. The file only
        exists in memory for this call: it is not stored on this server."""
        self._refresh()
        field = next((f for f in self.fields if f["name"] == name and f["type"] == "file"), None)
        if field is None:
            return {"status": "error", "message": "I couldn't find that file field on the form."}
        import mimetypes
        mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        try:
            self.frame.locator(form_crawler.field_selector(field)).set_input_files(
                files=[{"name": filename, "mimeType": mime, "buffer": data}], timeout=10000)
        except Exception as exc:
            log.info("[form-session] could not attach the file: %s", str(exc)[:160])
            return {"status": "error", "message": "The form didn't accept the file."}
        self.page.wait_for_timeout(500)
        return {"status": "ok"}

    _OTP_FIELD_JS = """() => {
      const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const labelOf = e => {
        if (e.id) { const l = document.querySelector('label[for="' + CSS.escape(e.id) + '"]'); if (l) return l.innerText; }
        const p = e.closest('label'); if (p) return p.innerText;
        const box = e.closest('.form-group, .control-group, .row, li, p');
        const l2 = box ? box.querySelector('label') : null;
        return (l2 && l2.innerText) || e.getAttribute('aria-label') || e.placeholder || e.name || e.id || '';
      };
      const otpWord = /\\botp\\b|verification code|one[- ]time (code|password|pin)/i;
      const boxes = Array.from(document.querySelectorAll('input:not([type=hidden]):not([type=submit]), textarea'));
      for (const e of boxes) {
        if (e.disabled) continue;
        const label = (labelOf(e) || '').trim();
        if (!otpWord.test(label) && !otpWord.test(e.name || '') && !otpWord.test(e.id || '')) continue;
        if (!vis(e)) continue;
        if ((e.value || '').trim()) continue;
        return {name: e.name || e.id, label: label || e.name || e.id};
      }
      return null;
    }"""

    def _otp_field(self) -> dict | None:
        """The form's own one-time code box, if it is showing right now and still empty: sites that ask for one
        often keep it hidden until Submit is pressed once (the code is only sent then), so this is checked again,
        fresh, after every press - not just when the form was first opened. Read straight from the live page (never
        from the tagged/rescanned field list, which can drop a field that only just appeared), so it is found
        whatever the rest of the page around it looks like right now. Never the captcha box, which is a different
        kind of "only a person can do this" step with its own handling."""
        # self.frame first: that is where the rest of the form the person is already answering lives, and an
        # embedded form's own one-time code, on the rare site that has one, belongs there too - never reassigned
        # here, so a form embedded in an iframe is not silently switched back to the page around it.
        for fr in dict.fromkeys([self.frame, self.page.main_frame]):
            try:
                found = fr.evaluate(self._OTP_FIELD_JS)
            except Exception:
                continue
            if not found or re.search(r"captcha|not a robot", found.get("label") or "", re.I):
                continue
            field = next((f for f in self.fields if f["name"] == found["name"]), None)
            if field is None:
                # not one of the fields this session already knows (it only just appeared): added now, by its own
                # name, so the chat's next "fill" can type the code straight into it like any other question
                field = {"name": found["name"], "id": "", "type": "text", "uid": "", "gid": "", "choices": [],
                        "label": found.get("label") or found["name"], "required": True, "options": [],
                        "pattern": "", "minlength": 0, "maxlength": 0, "min": "", "max": "", "placeholder": "", "title": "",
                        "kind": None}
                if fr == self.frame:
                    self.fields.append(field)
            return field
        return None

    # An "I'm not a robot" box can only be ticked by a person. It is not solved or bypassed here: the person is shown
    # the box (a picture of just that part of the page) in the chat and clicks on it there; the click is passed to it.
    _CAPTCHA_JS = """(scroll) => {
      const vis = e => { const r = e.getBoundingClientRect(), s = getComputedStyle(e);
        return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none'; };
      const anchors = Array.from(document.querySelectorAll(
        'iframe[src*="recaptcha/api2/anchor"], iframe[src*="hcaptcha.com"][src*="checkbox"], iframe[src*="challenges.cloudflare.com"], '
        + '.g-recaptcha, .h-captcha, .cf-turnstile')).filter(e => !/size=invisible/.test(e.src || ''));
      const token = Array.from(document.querySelectorAll('[name="g-recaptcha-response"], [name="h-captcha-response"], '
        + '[name="cf-turnstile-response"]')).some(e => (e.value || '').length > 20);
      const shown = anchors.filter(vis);
      if (!anchors.length) return {present: false, solved: false};
      if (!shown.length) return {present: true, solved: token, box: null};
      if (scroll) shown[0].scrollIntoView({block: 'center', inline: 'nearest'});
      const parts = shown.slice(0, 1).concat(Array.from(document.querySelectorAll(
        'iframe[src*="recaptcha/api2/bframe"], iframe[src*="hcaptcha.com"][src*="challenge"]')).filter(vis));
      let x1 = 1e9, y1 = 1e9, x2 = 0, y2 = 0;
      parts.forEach(e => { const r = e.getBoundingClientRect();
        x1 = Math.min(x1, r.left); y1 = Math.min(y1, r.top); x2 = Math.max(x2, r.right); y2 = Math.max(y2, r.bottom); });
      x1 = Math.max(0, x1 - 6); y1 = Math.max(0, y1 - 6);
      x2 = Math.min(innerWidth, x2 + 6); y2 = Math.min(innerHeight, y2 + 6);
      return {present: true, solved: token, box: {x: x1, y: y1, width: x2 - x1, height: y2 - y1}};
    }"""

    def _captcha_state(self, scroll: bool = False) -> dict:
        state = {"present": False, "solved": False, "box": None}
        for fr in {self.page.main_frame, self.frame}:
            try:
                got = fr.evaluate(self._CAPTCHA_JS, scroll)
            except Exception:
                continue
            if got.get("present"):
                got["broken"] = self._captcha_broken()
                return {**state, **got}
        return state

    def _captcha_broken(self) -> bool:
        """Some sites' boxes are set up wrongly ("ERROR for site owner: Invalid domain for site key"): nobody can tick
        them, so the form cannot be sent from any browser."""
        for fr in self.page.frames:
            if re.search(r"recaptcha|hcaptcha", fr.url):
                try:
                    if re.search(r"error for site owner|invalid (domain|site key)|invalid key type",
                                 fr.evaluate("() => document.body ? document.body.innerText : ''"), re.I):
                        return True
                except Exception:
                    continue
        return False

    def _captcha(self, click: dict | None = None) -> dict:
        """Optionally passes one click (fractions x, y of the picture last shown) to the captcha, then returns a fresh
        picture of it: {"present", "solved", "image_base64", "width", "height"}."""
        state = self._captcha_state(scroll=True)
        if click and state.get("box"):
            box = state["box"]
            self.page.mouse.click(box["x"] + float(click["x"]) * box["width"], box["y"] + float(click["y"]) * box["height"])
            self.page.wait_for_timeout(2500)   # the tick animates; a picture challenge loads after it
            state = self._captcha_state(scroll=False)
        out = {"status": "ok", "present": state["present"], "solved": state["solved"], "broken": bool(state.get("broken"))}
        if state.get("box") and not state["solved"]:
            box = state["box"]
            try:
                png = self.page.screenshot(clip=box, type="png")
                out.update(image_base64=base64.b64encode(png).decode(), width=round(box["width"]), height=round(box["height"]))
            except Exception as exc:
                log.info("[form-session] could not take a picture of the captcha: %s", str(exc)[:120])
        return out

    def _rescan(self) -> list[dict]:
        try:
            frame, fields = form_crawler.find_form_in_page(self.page, self.meta)
            if frame is not None:
                self.frame = frame
                return fields
        except Exception:
            pass
        return self.fields

    def _options(self, name: str) -> dict:
        """The choices a dropdown offers right now (it may fill in only after an earlier one was chosen)."""
        self._refresh()
        field = next((f for f in self.fields if f["name"] == name), None)
        if field is None:
            return {"status": "error", "options": []}
        options: list[str] = []
        for attempt in range(40):   # up to ~20 s for a dropdown that loads its choices from the site - a slow AJAX
                                    # call over a real connection, not a local one, can take longer than a few seconds
            try:
                options = self.frame.eval_on_selector(
                    form_crawler.field_selector(field),
                    "s => { const all = Array.from(s.options), real = all.filter(o => (o.value || '').trim() !== '');"
                    " return (real.length ? real : all).map(o => o.text.trim()).filter(t => t && !/^(select|choose|--)/i.test(t)); }")
            except Exception:   # the page re-drew the form: tag it again and find the field once more
                options = []
                self._refresh()
                field = next((f for f in self.fields if f["name"] == name), field)
            if options:
                break
            self.page.wait_for_timeout(500)
            if attempt % 6 == 5:   # re-tag every few tries too, not only after an outright error: a field that gets
                                   # replaced wholesale (not just given new options) keeps the old tag pointing at
                                   # nothing, which throws no exception by itself, just quietly finds nothing
                self._refresh()
                field = next((f for f in self.fields if f["name"] == name), field)
        return {"status": "ok", "options": list(dict.fromkeys(options))[:200]}   # each choice once

    def _refresh(self) -> None:
        """Re-tags the live form (the page may have re-drawn it since) without any waiting or clicking, keeping the
        same form the chat is working on."""
        try:
            frame, fields = form_crawler._scan_frames(self.page, self.meta)
        except Exception:
            return
        if frame is not None and fields:
            self.frame, self.fields = frame, fields

    _SUBMIT_FINDER_JS = """(sel) => {
      // Finds the control that submits THIS form, however the page draws it: <button> (with or without a type),
      // <input type=submit|button|image>, a link or div that acts as a button. Scored, not matched by one word.
      const first = document.querySelector(sel.first), last = document.querySelector(sel.last);
      let scope = sel.gid ? document.querySelector('[data-odform="' + sel.gid + '"]') : null;
      const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && getComputedStyle(e).visibility !== 'hidden'; };
      const CONTROLS = 'button, input[type=submit], input[type=button], input[type=image], a, [role=button], div[onclick], span[onclick]';
      const bad = /(cancel|close|reset|clear|back|previous|prev\\b|search|log ?in|sign ?in|menu|call now|whatsapp|share|print|download|read more|learn more|skip|edit)/i;
      const good = /(submit|send|book|make|apply|register|request|confirm|save|proceed|continue|next|enquir|inquir|appointment|schedule|reserve|contact|join|subscribe|get |go\\b|pay|verify|validat|otp)/i;
      const candidates = root => Array.from(root.querySelectorAll(CONTROLS)).filter(e => vis(e) && !e.disabled);
      if (!scope && first && last) {   // fields that are not inside a <form>: the smallest box that holds them and a button
        let box = first;
        while (box && !(box.contains(last) && candidates(box).length)) box = box.parentElement;
        scope = box || document.body;
      }
      scope = scope || document.body;
      let best = null, bestScore = -1;
      candidates(scope).forEach((e, i, all) => {
        const text = (e.innerText || e.value || e.getAttribute('aria-label') || e.title || e.alt || '').trim();
        const type = (e.getAttribute('type') || '').toLowerCase();
        if (type === 'reset' || (bad.test(text) && !good.test(text))) return;
        if (e.tagName === 'A' && !/(btn|button)/i.test(e.className || '') && !good.test(text)) return;   // an ordinary link
        let s = 0;
        if (type === 'submit') s += 10;
        else if (e.tagName === 'BUTTON' && !type) s += 8;          // a <button> without a type submits its form
        else if (type === 'image') s += 7;
        else if (e.tagName === 'INPUT' && type === 'button') s += 4;
        else if (e.tagName === 'BUTTON') s += 3;                    // type=button: only by JavaScript, so it needs wording
        else s += 1;
        if (good.test(text)) s += 5;
        if (e.form && scope.tagName === 'FORM' && e.form === scope) s += 3;
        s += i / 100;                                               // later ones (nearer the end of the form) win ties
        if (s > bestScore) { best = e; bestScore = s; }
      });
      document.querySelectorAll('[data-odsubmit]').forEach(x => x.removeAttribute('data-odsubmit'));
      if (!best) return null;
      best.setAttribute('data-odsubmit', '1');
      return {text: (best.innerText || best.value || '').trim().slice(0, 40), tag: best.tagName, score: bestScore};
    }"""

    def _find_submit(self):
        """The Submit control of THE form being filled (not of another form on the same page), or None."""
        gid = next((f.get("gid") for f in self.fields if f.get("gid")), "")
        located = [f for f in self.fields if f.get("uid")]
        sel = {"gid": gid, "first": form_crawler.field_selector(located[0]) if located else "",
               "last": form_crawler.field_selector(located[-1]) if located else ""}
        try:
            found = self.frame.evaluate(self._SUBMIT_FINDER_JS, sel)
        except Exception as exc:
            log.warning("[form-session] could not look for the Submit button: %s", exc)
            return None
        if not found:
            return None
        log.info("[form-session] Submit control: %s %r (score %.1f)", found["tag"], found["text"], found["score"])
        return self.frame.locator('[data-odsubmit="1"]').first

    def _submit_without_button(self) -> bool:
        """A form with no button at all still submits: by pressing Enter in its last text box, or requestSubmit()."""
        try:
            gid = next((f.get("gid") for f in self.fields if f.get("gid")), "")
            if gid and self.frame.evaluate("g => { const f = document.querySelector('[data-odform=\"' + g + '\"]');"
                                           " if (!f) return false; window.__od = {clicked: false, submitted: false};"
                                           " f.addEventListener('submit', () => { window.__od.submitted = true; }, true);"
                                           " f.requestSubmit(); return true; }", gid):
                self.page.wait_for_timeout(1200)
                return True
        except Exception as exc:
            log.info("[form-session] requestSubmit without a button failed: %s", str(exc)[:120])
        return False
    def _dismiss_overlays(self) -> None:
        """Closes what covers a page: exit-intent / newsletter / cookie pop-ups and modals."""
        try:
            self.page.keyboard.press("Escape")
        except Exception:
            pass
        for scope in {self.page.main_frame, self.frame}:
            try:
                scope.evaluate("""() => {
                  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
                  const covers = Array.from(document.querySelectorAll(
                    '[class*="popup"], [id*="popup"], [class*="modal"], [class*="overlay"], [class*="cookie"], [role="dialog"]'))
                    .filter(e => vis(e) && !e.querySelector('[data-odform]:not([data-odform=""])') && !e.hasAttribute('data-odform')
                                 && !e.querySelector('[data-odf]'));   // never the form being filled (or a box that holds it)
                  covers.forEach(c => {
                    const close = c.querySelector('[class*="close"], [aria-label*="close" i], [data-dismiss], [data-bs-dismiss], button.btn-close');
                    if (close) { try { close.click(); } catch (e) {} }
                  });
                  // whatever is still covering the page is switched off: it is an advert, not part of the form
                  covers.forEach(c => { if (vis(c)) { c.style.setProperty('display', 'none', 'important'); c.setAttribute('aria-hidden', 'true'); } });
                }""")
            except Exception:
                continue

    _NOT_A_SUBMISSION = re.compile(r"google-analytics|googletagmanager|doubleclick|facebook\.|clarity\.ms|hotjar|/collect|"
                                   r"gtag|analytics|pixel|beacon|sentry|segment\.|mixpanel|amplitude|connect\.facebook", re.I)

    def _on_request(self, request) -> None:
        """Notes every request that sends data to a site - except analytics - so that a Submit press can be recognised
        by what it DID, not by whether one particular element noticed it."""
        try:
            if request.method != "GET" and request.resource_type in ("xhr", "fetch", "document", "other") \
                    and not self._NOT_A_SUBMISSION.search(request.url):
                self.writes.append(time.time())
        except Exception:
            pass

    _UNCOVER_JS = """(btn) => {
      // Whatever sits on top of the button (an exit-intent pop-up, a chat widget, a cookie bar, a sticky banner) is
      // found by asking the page what is at the button's own position, and switched off - whatever its class is called.
      btn.scrollIntoView({block: 'center', inline: 'center'});
      let hidden = 0;
      for (let i = 0; i < 8; i++) {
        const r = btn.getBoundingClientRect();
        const top = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
        if (!top || top === btn || btn.contains(top) || top.contains(btn)) break;   // nothing covers it (any more)
        let cover = top;   // the outermost element that covers the button but does not contain it
        while (cover.parentElement && cover.parentElement !== document.body && !cover.parentElement.contains(btn)) cover = cover.parentElement;
        cover.style.setProperty('display', 'none', 'important');
        hidden++;
      }
      return hidden;
    }"""

    _TEXT_BLOCKS_JS = """(scrollTo) => {
      // The text the person can see on the page right now, block by block (an element's own words). Comparing this
      // before and after pressing Submit finds ANY message the page shows - a toast, a pop-up, a line under the
      // form - whatever it says and whatever it is called.
      const vis = e => { const r = e.getBoundingClientRect(), s = getComputedStyle(e);
        return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0'; };
      const own = e => { let o = ''; e.childNodes.forEach(n => { if (n.nodeType === 3) o += n.textContent; });
        return o.replace(/\\s+/g, ' ').trim().slice(0, 160); };
      const SKIP = ['SCRIPT', 'STYLE', 'NOSCRIPT', 'OPTION', 'SELECT', 'TEXTAREA', 'INPUT'];
      const blocks = [];
      document.querySelectorAll('body *').forEach(e => {
        if (SKIP.includes(e.tagName)) return;
        const o = own(e);
        if (o.length >= 4 && vis(e)) blocks.push(o);
      });
      if (scrollTo) {   // bring the element that says exactly this into view, so the picture shows it
        const el = Array.from(document.querySelectorAll('body *')).find(e => !SKIP.includes(e.tagName) && own(e) === scrollTo && vis(e));
        if (el) el.scrollIntoView({block: 'center', inline: 'nearest'});
      }
      return Array.from(new Set(blocks)).slice(0, 600);
    }"""

    def _blocks(self, scroll_to: str = "") -> set[str]:
        """Every visible block of text on the page (and in the form's frame)."""
        out: set[str] = set()
        for fr in {self.page.main_frame, self.frame}:
            try:
                out.update(fr.evaluate(self._TEXT_BLOCKS_JS, scroll_to))
            except Exception:
                continue
        return out

    def _watch(self) -> None:
        """Looks at the page right now. The moment NEW text shows up that was not there before Submit was pressed
        (a confirmation, an error, a pop-up), the message is scrolled into view and the picture is taken AT THAT
        MOMENT. Toasts and pop-ups vanish after a couple of seconds, and some sit off-screen, so a picture taken later
        (or without scrolling) misses them. Several pictures are kept; the best is chosen at the end."""
        if len(self._shots) >= 60:   # generous: this may now be watched for minutes, not seconds
            return
        try:
            busy_now = bool(self.frame.evaluate(_BUSY_JS))
        except Exception:
            busy_now = False
        now = self._blocks()
        fresh = [b for b in now if b not in self._before_blocks and b not in self._seen_blocks]
        # some sites show their final wording BEFORE they stop looking busy (the text changes first, the spinner
        # class comes off a moment later): the text alone is never trusted while busy is true, so the moment
        # busy clears is watched for too, even when no further text has changed since
        settled = self._was_busy and not busy_now
        self._was_busy = busy_now
        if not fresh and not settled:
            return
        self._seen_blocks.update(fresh)
        if fresh:
            self._blocks(scroll_to=max(fresh, key=len))
        # once settled, everything that showed up since Submit (not just this instant's fresh text) is what is judged
        judge = fresh if not settled else list(now - self._before_blocks)
        self._shots.append({"shot": self._shot(), "fresh": fresh or judge, "busy": busy_now,
                            "success": bool(SUCCESS_RE.search(" ".join(judge))) and not self._already_thanks and not busy_now})

    def _final_shot(self) -> str:
        """The most useful picture of what happened: one taken while the confirmation was showing (and the page had
        stopped working - never a "Submitting..." spinner mid-frame); else one showing a message that has since
        gone (a pop-up); else the first one that showed anything new; else the page as it is."""
        final = self._blocks()
        shots = self._shots
        picked = None
        if shots:
            success = [s for s in shots if s["success"]]
            if success:
                picked = success[0]["shot"]   # the earliest picture that shows the confirmation
            else:
                gone = [s for s in shots if any(t not in final for t in s["fresh"])]
                if gone:
                    picked = max(gone, key=lambda s: sum(len(t) for t in s["fresh"] if t not in final))["shot"]
                else:
                    picked = shots[0]["shot"]
        return picked or self._shot()
    def _wait_watching(self, ms: int) -> None:
        """Waits `ms` milliseconds, looking at the page every tenth of a second."""
        waited = 0
        while waited < ms:
            self.page.wait_for_timeout(100)
            waited += 100
            self._watch()

    def _triggered(self, since: float) -> bool:
        """Did the press reach the site? Judged by what happened since `since`: the page sent data (a submission), it
        navigated, the button or its form noticed the press, or the button's page is gone. Deliberately NOT judged by
        one element alone: sites re-draw their buttons, and pressing again after a real submission sends it twice."""
        if any(t >= since for t in self.writes) or any(t >= since for t in self.moves):
            return True
        try:
            state = self.frame.evaluate("() => window.__od ? !!(window.__od.clicked || window.__od.submitted) : 'gone'")
        except Exception:
            return True   # the page navigated away while we asked
        return state is True or state == "gone"

    def _press(self, button) -> bool:
        """Presses the form's Submit button by whichever way works on THIS page: a normal click; the button's own
        click() (needs no free spot on screen); the same after removing whatever covers the button; a forced click;
        the form's requestSubmit(); a real mouse click; the Enter key. The next way is only tried when the last one
        clearly did nothing - never after a press that may have gone through - so the form is never sent twice."""
        try:
            button.evaluate("""btn => { window.__od = {clicked: false, submitted: false};
                btn.addEventListener('click', () => { window.__od.clicked = true; }, true);
                if (btn.form) btn.form.addEventListener('submit', () => { window.__od.submitted = true; }, true); }""",
                            timeout=5000)
        except Exception as exc:
            log.warning("[form-session] could not watch the Submit button: %s", exc)

        def uncover() -> None:
            try:
                button.evaluate(self._UNCOVER_JS, timeout=5000)
            except Exception:
                pass
            self._dismiss_overlays()

        def mouse() -> None:
            box = button.bounding_box()
            if not box:
                raise RuntimeError("the button has no position")
            self.page.mouse.click(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)

        attempts = [
            ("click", lambda: button.click(timeout=2500)),
            ("the button's own click", lambda: button.evaluate("b => b.click()", timeout=4000)),
            ("click after clearing the page", lambda: (uncover(), button.click(timeout=2500))),
            ("forced click", lambda: button.click(force=True, timeout=2500)),
            ("requestSubmit", lambda: button.evaluate("b => b.form ? b.form.requestSubmit(b) : b.click()", timeout=4000)),
            ("mouse click", lambda: (uncover(), mouse())),
            ("Enter key", lambda: (button.focus(timeout=2500), self.page.keyboard.press("Enter"))),
        ]
        # Some sites still submit the old-fashioned way: a plain <input type=submit> whose onclick just calls
        # this.form.submit() there and then, so the page can start tearing itself down WHILE Playwright's click
        # is still being carried out - it then reports the click as failed ("execution context was destroyed" and
        # the like), when what actually happened is the opposite: the click landed, and landed so well the page
        # is already leaving. That wording, and only that wording, is trusted as a press having gone through.
        navigated_away = re.compile(r"execution context was destroyed|target closed|"
                                    r"target page,? context or browser has been closed|frame (was|got) detached|"
                                    # Playwright's own click() timed out, but its call log says the click itself
                                    # landed and it was only waiting on the page's OWN following navigation to
                                    # settle - a plain old "onclick submits the form" button often navigates so
                                    # promptly that this wait outlasts our timeout on a site whose server is slow
                                    r"click action done", re.I)
        for name, attempt in attempts:
            since = time.time()
            try:
                attempt()
            except Exception as exc:
                if navigated_away.search(str(exc)):
                    log.info("[form-session] submit by %s: the page left while pressing it - taken as a press that landed", name)
                    return True
                log.info("[form-session] submit by %s failed: %s", name, str(exc)[:160])
                continue
            self._wait_watching(1200)   # give the site time to react before deciding it did not (and catch its message)
            if self._triggered(since):
                log.info("[form-session] submit pressed by %s", name)
                return True
            log.info("[form-session] submit by %s ran, but the page did not react (url %s)", name, self.page.url[:80])
        log.warning("[form-session] no way of pressing Submit worked")
        return False

    def _read_page(self) -> dict:
        sels = [{"name": f["name"], "sel": form_crawler.field_selector(f)} for f in self.fields]
        info = self.frame.evaluate(_ANALYZE_JS, sels)
        main_text = ""
        if self.frame != self.page.main_frame:   # a message may appear on the page around an embedded form
            try:
                main_text = self.page.main_frame.evaluate("() => (document.body ? document.body.innerText : '').slice(0, 6000)")
            except Exception:
                pass
        info["body"] = (info.get("body") or "") + " " + main_text
        return info

    def _submit(self) -> dict:
        self._refresh()
        state = self._captcha_state()
        if state["present"] and not state["solved"] and not state.get("broken"):
            # (a box that is broken on the site's own side cannot be ticked by anyone: the form is tried anyway, exactly
            # as a visitor pressing Submit would, because many such sites never check it on their server)
            # pressing Submit now would only make the site say "please tick the box": the person has to do that first
            return {"status": "captcha", "broken": bool(state.get("broken")),
                    "message": "The form has an \"I'm not a robot\" check that has to be ticked first."}
        button = self._find_submit()
        # what each field holds before the press: a field that held something and is EMPTY afterwards was cleared by
        # the site after sending (a contact form that resets itself) - that is not an error, and it is not "missing"
        filled_before = {f["name"] for f in self.fields if self._current(f).strip()}
        try:
            before = self._read_page()
            url_before = self.page.url
        except Exception:
            before, url_before = {"body": ""}, self.page.url
        already_thanks = bool(SUCCESS_RE.search(before.get("body") or ""))
        self._already_thanks = already_thanks
        self._shots, self._seen_blocks, self._was_busy = [], set(), False
        self._before_blocks = self._blocks()   # what the page says before Submit: anything new afterwards is its answer
        if button is None:
            # no button anywhere in or beside the form: submit the form itself
            since = time.time()
            if not (self._submit_without_button() and self._triggered(since)):
                return {"status": "error", "message": "I couldn't find a way to submit this form from here. "
                                                      "Please use the place's own page."}
        elif not self._press(button):
            return {"status": "error", "message": "I couldn't press the form's Submit button - something on the page "
                                                  "is covering it. You can try again or use the place's own page."}
        # Keep watching for the site's own confirmation - not just for a little while: some sites answer in well
        # under a second, others take a couple of minutes (a slow mail relay, a review step), so this is willing to
        # wait, checking and screenshotting about once a second, for as long as it reasonably can. It only stops
        # early for a real reason: the confirmation has actually been seen, the site rejected something, or the
        # person has to do a step no one else can (a one-time code, a captcha) - never just because time is short.
        end = time.time() + 180
        grace_end = None   # set once the form itself visibly changes with no confirmation text yet (see below)
        busy_since = None   # when "busy" was FIRST seen without a break since - see below
        otp = captcha_needed = None
        seen: dict = {}
        while time.time() < end:
            # checked and screenshotted several times a second - a real toast can come and go in under two seconds,
            # and this must never be the reason a genuine confirmation is missed, however long it ends up waiting overall
            self.page.wait_for_timeout(200)
            self._watch()
            try:
                seen = self._read_page()
            except Exception:
                seen = {}
                break   # the page navigated: read what's there now, below
            if seen.get("busy"):
                busy_since = busy_since or time.time()
                # "busy" is judged by the Submit button's own state as well as the page's, and plenty of sites
                # disable that button - permanently, on purpose, to stop a second click - the moment it is first
                # pressed, whether or not anything is still happening; taken at face value with no limit, a page
                # like that would look "busy" forever and nothing after this point would ever be looked at again.
                # Trusted for a little while, since a real spinner rarely runs long - past that, it is not read as
                # meaning anything further is being worked on, and everything below starts being checked as usual.
                if time.time() - busy_since < 20:
                    continue
            else:
                busy_since = None
            # checked BEFORE trusting any "success"-sounding text: a site's own "we've sent you a code" message
            # often reads exactly like a confirmation (it may even say "sent successfully"), but the one-time-code
            # box now showing, empty, is the real answer - it must never be mistaken for the finish line
            otp = self._otp_field()
            if otp is not None:
                break
            if seen.get("captcha") and re.search(r"captcha|not a robot|verify (that )?you|recaptcha", (seen.get("body") or ""), re.I) \
                    and not already_thanks and not self._captcha_state()["solved"]:
                captcha_needed = True
                break
            if any(s["success"] for s in self._shots):
                break   # the confirmation itself has been caught, mid-page, exactly as it looked at that moment
            raw_alerts = seen.get("alerts") or []
            real_alerts = [a for a in raw_alerts if not SUCCESS_RE.search(a)]
            if seen.get("fields") or real_alerts:
                break   # a rejection: no point waiting minutes for a confirmation that a rejected form won't get
            # the form itself already changed - cleared, or stopped showing - but nothing has SAID anything yet.
            # The site's own message may just be a beat behind, worth a further look - but how much further depends
            # on WHY it looks done: an AJAX form that just cleared itself settles in well under a second, so a short
            # look is enough; a real page navigation (some "Submit" buttons still do a plain old-fashioned form post,
            # not AJAX) can mean a slow server round trip still to come - sending a text message, among other things
            # can take a while - so that is given much longer before this gives up on ever hearing back.
            moved_now = self.page.url.split("#")[0] != url_before.split("#")[0]
            now_cleared = sum(1 for f in self.fields if f["name"] in filled_before and not self._current(f).strip())
            looks_done = (seen.get("visibleFields") or 0) == 0 or now_cleared >= max(1, len(filled_before) // 2)
            if looks_done:
                grace_end = grace_end or time.time() + (60 if moved_now else 8)
                if time.time() >= grace_end:
                    break
        try:
            after = self._read_page()
        except Exception:
            # the form's frame is gone entirely - the page moved on, which normally means it went through, but
            # there was no confirmation text to point to, so this is not claimed as certain either
            try:
                shot = self._shot()
            except Exception:
                shot = None
            return {"status": "success", "confirmed": False, "message": "The page moved on after submitting.",
                    "screenshot_base64": shot}

        if otp is not None:
            # a one-time code just sent to the person's own phone or email cannot be typed by anyone else: this
            # is not a rejection and not the answer either, just the next step, so Submit is not pressed again here -
            # the chat asks for the code, types it in, and presses Submit itself once it has it
            return {"status": "otp_required", "field": {"name": otp["name"], "label": otp.get("label") or otp["name"]},
                    "screenshot_base64": self._final_shot()}
        if captcha_needed:
            return {"status": "captcha", "message": "The site is asking for the \"I'm not a robot\" check.",
                    "screenshot_base64": self._final_shot()}

        errors, cleared = [], set()
        for item in after.get("fields") or []:
            field = next((f for f in self.fields if f["name"] == item["name"]), None)
            if field and item["name"] in filled_before and not self._current(field).strip():
                cleared.add(item["name"])   # emptied by the site after sending: not a mistake in the answer
                continue
            # "please fill out this field" about a field that does hold a value is a stale message, not a real error
            if field and re.search(r"fill out|select an item|required|choose", item["message"], re.I) and self._current(field).strip():
                continue
            errors.append({"name": item["name"], "label": (field or {}).get("label") or item["name"], "message": item["message"]})
        # an alert box that reads as a confirmation ("Thanks for contacting us!") is the site's answer, not a
        # complaint - some plugins (Forminator among them) show their success message in the same kind of box
        # as their error messages, so this is judged by what it SAYS, never by which box it is in.
        raw_alerts = after.get("alerts") or []
        success_alerts = [a for a in raw_alerts if SUCCESS_RE.search(a)]
        alerts = [a for a in raw_alerts if a not in success_alerts]
        if errors or alerts:
            return {"status": "errors", "errors": errors, "alerts": alerts, "screenshot_base64": self._final_shot()}
        thanks = (bool(SUCCESS_RE.search(after.get("body") or "")) or bool(success_alerts)) and not already_thanks
        if thanks:
            # proof, not a guess: the confirmation was actually read on the page (or in the shot that caught it)
            return {"status": "success", "confirmed": True, "message": "The page confirmed it.",
                    "screenshot_base64": self._final_shot()}
        # No confirmation TEXT ever showed up, however long this waited. The form itself may still say plenty: it
        # can empty itself, or the page can move on, the way many ordinary AJAX contact forms answer "done" without
        # ever writing a word - that is real signal, not nothing, so it still counts as sent; it is just labelled
        # "confirmed: false", the screenshot is ALWAYS attached either way, and the chat says the page itself never
        # actually said so, so the person can look at the very same picture and judge it for themselves.
        moved = self.page.url.split("#")[0] != url_before.split("#")[0]
        gone = (after.get("visibleFields") or 0) == 0
        cleared_most = bool(cleared) and len(cleared) >= max(1, len(filled_before) // 2)
        if cleared_most or gone or moved:
            return {"status": "success", "confirmed": False, "screenshot_base64": self._final_shot(),
                    "message": ("The form cleared itself after sending." if cleared_most
                               else "The page moved on after submitting." if moved
                               else "The form is no longer showing.")}
        return {"status": "unknown", "screenshot_base64": self._final_shot(),
                "message": "I pressed Submit, but the page didn't say whether it went through."}


_sessions: dict[str, FormSession] = {}
_sessions_lock = threading.Lock()


def open_session(url: str, owner: str, headed: bool = False) -> FormSession:
    """A new browser session for `owner` on `url` (also tidies up sessions that have been idle or closed)."""
    with _sessions_lock:
        for sid, s in list(_sessions.items()):
            if not s.alive or time.time() - s.last_used > SESSION_IDLE_S:
                _sessions.pop(sid, None)
        session = FormSession(url, owner, headed)
        _sessions[session.id] = session
        return session


def get_session(sid: str, owner: str) -> FormSession | None:
    s = _sessions.get(sid)
    return s if s and s.owner == owner and s.alive else None


def close_session(sid: str, owner: str) -> None:
    s = _sessions.get(sid)
    if s and s.owner == owner:
        s.call("close", timeout=10)
        _sessions.pop(sid, None)


