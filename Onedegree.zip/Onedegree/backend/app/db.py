"""The database: the engine/session (connect, create-if-missing) and every table (SQLAlchemy ORM model),
kept together since one is meaningless without the other in a project this size.
"""
import logging
import os
import uuid
from datetime import datetime, date
from pathlib import Path

import psycopg2
from dotenv import load_dotenv
from psycopg2 import sql
from sqlalchemy import (CheckConstraint, Date, DateTime, Float, ForeignKey, Integer, SmallInteger, String,
                        Text, UniqueConstraint, URL, create_engine, func, inspect, text)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker

load_dotenv(Path(__file__).resolve().parent.parent.parent / ".env")

log = logging.getLogger("onedegree.db")

DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_NAME = os.getenv("DB_NAME", "OneDegree")

DATABASE_URL = URL.create(
    "postgresql+psycopg2",
    username=DB_USER, password=DB_PASSWORD, host=DB_HOST, port=DB_PORT, database=DB_NAME,
)

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------
class User(Base):
    __tablename__ = "users"

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    first_name: Mapped[str] = mapped_column(String(100))
    middle_name: Mapped[str | None] = mapped_column(String(100), nullable=True)
    last_name: Mapped[str] = mapped_column(String(100))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    phone: Mapped[str] = mapped_column(String(30), index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    date_of_birth: Mapped[date | None] = mapped_column(Date, nullable=True)
    address_line1: Mapped[str | None] = mapped_column(String(255), nullable=True)
    address_line2: Mapped[str | None] = mapped_column(String(255), nullable=True)
    city: Mapped[str | None] = mapped_column(String(100), nullable=True)
    state: Mapped[str | None] = mapped_column(String(100), nullable=True)
    postal_code: Mapped[str | None] = mapped_column(String(20), nullable=True)
    country: Mapped[str | None] = mapped_column(String(100), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())


class UserAttribute(Base):
    """Extra details a user gave the form assistant in the chat (course, household size, ...), kept so the same
    question is never asked twice. This is a SEPARATE table: the sign-up details in `users` are never changed
    by anything the chat collects."""
    __tablename__ = "user_attributes"
    __table_args__ = (UniqueConstraint("user_id", "normalized_key", name="uq_user_attribute_key"),)

    attribute_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.user_id", ondelete="CASCADE"),
                                               index=True)
    normalized_key: Mapped[str] = mapped_column(String(120))      # one of profile_match.ATTRIBUTES, e.g. "household_size"
    field_name: Mapped[str] = mapped_column(String(255))          # its readable name, e.g. "Household size"
    field_value: Mapped[str] = mapped_column(Text)
    value_type: Mapped[str] = mapped_column(String(20), default="string")   # string, integer, decimal, date, email, phone
    source: Mapped[str] = mapped_column(String(30), default="chat")
    verified: Mapped[bool] = mapped_column(default=True)          # the user typed or chose it themselves
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())

    user: Mapped["User"] = relationship(viewonly=True)   # whose fact this is (users.user_id); never written through here


class UserFieldValue(Base):
    """Every name, phone number, email... the user has used in a form through the chat, one row per distinct value.
    The next form offers them all (with the sign-up details) to pick from, or the user types a new one. A SEPARATE
    table: `users` is never changed by anything the chat collects."""
    __tablename__ = "user_field_values"
    __table_args__ = (UniqueConstraint("user_id", "kind", "value_key", name="uq_user_field_value"),)

    value_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.user_id", ondelete="CASCADE"),
                                               index=True)
    kind: Mapped[str] = mapped_column(String(40))            # what it is: full_name, first_name, email, phone, city...
    value: Mapped[str] = mapped_column(String(255))          # as the user typed it
    value_key: Mapped[str] = mapped_column(String(255))      # lower-cased, for telling "Vani" and "vani" apart from "Shivani"
    use_count: Mapped[int] = mapped_column(Integer, default=1)
    last_used: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class SavedResource(Base):
    """A resource a user saved with the heart button: the user's "My Plan".
    A copy of the main details is kept so My Plan still works when the map servers are down."""
    __tablename__ = "saved_resources"
    __table_args__ = (UniqueConstraint("user_id", "resource_id", name="uq_saved_user_resource"),)

    saved_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.user_id", ondelete="CASCADE"),
                                               index=True)
    resource_id: Mapped[str] = mapped_column(String(40))  # OpenStreetMap id, e.g. "node/123"
    name: Mapped[str] = mapped_column(String(255))
    category: Mapped[str | None] = mapped_column(String(100), nullable=True)
    service: Mapped[str | None] = mapped_column(String(100), nullable=True)
    address: Mapped[str | None] = mapped_column(Text, nullable=True)
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    phone: Mapped[str | None] = mapped_column(String(100), nullable=True)
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    website: Mapped[str | None] = mapped_column(Text, nullable=True)
    opening_hours: Mapped[str | None] = mapped_column(Text, nullable=True)
    source: Mapped[str | None] = mapped_column(String(100), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class Review(Base):
    """A user's star rating (1-5) and optional comment on a resource. One review per user per resource."""
    __tablename__ = "resource_reviews"
    __table_args__ = (
        UniqueConstraint("user_id", "resource_id", name="uq_review_user_resource"),
        CheckConstraint("rating BETWEEN 1 AND 5", name="ck_review_rating_range"),
    )

    review_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    resource_id: Mapped[str] = mapped_column(String(40), index=True)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.user_id", ondelete="CASCADE"),
                                               index=True)
    rating: Mapped[int] = mapped_column(SmallInteger)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())

class ApiUsage(Base):
    """Calls made to a paid-tier API this month, so the app can stop before a free limit is passed."""
    __tablename__ = "api_usage"

    provider: Mapped[str] = mapped_column(String(30), primary_key=True)
    kind: Mapped[str] = mapped_column(String(30), primary_key=True)    # "search" or "details"
    month: Mapped[str] = mapped_column(String(7), primary_key=True)    # "2026-09"
    calls: Mapped[int] = mapped_column(Integer, default=0)

class WebEnrichment(Base):
    """What was read from a place's own website (phone, email, hours...), kept for a while so the
    website is not fetched again on every visit."""
    __tablename__ = "web_enrichment"

    resource_id: Mapped[str] = mapped_column(String(40), primary_key=True)
    website: Mapped[str | None] = mapped_column(Text, nullable=True)
    data: Mapped[str] = mapped_column(Text)                       # JSON
    found_something: Mapped[bool] = mapped_column(default=False)
    fetched_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class SiteMetadata(Base):
    """What the site crawler found on a place's own website about booking an appointment online
    (a generic booking link, or one per specialty/department), kept for a while so the site is not
    crawled again on every visit."""
    __tablename__ = "site_metadata"

    resource_id: Mapped[str] = mapped_column(String(40), primary_key=True)
    website: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="ok")     # ok, no_website, unreachable, blocked
    has_appointment: Mapped[bool] = mapped_column(default=False)
    data: Mapped[str] = mapped_column(Text)                       # JSON: full crawler result incl. log
    crawled_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class FormMetadata(Base):
    """What the form crawler found on one specific booking/intake page: its fields (name, type, whether
    required) and whether it looks like a usable web form at all. Keyed by the page's own address (a
    resource can have several: one per specialty or doctor), kept for a while so a page already read
    for one user is not read again for the next."""
    __tablename__ = "form_metadata"

    form_id: Mapped[str] = mapped_column(String(64), primary_key=True)   # sha256(form_url)
    resource_id: Mapped[str] = mapped_column(String(40), index=True)
    form_url: Mapped[str] = mapped_column(Text)
    label: Mapped[str | None] = mapped_column(String(160), nullable=True)   # e.g. "Neurology - Dr. Jane Doe"
    usable: Mapped[bool] = mapped_column(default=False)
    data: Mapped[str] = mapped_column(Text)                       # JSON: fields, log, embed_url...
    crawled_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class AppointmentRequest(Base):
    """One "Form Runner" attempt: what we filled into a real intake form on a user's behalf, and whether
    it went on to be submitted. The chat presses Submit itself once the person says to; "submitted" here
    means the Form Runner saw the site accept it (its own confirmation when there was one, best-effort
    otherwise) - see form_runner.py for exactly what counts."""
    __tablename__ = "appointment_requests"

    request_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.user_id", ondelete="CASCADE"),
                                               index=True)
    resource_id: Mapped[str] = mapped_column(String(40), index=True)
    form_url: Mapped[str] = mapped_column(Text)
    label: Mapped[str | None] = mapped_column(String(160), nullable=True)
    values: Mapped[str] = mapped_column(Text)                     # JSON: field name -> value we filled in
    status: Mapped[str] = mapped_column(String(20), default="filled")   # filled, submitted, abandoned
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


# ---------------------------------------------------------------------------
# Connecting and creating what is missing
# ---------------------------------------------------------------------------
def ensure_database() -> bool:
    """Create the database if it does not exist yet. Returns True if it had to be created."""
    conn = psycopg2.connect(host=DB_HOST, port=DB_PORT, user=DB_USER, password=DB_PASSWORD,
                            dbname="postgres")  # the always-present maintenance database
    conn.autocommit = True  # CREATE DATABASE cannot run inside a transaction
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (DB_NAME,))
            if cur.fetchone():
                return False
            cur.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(DB_NAME)))
            log.warning("Database %r did not exist and was created.", DB_NAME)
            return True
    finally:
        conn.close()


def ensure_tables() -> list[str]:
    """Create any table that is missing (existing tables and their data are left untouched).
    Returns the names of the tables that were created."""
    existing = set(inspect(engine).get_table_names())
    missing = [t.name for t in Base.metadata.sorted_tables if t.name not in existing]
    if missing:
        Base.metadata.create_all(bind=engine, checkfirst=True)
        log.warning("Created missing table(s): %s", ", ".join(missing))
    if "user_attribute_details" not in inspect(engine).get_view_names():
        # a read-only view that shows each saved fact next to the person it belongs to (joins user_attributes to
        # users by user_id); it changes nothing in either table
        with engine.begin() as conn:
            conn.execute(text(
                "CREATE OR REPLACE VIEW user_attribute_details AS "
                "SELECT a.attribute_id, a.user_id, u.first_name, u.last_name, u.email, "
                "a.normalized_key, a.field_name, a.field_value, a.value_type, a.source, a.verified, a.updated_at "
                "FROM user_attributes a JOIN users u ON u.user_id = a.user_id"))
    return missing


def ensure_ready() -> None:
    """Make sure the database and every table exist. Safe to call repeatedly and cheap when
    everything is already there (it runs one catalog query)."""
    try:
        ensure_tables()
    except OperationalError:
        # the database is missing (or its connections went stale): create it, then retry once
        ensure_database()
        engine.dispose()
        ensure_tables()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
