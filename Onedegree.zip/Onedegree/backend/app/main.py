﻿import base64
import hashlib
import json
import logging
import os
import re
import threading
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlparse

import bcrypt
import jwt
from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import delete, func, select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from . import chat, form_crawler, form_runner, location, services, web_lookup
from .db import (AppointmentRequest, FormMetadata, Review, SavedResource, SessionLocal, SiteMetadata, User, UserAttribute,
                 UserFieldValue, WebEnrichment, ensure_database, ensure_ready, get_db)
from .location import OPTION_TAGS

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret")
JWT_EXPIRE_HOURS = int(os.getenv("JWT_EXPIRE_HOURS", "12"))

app = FastAPI(title="One Degree POC API")


@app.middleware("http")
async def no_cache_static(request, call_next):
    """Always revalidate frontend files so edits show up without a manual cache clear."""
    response = await call_next(request)
    if not request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-cache"
    return response


@app.on_event("startup")
def on_startup():
    ensure_database()  # create the database first if it is missing
    ensure_ready()     # then create any missing tables


class SignupIn(BaseModel):
    first_name: str = Field(min_length=1, max_length=100)
    middle_name: str | None = Field(default=None, max_length=100)
    last_name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    phone: str = Field(min_length=7, max_length=30)
    password: str = Field(min_length=6, max_length=128)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


def normalize_phone(p: str) -> str:
    return re.sub(r"[^\d+]", "", p)


def user_out(u: User) -> dict:
    return {
        "user_id": str(u.user_id),
        "name": u.first_name,
        "firstName": u.first_name,
        "middleName": u.middle_name,
        "lastName": u.last_name,
        "email": u.email,
        "phone": u.phone,
    }


def make_token(u: User) -> str:
    exp = datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRE_HOURS)
    return jwt.encode({"sub": str(u.user_id), "exp": exp}, JWT_SECRET, algorithm="HS256")


_STARTED_AT = datetime.now()


def _code_updated_at() -> datetime:
    """When any file of the backend was last changed."""
    files = list(Path(__file__).resolve().parent.glob("*.py"))
    return datetime.fromtimestamp(max((f.stat().st_mtime for f in files), default=0))


@app.get("/api/health")
def health(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    updated = _code_updated_at()
    return {"status": "ok", "database": "connected", "server_started": _STARTED_AT.isoformat(timespec="seconds"),
            "code_updated": updated.isoformat(timespec="seconds"),
            # True when the code on disk is newer than the code this server is running: restart the server
            "restart_needed": updated > _STARTED_AT}


@app.post("/api/signup")
def signup(data: SignupIn, db: Session = Depends(get_db)):
    pw_hash = bcrypt.hashpw(data.password.encode(), bcrypt.gensalt()).decode()
    user = User(
        first_name=data.first_name.strip(),
        middle_name=(data.middle_name or "").strip() or None,
        last_name=data.last_name.strip(),
        email=data.email.lower(),
        phone=normalize_phone(data.phone),
        password_hash=pw_hash,
    )
    ensure_ready()  # the database and the users table must exist before inserting
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="An account with this email already exists.")
    db.refresh(user)
    return {"token": make_token(user), "user": user_out(user)}


@app.post("/api/login")
def login(data: LoginIn, db: Session = Depends(get_db)):
    user = db.execute(select(User).where(User.email == data.email.lower())).scalars().first()
    if not user or not bcrypt.checkpw(data.password.encode(), user.password_hash.encode()):
        raise HTTPException(status_code=401, detail="Invalid email or password.")
    return {"token": make_token(user), "user": user_out(user)}


bearer = HTTPBearer(auto_error=False)


def current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(bearer),
    db: Session = Depends(get_db),
) -> User:
    unauthorized = HTTPException(status_code=401, detail="Please log in again.")
    if creds is None:
        raise unauthorized
    try:
        payload = jwt.decode(creds.credentials, JWT_SECRET, algorithms=["HS256"])
        user = db.get(User, uuid.UUID(payload["sub"]))
    except (jwt.PyJWTError, KeyError, ValueError):
        raise unauthorized
    if user is None or user.status != "active":
        raise unauthorized
    return user


class ProfileUpdateIn(BaseModel):
    first_name: str = Field(min_length=1, max_length=100)
    middle_name: str | None = Field(default=None, max_length=100)
    last_name: str = Field(min_length=1, max_length=100)
    phone: str = Field(min_length=7, max_length=30)
    current_password: str | None = None
    new_password: str | None = Field(default=None, min_length=6, max_length=128)


@app.get("/api/profile")
def get_profile(user: User = Depends(current_user)):
    return {"user": user_out(user)}


@app.put("/api/profile")
def update_profile(data: ProfileUpdateIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    user.first_name = data.first_name.strip()
    user.middle_name = (data.middle_name or "").strip() or None
    user.last_name = data.last_name.strip()
    user.phone = normalize_phone(data.phone)

    if data.new_password:
        if not data.current_password or not bcrypt.checkpw(
            data.current_password.encode(), user.password_hash.encode()
        ):
            raise HTTPException(status_code=400, detail="Current password is incorrect.")
        user.password_hash = bcrypt.hashpw(data.new_password.encode(), bcrypt.gensalt()).decode()

    db.commit()
    db.refresh(user)
    return {"user": user_out(user)}


def _require_india(lat: float, lng: float) -> None:
    """This service covers India only: a place anywhere else is refused, whatever the browser sent."""
    if not location.in_india(lat, lng):
        raise HTTPException(status_code=400, detail="This service works only for locations in India. "
                                                    "Please type a place in India in the search box.")


@app.get("/api/menu")
def menu(
    lat: float = Query(ge=-90, le=90),
    lng: float = Query(ge=-180, le=180),
    user: User = Depends(current_user),
):
    """Browse-resources menu limited to options that have results near the given location.
    The check runs in the background; poll until `done` is true (categories fill in as they finish)."""
    _require_india(lat, lng)
    return location.get_menu(lat, lng)

@app.get("/api/timezone")
def timezone_of(
    lat: float = Query(ge=-90, le=90),
    lng: float = Query(ge=-180, le=180),
    user: User = Depends(current_user),
):
    """The time zone at a spot (e.g. "Asia/Kolkata"): opening hours are in the place's own local time."""
    return {"timezone": _timezone_at(lat, lng)}


_tzfinder = None


def _timezone_at(lat: float, lng: float) -> str | None:
    global _tzfinder
    try:
        if _tzfinder is None:
            from timezonefinder import TimezoneFinder
            _tzfinder = TimezoneFinder()
        return _tzfinder.timezone_at(lat=lat, lng=lng)
    except Exception:
        return None


@app.get("/api/geocode")
def geocode(
    q: str = Query(min_length=1, max_length=120),
    near_lat: float | None = Query(default=None, ge=-90, le=90),
    near_lng: float | None = Query(default=None, ge=-180, le=180),
    user: User = Depends(current_user),
):
    """Coordinates for a typed place name. Spelling mistakes are corrected ("Hyderbad" -> Hyderabad);
    `corrected_to` is set when that happened."""
    near = (near_lat, near_lng) if near_lat is not None and near_lng is not None else None
    try:
        return location.geocode(q, near)
    except location.PlaceNotFound:
        raise HTTPException(status_code=404, detail=f"We couldn't find \u201c{q.strip()}\u201d in India. Please type a city or area in India.")
    except location.DiscoveryError:
        raise HTTPException(status_code=502, detail="Could not look up that location right now. Please try again.")

class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=800)


@app.post("/api/chat/parse")
def chat_parse(data: ChatIn, user: User = Depends(current_user)):
    """Work out the service and the place from a sentence typed in the home-page chat."""
    return chat.parse(data.message)


RESOURCE_ID = re.compile(r"^(node|way|relation)/[0-9]{1,15}$")  # an OpenStreetMap id


def valid_resource_id(rid: str) -> str:
    if not RESOURCE_ID.match(rid):
        raise HTTPException(status_code=400, detail="Invalid resource id.")
    return rid


def rating_summaries(db: Session, ids: list[str]) -> dict[str, tuple[float, int]]:
    """{resource_id: (average rating, number of ratings)} for the ids that have ratings."""
    if not ids:
        return {}
    rows = db.execute(
        select(Review.resource_id, func.avg(Review.rating), func.count(Review.review_id))
        .where(Review.resource_id.in_(ids)).group_by(Review.resource_id)
    ).all()
    return {rid: (round(float(avg), 1), int(n)) for rid, avg, n in rows}


def saved_ids(db: Session, user: User, ids: list[str]) -> set[str]:
    if not ids:
        return set()
    return set(db.execute(
        select(SavedResource.resource_id)
        .where(SavedResource.user_id == user.user_id, SavedResource.resource_id.in_(ids))
    ).scalars().all())


def decorate(db: Session, user: User, data: dict) -> dict:
    """Add each result's average rating and whether this user saved it. Copies the results, because
    the search data itself is cached and shared between users."""
    results = [dict(r) for r in data["results"]]
    ids = [r["id"] for r in results]
    ratings, saved = rating_summaries(db, ids), saved_ids(db, user, ids)
    for r in results:
        summary = ratings.get(r["id"])
        r["rating"] = summary[0] if summary else None
        r["rating_count"] = summary[1] if summary else 0
        r["saved"] = r["id"] in saved
    return {**data, "results": results}


@app.get("/api/search")
def search(
    lat: float = Query(ge=-90, le=90),
    lng: float = Query(ge=-180, le=180),
    option: str | None = Query(default=None, max_length=60),
    q: str | None = Query(default=None, max_length=800),
    category: str = Query(default="", max_length=60),
    user: User = Depends(current_user),
    db: Session = Depends(get_db),
):
    """Search near lat/lng: by menu `option`, or by typed text `q` (from the header search box)."""
    _require_india(lat, lng)
    try:
        if q and q.strip():
            data = location.search_text(q.strip(), lat, lng)
        elif option in OPTION_TAGS:
            data = location.search_places(option, category, lat, lng)
        else:
            raise HTTPException(status_code=400, detail="Unknown resource type.")
    except location.DiscoveryError as exc:
        raise HTTPException(status_code=502, detail=f"Search service unavailable: {exc}")
    return decorate(db, user, data)


# ---------------------------------------------------------------------------
# One resource: details (OpenStreetMap), website details, ratings and comments (our database)
# ---------------------------------------------------------------------------
@app.get("/api/resource")
def resource_details(id: str = Query(max_length=40), user: User = Depends(current_user)):
    rid = valid_resource_id(id)
    try:
        data = location.get_resource(rid)
    except location.DiscoveryError:
        raise HTTPException(status_code=502, detail="The map servers could not be reached right now.")
    if data is None:
        raise HTTPException(status_code=404, detail="This place could not be found on OpenStreetMap.")
    return data


WEB_TTL_FOUND = timedelta(days=14)
WEB_TTL_EMPTY = timedelta(days=3)
_web_locks: dict[str, threading.Lock] = {}


@app.get("/api/resource/web")
def resource_from_website(id: str = Query(max_length=40), search: bool = Query(default=True),
                          user: User = Depends(current_user), db: Session = Depends(get_db)):
    """What OpenStreetMap lacks for a place: phone, email, opening hours and a rating.
    1) its OWN website (and Wikidata) are read; 2) if a search tool is set up, the place is looked up
    there to find its website, phone number and rating. The website always comes from OpenStreetMap or
    from a search result, never from the browser. `search=false` skips the search tools (used for the
    background phone-number fill on result cards, so no search-tool call is spent on every card)."""
    rid = valid_resource_id(id)
    row = db.get(WebEnrichment, rid)
    if row and not search:
        # Only the quick card-level read (the phone number on the results list) may reuse a saved answer.
        # The details page (search=true) always looks again, so it never shows something out of date, such
        # as a place saved before addresses, hours or reviews were being read.
        age = datetime.now() - row.fetched_at
        cached = json.loads(row.data)
        if "address" in cached and age < (WEB_TTL_FOUND if row.found_something else WEB_TTL_EMPTY):   # older rows never looked for an address
            return {**cached, "cached": True, "fetched_at": row.fetched_at.isoformat()}

    try:
        place = location.get_resource(rid)
    except location.DiscoveryError:
        raise HTTPException(status_code=502, detail="The map servers could not be reached right now.")
    if not place:
        raise HTTPException(status_code=404, detail="This place could not be found on OpenStreetMap.")
    tags = place.get("tags") or {}
    site_known = bool(web_lookup.normalize_website(tags.get("website") or tags.get("contact:website") or tags.get("url") or "")
                      or tags.get("wikidata"))
    search_ready = search and bool(web_lookup.configured())
    if not site_known and not search_ready:
        return {"website": None, "phones": [], "emails": [], "opening_hours": None, "rating": None,
                "rating_count": None, "sources": {}, "pages": [], "hours_by_ai": False,
                "problem": "No website is listed for this place.", "cached": False}

    with _web_locks.setdefault(rid, threading.Lock()):  # two people opening the same place read the site once
        data = web_lookup.enrich(tags)
        if data["rating"] is not None:
            data["rating_source"] = "the place's own website"
        place_has_address = bool(place.get("address"))
        if place_has_address:
            data["address"] = None   # OpenStreetMap already has one: the website's is not needed
        elif data.get("address"):
            data["address_source"] = data["sources"].get("address") or "the place's own website"
        lacking = ({"website", "listing"} if not data["website"] else set()) | ({"phone"} if not data["phones"] else set()) \
            | ({"address"} if not place_has_address and not data.get("address") else set()) \
            | ({"opening_hours"} if not data.get("opening_hours") and not tags.get("opening_hours") else set()) \
            | ({"email"} if not data["emails"] else set()) | ({"rating"} if data["rating"] is None else set()) \
            | {"reviews"}   # the comments on the Google Maps listing are always asked for (Serper / SerpAPI)
        need = bool(lacking)
        if search_ready and need and place.get("lat") is not None:
            hint = tags.get("addr:city") or tags.get("addr:suburb") or tags.get("addr:street") or ""
            hit = web_lookup.lookup_place(place["name"], place["lat"], place["lng"], hint, need=lacking) or {}
            fields = []
            rejected = None
            found_by = None

            # 1) the place's own website, if OpenStreetMap had none: from the search tools, else from the
            #    website finder, which uses every free source and makes each candidate prove it is this place
            candidate = hit.get("website") if not data["website"] else None
            if not candidate and not data["website"] and search:
                finding = web_lookup.find(place["name"], place["lat"], place["lng"], tags, hint)
                if finding:
                    candidate, found_by = finding["url"], f"{finding['source']} ({'; '.join(finding['evidence'])})"
            if candidate:
                found_site = web_lookup.enrich({**tags, "website": candidate})   # read the website that was found
                check = found_site.get("website_check") or {}
                if check.get("status") in ("unreachable", "unmatched"):
                    # a result that does not work, or is not about this place, is never used
                    rejected = {"url": candidate, "reason": check.get("detail")}
                else:
                    data = found_site
                    data["website"] = candidate
                    fields.append("website")
                    if data["rating"] is not None:
                        data["rating_source"] = "the place's own website"

            # 2) everything else the search tools returned, for what is still missing
            if hit.get("phone") and not data["phones"] and not (tags.get("phone") or tags.get("contact:phone")):
                data["phones"] = [hit["phone"]]
                fields.append("phone")
            if hit.get("email") and not data["emails"] and not (tags.get("email") or tags.get("contact:email")):
                data["emails"] = [hit["email"]]
                fields.append("email")
            if hit.get("rating") and data["rating"] is None:
                data["rating"], data["rating_count"] = round(hit["rating"], 1), hit["rating_count"]
                data["rating_source"] = hit.get("rating_from") or "web search results"
                fields.append("rating")
            if hit.get("opening_hours") and not data.get("opening_hours") and not tags.get("opening_hours"):
                data["opening_hours"] = hit["opening_hours"]   # already in OpenStreetMap's "Mo-Fr 09:00-17:00" style
                data["sources"]["opening_hours"] = "Google Maps"
                data["hours_by_ai"] = False
                fields.append("opening_hours")
            if hit.get("address") and not place_has_address and not data.get("address"):
                data["address"] = hit["address"]
                data["address_source"] = "Google Maps" if hit.get("provider") in web_lookup.GOOGLE_MAPS else "web search results"
                fields.append("address")
            if hit.get("reviews"):
                data["reviews"] = hit["reviews"]
                data["reviews_source"] = "Google Maps"
                fields.append("reviews")

            # 3) still no website of its own: a directory page about this place (never its email address)
            if hit.get("listing") and not data["website"]:
                page = web_lookup.enrich({**tags, "website": hit["listing"]})
                if (page.get("website_check") or {}).get("status") not in ("unreachable", "unmatched"):
                    host = (urlparse(hit["listing"]).hostname or "").removeprefix("www.")
                    data["listing"] = {"url": hit["listing"], "host": host}
                    if page.get("opening_hours") and not data.get("opening_hours") and not tags.get("opening_hours"):
                        data["opening_hours"] = page["opening_hours"]
                        data["sources"]["opening_hours"] = hit["listing"]
                        fields.append("opening_hours")
                    if page.get("address") and not place_has_address and not data.get("address"):
                        data["address"], data["address_source"] = page["address"], f"{host} listing"
                        fields.append("address")
                    if page.get("rating") is not None and data["rating"] is None:
                        data["rating"], data["rating_count"] = page["rating"], page.get("rating_count")
                        data["rating_source"] = f"{host} listing"
                        fields.append("rating")
                    if page.get("phones") and not data["phones"]:
                        data["phones"] = page["phones"][:2]
                        data["sources"]["phones"] = hit["listing"]
                        fields.append("phone")
                    fields.append("listing")

            data["search"] = {"provider": hit.get("provider") or ("website finder" if found_by else None), "fields": fields,
                              "rejected_website": rejected, "website_found_by": found_by}
        if place_has_address:
            data["address"] = None   # (the website search above may have re-read a site: keep OpenStreetMap's address)
        elif data.get("address") and not data.get("address_source"):
            data["address_source"] = ("the place's own website" if data["sources"].get("address") else "web search results")
        if not search and web_lookup.configured() and need:
            data["search_pending"] = True   # the search tools were skipped: the details page will run them
    found = bool(data["phones"] or data["emails"] or data["opening_hours"] or data["rating"] or data.get("address")
                 or data.get("search", {}).get("fields")
                 or data.get("website_check"))
    ensure_ready()
    db.merge(WebEnrichment(resource_id=rid, website=data["website"], data=json.dumps(data),
                           found_something=found, fetched_at=datetime.now()))
    db.commit()
    return {**data, "cached": False, "fetched_at": datetime.now().isoformat()}


_site_crawl_locks: dict[str, threading.Lock] = {}


@app.get("/api/resource/site-crawl")
def resource_site_crawl(id: str = Query(max_length=40), user: User = Depends(current_user),
                        db: Session = Depends(get_db)):
    """The "Book appointment" site crawler (form_crawler.py): reads a place's own website looking for
    a way to book an appointment online, one generic link or one per specialty/department, and lists
    the forms it finds. Crawled fresh on every visit; the result is saved in site_metadata only so the
    form endpoints below know which links this crawl found (it is never served back as a cache)."""
    rid = valid_resource_id(id)

    try:
        place = location.get_resource(rid)
    except location.DiscoveryError:
        raise HTTPException(status_code=502, detail="The map servers could not be reached right now.")
    if not place:
        raise HTTPException(status_code=404, detail="This place could not be found on OpenStreetMap.")
    tags = place.get("tags") or {}
    website = web_lookup.normalize_website(tags.get("website") or tags.get("contact:website") or tags.get("url") or "")
    if not website:
        # OpenStreetMap has no website tag for this place: reuse whatever /api/resource/web already
        # found for it (Wikidata, or a search tool), instead of looking that up again here.
        web_row = db.get(WebEnrichment, rid)
        if web_row and web_row.website:
            website = web_row.website

    if not website:
        data = {"website": None, "status": "no_website", "has_appointment": False, "appointment_url": None,
               "requires_login": False, "specialties": [], "pages_crawled": [], "forms": [], "log": []}
    else:
        with _site_crawl_locks.setdefault(rid, threading.Lock()):
            data = form_crawler.crawl(website, place.get("name") or "", place.get("service"), place.get("category"))

    ensure_ready()
    db.merge(SiteMetadata(resource_id=rid, website=data.get("website"), status=data.get("status", "ok"),
                          has_appointment=bool(data.get("has_appointment")), data=json.dumps(data),
                          crawled_at=datetime.now()))
    db.commit()
    return {**data, "cached": False, "crawled_at": datetime.now().isoformat()}


_form_crawl_locks: dict[str, threading.Lock] = {}


def _known_booking_urls(site_data: dict) -> set[str]:
    """Every booking URL the site crawler already vetted for this place (the generic link, each
    specialty's link, and each doctor's own link) - the form crawler may only be pointed at one of
    these, never at an address the client makes up."""
    urls = set()
    if site_data.get("appointment_url"):
        urls.add(site_data["appointment_url"])
    for form in site_data.get("forms") or []:
        if form.get("url"):
            urls.add(form["url"])
    for sp in site_data.get("specialties") or []:
        if sp.get("url"):
            urls.add(sp["url"])
        for doc in sp.get("doctors") or []:
            if doc.get("url"):
                urls.add(doc["url"])
    return urls


@app.get("/api/resource/form-crawl")
def resource_form_crawl(id: str = Query(max_length=40), url: str = Query(max_length=500),
                        label: str | None = Query(default=None, max_length=160),
                        user: User = Depends(current_user), db: Session = Depends(get_db)):
    """The "Form Crawler" (form_crawler.py): reads one specific booking page - a URL the site crawler
    already found for this place - and works out what its intake form asks for. Read fresh each time;
    the result is saved in form_metadata (keyed by the page's address) for the prefill and run steps."""
    rid = valid_resource_id(id)
    site_row = db.get(SiteMetadata, rid)
    if not site_row:
        raise HTTPException(status_code=404, detail="Run the site crawler for this place first.")
    if url not in _known_booking_urls(json.loads(site_row.data)):
        raise HTTPException(status_code=400, detail="This booking link was not found by the site crawler for this place.")

    form_id = hashlib.sha256(url.encode()).hexdigest()
    with _form_crawl_locks.setdefault(form_id, threading.Lock()):
        data = form_crawler.crawl_form(url)

    ensure_ready()
    db.merge(FormMetadata(form_id=form_id, resource_id=rid, form_url=data.get("form_url", url), label=label,
                          usable=bool(data.get("usable")), data=json.dumps(data), crawled_at=datetime.now()))
    db.commit()
    return {**data, "cached": False, "crawled_at": datetime.now().isoformat()}


def _form_row_or_404(db: Session, rid: str, url: str) -> FormMetadata:
    site_row = db.get(SiteMetadata, rid)
    if not site_row or url not in _known_booking_urls(json.loads(site_row.data)):
        raise HTTPException(status_code=400, detail="This booking link was not found by the site crawler for this place.")
    form_row = db.get(FormMetadata, hashlib.sha256(url.encode()).hexdigest())
    if not form_row:
        raise HTTPException(status_code=404, detail="Run the form crawler on this page first.")
    return form_row


@app.get("/api/resource/form-prefill")
def resource_form_prefill(id: str = Query(max_length=40), url: str = Query(max_length=500),
                          label: str | None = Query(default=None, max_length=160),
                          user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Profile matching (services.py): lines up the fields form_crawler found on one page with
    what this user already told us (name, phone, email...), so only what is genuinely missing needs
    to be asked for before the Form Runner fills the page in."""
    rid = valid_resource_id(id)
    form_row = _form_row_or_404(db, rid, url)
    form_data = json.loads(form_row.data)
    saved = {a.normalized_key: a.field_value for a in db.execute(
        select(UserAttribute).where(UserAttribute.user_id == user.user_id)).scalars().all()}
    history: dict[str, list[str]] = {}
    for row in db.execute(select(UserFieldValue).where(UserFieldValue.user_id == user.user_id)
                          .order_by(UserFieldValue.last_used.desc())).scalars().all():
        history.setdefault(row.kind, []).append(row.value)   # row.kind is the concept: phone, full_name, x_blood_group...
    return {"usable": form_data.get("usable", False),
           "fields": services.match_fields(user, form_data.get("fields") or [], label, saved=saved, history=history)}


class FieldValueIn(BaseModel):
    kind: str | None = Field(default=None, max_length=40)   # what the crawler took the field to be (phone, full_name...)
    label: str = Field(default="", max_length=255)
    name: str = Field(default="", max_length=255)
    type: str = Field(default="", max_length=30)
    value: str = Field(min_length=1, max_length=255)


class FieldValuesIn(BaseModel):
    items: list[FieldValueIn] = Field(max_length=60)


@app.post("/api/profile/field-values")
def save_field_values(data: FieldValuesIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Remembers the names, phone numbers, emails... used in a form, each distinct value once, so the next form can
    offer them all to pick from. `user_field_values` only - `users` is never touched. Sensitive answers are refused."""
    ensure_ready()
    saved = 0
    for item in data.items:
        kind = services.concept_key(item.kind, item.label, item.name, item.type)   # what it is about, not what this form calls it
        if not kind or not services.remembered_ok(item.kind, item.label, item.value, item.name, item.type):
            continue
        value = re.sub(r"\s+", " ", item.value).strip()
        row = db.execute(select(UserFieldValue).where(UserFieldValue.user_id == user.user_id, UserFieldValue.kind == kind,
                                                      UserFieldValue.value_key == value.lower())).scalars().first()
        if row:
            row.use_count, row.last_used = (row.use_count or 0) + 1, datetime.now()
        else:
            db.add(UserFieldValue(user_id=user.user_id, kind=kind, value=value, value_key=value.lower()))
        db.flush()   # so the same value later in this list (a Name and a Patient Name) finds this row instead of adding another
        saved += 1
    db.commit()
    return {"saved": saved}


class AttributeIn(BaseModel):
    label: str = Field(min_length=1, max_length=255)     # the question as the form asked it
    value: str = Field(min_length=1, max_length=1000)
    type: str | None = Field(default=None, max_length=20)  # the form field's type: text, tel, email, date, select...


class AttributesIn(BaseModel):
    items: list[AttributeIn] = Field(max_length=60)


@app.get("/api/profile/attributes")
def get_attributes(user: User = Depends(current_user), db: Session = Depends(get_db)):
    """The extra details this user gave the form assistant. (The sign-up details are in /api/profile.)"""
    rows = db.execute(select(UserAttribute).where(UserAttribute.user_id == user.user_id)
                      .order_by(UserAttribute.field_name)).scalars().all()
    return {"items": [{"key": r.normalized_key, "label": r.field_name, "value": r.field_value, "type": r.value_type,
                       "source": r.source, "updated_at": r.updated_at.isoformat()} for r in rows]}


@app.post("/api/profile/attributes")
def save_attributes(data: AttributesIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Saves extra details the user gave in the form assistant chat, so the same question is not asked again.
    They go into `user_attributes` only - the `users` table (the sign-up details) is never touched. One-time
    codes, captchas, passwords and identity numbers are refused."""
    ensure_ready()
    saved, skipped = 0, 0
    for item in data.items:
        # only the lasting facts listed in services.ATTRIBUTES are kept (household size, income, employment
        # status...); free text, form-specific answers, sensitive data and anything already in `users` are not
        concept = services.canonical_attribute(item.label, item.type or "")
        value = services.clean_value(item.value, concept[2]) if concept else None
        if not concept or not value:
            skipped += 1
            continue
        key, name, vtype = concept
        row = db.execute(select(UserAttribute).where(UserAttribute.user_id == user.user_id,
                                                     UserAttribute.normalized_key == key)).scalars().first()
        if row:
            row.field_name, row.field_value, row.value_type, row.source, row.verified = name, value, vtype, "chat", True
        else:
            db.add(UserAttribute(user_id=user.user_id, normalized_key=key, field_name=name, field_value=value,
                                 value_type=vtype, source="chat", verified=True))
        saved += 1
    db.commit()
    return {"saved": saved, "skipped": skipped}


@app.delete("/api/profile/attributes")
def delete_attribute(key: str = Query(max_length=120), user: User = Depends(current_user), db: Session = Depends(get_db)):
    db.execute(delete(UserAttribute).where(UserAttribute.user_id == user.user_id, UserAttribute.normalized_key == key))
    db.commit()
    return {"deleted": key}


def _clean_values(values: dict) -> dict[str, str]:
    return {str(k)[:80]: str(v)[:300] for k, v in (values or {}).items() if isinstance(v, str) and v.strip()}


class FormSessionIn(BaseModel):
    resource_id: str = Field(max_length=40)
    url: str = Field(max_length=500)
    label: str | None = Field(default=None, max_length=160)
    values: dict[str, str] = Field(default_factory=dict)
    fields: list[dict] = Field(default_factory=list, max_length=80)   # {name, label, kind} of each question the chat asked


class FormOptionsIn(BaseModel):
    name: str = Field(max_length=80)


class FormSubmitIn(BaseModel):
    values: dict[str, str] = Field(default_factory=dict)   # corrected values, when the form rejected some


@app.post("/api/resource/form-session")
def form_session_start(data: FormSessionIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Opens the form in a browser window on this machine and fills it in with `values`, but does NOT submit.
    The person presses "Submit the form" in the chat when they are ready (see form_session_submit)."""
    rid = valid_resource_id(data.resource_id)
    _form_row_or_404(db, rid, data.url)   # only ever a page the form crawler already vetted
    values = _clean_values(data.values)
    if not values:
        raise HTTPException(status_code=400, detail="Nothing to fill in: no values were given.")
    ensure_ready()
    req = AppointmentRequest(user_id=user.user_id, resource_id=rid, form_url=data.url, label=data.label,
                             values=json.dumps(values), status="filled")
    db.add(req)
    db.commit()
    db.refresh(req)

    session = form_runner.open_session(data.url, str(user.user_id))
    session.request_id, session.form_label = req.request_id, (data.label or "your appointment")
    session.meta = [{"name": str(f.get("name", ""))[:80], "label": str(f.get("label") or "")[:160], "kind": f.get("kind")}
                    for f in data.fields if isinstance(f, dict)]
    opened = session.call("open", timeout=70)
    if opened.get("status") != "ok":
        form_runner.close_session(session.id, str(user.user_id))
        raise HTTPException(status_code=502, detail=opened.get("message") or "Could not open the form.")
    filled = session.call("fill", {"values": values})
    return {"session_id": session.id, "request_id": req.request_id, "filled_fields": filled.get("filled_fields", []),
            "by_hand": filled.get("by_hand", [])}


@app.post("/api/resource/form-session/{sid}/options")
def form_session_options(sid: str, data: FormOptionsIn, user: User = Depends(current_user)):
    """The choices one dropdown of the open form offers right now (dependent dropdowns - city, then hospital,
    then doctor - fill in only after the earlier one is chosen)."""
    session = form_runner.get_session(sid, str(user.user_id))
    if session is None:
        raise HTTPException(status_code=404, detail="That form is no longer open. Please start it again.")
    return session.call("options", {"name": data.name}, timeout=40)


@app.post("/api/resource/form-session/{sid}/preflight")
def form_session_preflight(sid: str, data: FormSubmitIn, user: User = Depends(current_user)):
    """Reads the open form again right now and checks every answer against the fields' own rules (required,
    format, length, allowed choices) BEFORE anything is submitted. Answers that only need reshaping are fixed and
    filled in; `problems` lists what the person has to correct or add, so the form is not rejected afterwards."""
    session = form_runner.get_session(sid, str(user.user_id))
    if session is None:
        raise HTTPException(status_code=404, detail="That form is no longer open. Please start it again.")
    return session.call("preflight", {"values": _clean_values(data.values)}, timeout=60)


class FormFileIn(BaseModel):
    name: str = Field(max_length=80)                   # the form's file field
    filename: str = Field(max_length=200)
    content_base64: str = Field(max_length=7_500_000)  # about 5 MB of file


@app.post("/api/resource/form-session/{sid}/file")
def form_session_file(sid: str, data: FormFileIn, user: User = Depends(current_user)):
    """Attaches a file the person picked in the chat (a CV...) to the open form. Passed straight to the browser
    window; never written to disk or the database."""
    session = form_runner.get_session(sid, str(user.user_id))
    if session is None:
        raise HTTPException(status_code=404, detail="That form is no longer open. Please start it again.")
    try:
        raw = base64.b64decode(data.content_base64, validate=True)
    except Exception:
        raise HTTPException(status_code=400, detail="That file could not be read.")
    if not raw or len(raw) > 5_000_000:
        raise HTTPException(status_code=400, detail="Please pick a file under 5 MB.")
    filename = re.sub(r"[^\w.\- ]", "_", data.filename)[:100] or "file"
    return session.call("attach", {"name": data.name, "filename": filename, "data": raw}, timeout=40)


@app.post("/api/resource/form-session/{sid}/handoff")
def form_session_handoff(sid: str, data: FormSubmitIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """For a form the chat cannot finish (a captcha only a person can tick): opens the same form in a real browser
    window on this machine, filled in with the answers so far, and leaves it to the person to tick the box and press
    Submit themselves. Nothing is submitted here."""
    session = form_runner.get_session(sid, str(user.user_id))
    if session is None:
        raise HTTPException(status_code=404, detail="That form is no longer open. Please start it again.")
    req = db.get(AppointmentRequest, getattr(session, "request_id", None))
    values = {**(json.loads(req.values) if req and req.values else {}), **_clean_values(data.values)}
    window = form_runner.open_session(session.url, str(user.user_id), headed=True)
    window.meta = session.meta
    opened = window.call("open", timeout=70)
    if opened.get("status") != "ok":
        form_runner.close_session(window.id, str(user.user_id))
        raise HTTPException(status_code=502, detail=opened.get("message") or "Could not open the window.")
    window.call("fill", {"values": values})
    window.call("captcha", {})   # brings the captcha box into view
    return {"status": "ok"}


class CaptchaClickIn(BaseModel):
    x: float | None = Field(default=None, ge=0, le=1)   # where the person clicked in the picture, as a fraction of its size
    y: float | None = Field(default=None, ge=0, le=1)


@app.post("/api/resource/form-session/{sid}/captcha")
def form_session_captcha(sid: str, data: CaptchaClickIn, user: User = Depends(current_user)):
    """A picture of the form's "I'm not a robot" box. With x and y, the person's click on that picture is passed to
    the box first. The box is never solved by this server: the person does it, in the chat."""
    session = form_runner.get_session(sid, str(user.user_id))
    if session is None:
        raise HTTPException(status_code=404, detail="That form is no longer open. Please start it again.")
    click = {"x": data.x, "y": data.y} if data.x is not None and data.y is not None else None
    return session.call("captcha", {"click": click}, timeout=40)


@app.post("/api/resource/form-session/{sid}/set")
def form_session_set(sid: str, data: FormSubmitIn, user: User = Depends(current_user)):
    """Fills in some more values of the open form (for example a dropdown answered in the chat), without submitting."""
    session = form_runner.get_session(sid, str(user.user_id))
    if session is None:
        raise HTTPException(status_code=404, detail="That form is no longer open. Please start it again.")
    return session.call("fill", {"values": _clean_values(data.values)}, timeout=30)


@app.post("/api/resource/form-session/{sid}/submit")
def form_session_submit(sid: str, data: FormSubmitIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Presses the form's Submit button and reports what happened: {"status": "success" | "errors" | "unknown" |
    "error"}. When the form rejects a field, `errors` says which and why, so the chat can ask for a new value; call
    this again with the corrected `values`."""
    session = form_runner.get_session(sid, str(user.user_id))
    if session is None:
        raise HTTPException(status_code=404, detail="That browser window is no longer open. Please start the form again.")
    values = _clean_values(data.values)
    result = session.call("submit", {"values": values}, timeout=220)   # the runner itself waits up to ~3 minutes for a confirmation
    req = db.get(AppointmentRequest, getattr(session, "request_id", None))
    if req and values:
        merged = {**json.loads(req.values), **values}
        req.values = json.dumps(merged)
    if result.get("status") == "success" and req:
        req.status, req.submitted_at = "submitted", datetime.now()
        threading.Timer(20, form_runner.close_session, args=(sid, str(user.user_id))).start()   # leave the window a moment
    db.commit()
    result["request_id"] = getattr(session, "request_id", None)
    return result


@app.delete("/api/resource/form-session/{sid}")
def form_session_close(sid: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    session = form_runner.get_session(sid, str(user.user_id))
    if session is not None:
        req = db.get(AppointmentRequest, getattr(session, "request_id", None))
        if req and req.status == "filled":
            req.status = "abandoned"
            db.commit()
    form_runner.close_session(sid, str(user.user_id))
    return {"closed": True}


class ReviewIn(BaseModel):
    resource_id: str = Field(max_length=40)
    rating: int = Field(ge=1, le=5)
    comment: str | None = Field(default=None, max_length=1000)


def review_payload(db: Session, user: User, rid: str) -> dict:
    rows = db.execute(
        select(Review, User.first_name, User.last_name)
        .join(User, User.user_id == Review.user_id)
        .where(Review.resource_id == rid).order_by(Review.updated_at.desc()).limit(50)
    ).all()
    summary = rating_summaries(db, [rid]).get(rid)
    return {
        "resource_id": rid,
        "rating": summary[0] if summary else None,
        "rating_count": summary[1] if summary else 0,
        "saved": rid in saved_ids(db, user, [rid]),
        "reviews": [{
            "review_id": r.review_id, "rating": r.rating, "comment": r.comment or "",
            "author": f"{first} {last[:1]}." if last else first,  # first name and last initial only
            "mine": r.user_id == user.user_id, "date": r.updated_at.date().isoformat(),
        } for r, first, last in rows],
    }


@app.get("/api/resource/reviews")
def get_reviews(id: str = Query(max_length=40), user: User = Depends(current_user), db: Session = Depends(get_db)):
    return review_payload(db, user, valid_resource_id(id))


@app.post("/api/resource/reviews")
def save_review(data: ReviewIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Create or update the current user's rating and comment for a resource."""
    rid = valid_resource_id(data.resource_id)
    ensure_ready()
    review = db.execute(select(Review).where(Review.user_id == user.user_id, Review.resource_id == rid)).scalars().first()
    comment = (data.comment or "").strip() or None
    if review:
        review.rating, review.comment = data.rating, comment
    else:
        db.add(Review(resource_id=rid, user_id=user.user_id, rating=data.rating, comment=comment))
    db.commit()
    return review_payload(db, user, rid)


@app.delete("/api/resource/reviews")
def delete_review(id: str = Query(max_length=40), user: User = Depends(current_user), db: Session = Depends(get_db)):
    rid = valid_resource_id(id)
    db.execute(delete(Review).where(Review.user_id == user.user_id, Review.resource_id == rid))
    db.commit()
    return review_payload(db, user, rid)


# ---------------------------------------------------------------------------
# My Plan: resources the user saved with the heart button
# ---------------------------------------------------------------------------
class PlanIn(BaseModel):
    resource_id: str = Field(max_length=40)
    name: str = Field(min_length=1, max_length=255)
    category: str | None = Field(default=None, max_length=100)
    service: str | None = Field(default=None, max_length=100)
    address: str | None = Field(default=None, max_length=500)
    lat: float | None = Field(default=None, ge=-90, le=90)
    lng: float | None = Field(default=None, ge=-180, le=180)
    phone: str | None = Field(default=None, max_length=100)
    email: str | None = Field(default=None, max_length=255)
    website: str | None = Field(default=None, max_length=500)
    opening_hours: str | None = Field(default=None, max_length=500)
    source: str | None = Field(default=None, max_length=100)


def plan_item(s: SavedResource, ratings: dict) -> dict:
    summary = ratings.get(s.resource_id)
    return {
        "id": s.resource_id, "name": s.name, "category": s.category, "service": s.service, "address": s.address,
        "lat": s.latitude, "lng": s.longitude, "phone": s.phone, "email": s.email, "website": s.website,
        "opening_hours": s.opening_hours, "source": s.source, "saved_at": s.created_at.isoformat(),
        "rating": summary[0] if summary else None, "rating_count": summary[1] if summary else 0,
    }


@app.get("/api/plan")
def get_plan(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.execute(select(SavedResource).where(SavedResource.user_id == user.user_id)
                      .order_by(SavedResource.created_at.desc())).scalars().all()
    ratings = rating_summaries(db, [s.resource_id for s in rows])
    return {"items": [plan_item(s, ratings) for s in rows]}


@app.post("/api/plan")
def add_to_plan(data: PlanIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    rid = valid_resource_id(data.resource_id)
    ensure_ready()
    website = data.website if data.website and re.match(r"^https?://", data.website, re.I) else None
    fields = dict(name=data.name.strip(), category=data.category, service=data.service, address=data.address,
                  latitude=data.lat, longitude=data.lng, phone=data.phone, email=data.email, website=website,
                  opening_hours=data.opening_hours, source=data.source)
    item = db.execute(select(SavedResource).where(SavedResource.user_id == user.user_id,
                                                  SavedResource.resource_id == rid)).scalars().first()
    if item:
        for k, v in fields.items():
            setattr(item, k, v)
    else:
        db.add(SavedResource(user_id=user.user_id, resource_id=rid, **fields))
    db.commit()
    return {"saved": True, "resource_id": rid}


@app.delete("/api/plan")
def remove_from_plan(id: str = Query(max_length=40), user: User = Depends(current_user), db: Session = Depends(get_db)):
    rid = valid_resource_id(id)
    db.execute(delete(SavedResource).where(SavedResource.user_id == user.user_id, SavedResource.resource_id == rid))
    db.commit()
    return {"saved": False, "resource_id": rid}


@app.get("/api/usage")
def api_usage(user: User = Depends(current_user)):
    """Which AI models and search tools are set up and how much of each free allowance is used."""
    return {"llm": services.llm_status(), "search": web_lookup.status()}

# Serve the static frontend (must be mounted last)
FRONTEND_DIR = Path(__file__).resolve().parent.parent.parent / "frontend"
app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
