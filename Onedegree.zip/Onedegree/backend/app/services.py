"""Small, independent support services the routes and crawlers call directly:
  * a free Hugging Face language model, tried one after another (used only as a fallback to read
    plain-text opening hours, and to help the site crawler decide whether a site offers online booking)
  * profile matching: lining up a form's fields (from form_crawler.py) with what we already know about
    the user, so the Form Runner only ever has to ask for what is genuinely missing

    HF_TOKEN=hf_...          https://huggingface.co/settings/tokens  (a token that can call Inference Providers)
    HF_MODELS=a/b,c/d        optional: your own list, best first
    HF_MONTHLY_LIMIT=300     optional
"""
import logging
import os
import re
import time

import httpx
from sqlalchemy import text

from .db import User, engine

log = logging.getLogger("onedegree.services")

# ---------------------------------------------------------------------------
# Hugging Face: free language models, tried one after another. The site only uses a model to read
# plain-text opening hours from a website and to help the site crawler read a page, so a failure is
# never fatal: if no model can answer, that step is skipped. A model that answers "payment required"
# (its provider is not covered by the free credit), "not supported" or an error is left alone for a
# while and the next one is tried. All Hugging Face models share ONE small monthly free credit (about
# $0.10), so the site also counts its own calls and stops at HF_MONTHLY_LIMIT (default 300) to stay
# inside it.
# ---------------------------------------------------------------------------
HF_URL = os.getenv("HF_BASE_URL", "https://router.huggingface.co/v1").rstrip("/")
# Tested on the real task (reading opening hours). Best first.
DEFAULT_MODELS = (
    "meta-llama/Llama-4-Scout-17B-16E-Instruct,"
    "meta-llama/Llama-3.1-8B-Instruct,"
    "Qwen/Qwen3-4B-Instruct-2507"
)
LLM_TIMEOUT_S = 25

_cooldown: dict[str, tuple[float, str]] = {}   # model -> (until, reason)


def token() -> str:
    return os.getenv("HF_TOKEN", "").strip()


def models() -> list[str]:
    raw = os.getenv("HF_MODELS", "").strip() or DEFAULT_MODELS
    return [m.strip() for m in raw.split(",") if m.strip()]


def configured() -> list[str]:
    """The models that can be used (none without a token)."""
    return models() if token() else []


def _limit() -> int:
    try:
        return int(os.getenv("HF_MONTHLY_LIMIT", "300"))
    except ValueError:
        return 300


def _month() -> str:
    return time.strftime("%Y-%m", time.gmtime())


def _reserve() -> bool:
    """Count one call BEFORE making it; False once this month's allowance is used up."""
    try:
        with engine.begin() as conn:
            row = conn.execute(text(
                "INSERT INTO api_usage (provider, kind, month, calls) VALUES ('huggingface', 'llm-month', :m, 1) "
                "ON CONFLICT (provider, kind, month) DO UPDATE SET calls = api_usage.calls + 1 "
                "WHERE api_usage.calls < :limit RETURNING calls"),
                {"m": _month(), "limit": _limit()}).first()
        return row is not None
    except Exception:
        return False  # cannot count: do not risk passing the free credit


def _refund() -> None:
    """A call that was refused (for example HTTP 402) was not billed, so it does not count."""
    try:
        with engine.begin() as conn:
            conn.execute(text("UPDATE api_usage SET calls = GREATEST(calls - 1, 0) "
                              "WHERE provider = 'huggingface' AND kind = 'llm-month' AND month = :m"), {"m": _month()})
    except Exception:
        pass


def llm_status() -> dict:
    """The models in use and how much of this month's allowance is used (for /api/usage)."""
    try:
        with engine.connect() as conn:
            used = conn.execute(text("SELECT calls FROM api_usage WHERE provider = 'huggingface' "
                                     "AND kind = 'llm-month' AND month = :m"), {"m": _month()}).scalar() or 0
    except Exception:
        used = 0
    return {"enabled": bool(token()), "used": used, "limit": _limit(), "period": "month",
            "models": [{"model": m, "paused": (_cooldown.get(m, (0, ""))[1] if time.time() < _cooldown.get(m, (0, ""))[0] else "")}
                       for m in models()]}


def chat(prompt: str, max_tokens: int = 150) -> tuple[str, str] | None:
    """(answer, model) from the first model that works, or None if none can answer."""
    if not token():
        return None
    for model in models():
        until, _reason = _cooldown.get(model, (0, ""))
        if time.time() < until:
            continue
        if not _reserve():
            log.warning("Hugging Face: this month's allowance is used up")
            return None  # the credit is shared by every model, so trying another one would not help
        try:
            resp = httpx.post(HF_URL + "/chat/completions", headers={"Authorization": "Bearer " + token()},
                              json={"model": model, "temperature": 0, "max_tokens": max_tokens,
                                    "messages": [{"role": "user", "content": prompt}]}, timeout=LLM_TIMEOUT_S)
        except httpx.HTTPError as exc:
            _refund()
            _cooldown[model] = (time.time() + 300, f"unreachable ({exc.__class__.__name__})")
            continue
        if resp.status_code != 200:
            _refund()
            # 402: the model's provider is not covered by the free credit. 400/404: model not available to you.
            pause = 3600 if resp.status_code in (402, 429) else 86400 if resp.status_code in (400, 401, 403, 404) else 300
            _cooldown[model] = (time.time() + pause, f"HTTP {resp.status_code}")
            log.warning("Hugging Face model %s answered HTTP %s, trying the next one", model, resp.status_code)
            continue
        try:
            content = resp.json()["choices"][0]["message"].get("content") or ""
        except (ValueError, KeyError, IndexError, TypeError):
            content = ""
        if content.strip():
            return content, model
        _cooldown[model] = (time.time() + 600, "empty answer")   # e.g. a reasoning model that used all its tokens
    return None


# ---------------------------------------------------------------------------
# Profile matching: lines up a form's fields (from form_crawler.py) with what we already know about the
# user, so the Form Runner only ever has to ask for what is genuinely missing.
#
# Two places hold what we know, and they are kept apart:
#   * `users`            - the sign-up details (name, email, phone, date of birth, address...). Only ever READ here.
#   * `user_attributes`  - a few lasting facts about the person that the form assistant learned from their answers
#                          (household size, monthly income, employment status...). Linked to `users` by user_id.
#
# Only facts that stay true from one form to the next are kept. What a form asks for that is specific to that form
# - a free-text message or description, a course, a year, a captcha, a department, someone else's name - is asked
# each time and never stored. ATTRIBUTES below is the complete list of what may be kept; a question that matches
# none of it is simply not saved.
# ---------------------------------------------------------------------------
# Never stored, whatever the form asks: one-time codes, secrets and identity / account numbers.
SENSITIVE_RE = re.compile(r"captcha|otp|one[- ]time|password|passcode|\bpin\b|cvv|card number|credit|debit|aadhaar|aadhar|"
                          r"\bssn\b|social security|passport|bank account|account number|verification code|"
                          r"policy number|member id|insurance (id|number)|licen[cs]e number|tax id|\bpan\b", re.I)

# Free text and one-off answers: these change with every form.
FORM_SPECIFIC_RE = re.compile(r"message|description|describe|comment|remark|note|reason|concern|query|enquiry|inquiry|"
                              r"feedback|complaint|explain|details|purpose|subject|why |symptom|"
                              r"course|program|programme|department|grade|section|year for|academic year|batch|"
                              r"preferred (date|time)|appointment|doctor|specialty|specialisation", re.I)

# key, name shown, value type, how the question is worded
ATTRIBUTES = (
    ("household_size", "Household size", "integer",
     r"household (size|members?)|(members|people|persons|individuals) (in|of|living|live|reside)|(people|persons|individuals|members).{0,25}"
     r"(household|family|home|reside|live)|family size|size of (the |your )?(household|family)|how many (people|persons|individuals)"),
    ("number_of_children", "Number of children", "integer",
     r"(number|no\.?|count) of (children|kids|dependents?)|how many (children|kids|dependents?)|\bdependents?\b|children (under|in)"),
    ("monthly_household_income", "Monthly household income", "decimal",
     r"(monthly|per month|month).{0,25}(income|earnings|salary)|(income|earnings|salary).{0,25}(monthly|per month|month)"),
    ("annual_household_income", "Annual household income", "decimal",
     r"(annual|yearly|per year|per annum).{0,25}(income|earnings|salary)|(income|earnings|salary).{0,25}(annual|yearly|per year|per annum)"),
    ("employment_status", "Employment status", "string",
     r"employ(ed|ment)|currently (have a )?(job|working)|have a job|work(ing)? status"),
    ("occupation", "Occupation", "string", r"occupation|profession|job title"),
    ("housing_status", "Housing status", "string",
     r"housing (status|situation|type)|living situation|homeless|do you (own|rent)|own or rent|residence type|type of residence"),
    ("preferred_language", "Preferred language", "string",
     r"(preferred|primary|home|first|spoken|native|mother) (tongue|language)|language (spoken|preference)|preferred language"),
    ("insurance_status", "Insurance status", "string",
     r"insurance|medicaid|medicare|health (cover|plan)"),
    ("veteran_status", "Veteran status", "string", r"veteran|military|armed forces"),
    ("disability_status", "Disability status", "string", r"disab(led|ility)|special needs"),
    ("transportation_access", "Transportation access", "string",
     r"transport|own (a )?(car|vehicle|bike)|vehicle|how do you (travel|commute)"),
    ("marital_status", "Marital status", "string", r"marital|married|relationship status"),
    ("education_level", "Education level", "string",
     r"education(al)? (level|qualification|status)|highest (qualification|education|degree)|qualification"),
    ("gender", "Gender", "string", r"\bgender\b|\bsex\b"),
    ("citizenship", "Citizenship", "string", r"citizen(ship)?|nationality"),
)
_ATTRIBUTE_RES = [(k, name, vt, re.compile(rx, re.I)) for k, name, vt, rx in ATTRIBUTES]
MAX_VALUE_LEN = 120


def canonical_attribute(label: str, field_type: str = "") -> tuple[str, str, str] | None:
    """(key, display name, value type) if this question asks for one of the lasting facts we keep, else None.
    Sensitive, free-text and form-specific questions are never kept."""
    label = re.sub(r"\s+", " ", label or "").strip()
    if not label or SENSITIVE_RE.search(label) or FORM_SPECIFIC_RE.search(label):
        return None
    if field_type in ("textarea", "file", "password", "hidden"):
        return None
    for key, name, vtype, pattern in _ATTRIBUTE_RES:
        if pattern.search(label):
            return key, name, vtype
    return None


def clean_value(value: str, vtype: str) -> str | None:
    """The answer tidied for storage, or None if it does not fit what the fact should look like."""
    value = re.sub(r"\s+", " ", value or "").strip()
    if not value or len(value) > MAX_VALUE_LEN:
        return None
    if vtype == "integer":
        digits = re.sub(r"[,\s]", "", value)
        return digits if re.fullmatch(r"\d{1,4}", digits) else None
    if vtype == "decimal":
        number = re.sub(r"[,\s]|(?i:rs\.?|inr|usd|\$|₹)", "", value)
        return number if re.fullmatch(r"\d+(\.\d{1,2})?", number) else None
    return value


def _from_profile(user: User, kind: str | None) -> str | None:
    """Sign-up details (read-only)."""
    if kind == "first_name":
        return user.first_name
    if kind == "last_name":
        return user.last_name
    if kind == "full_name":
        parts = [user.first_name, user.middle_name, user.last_name]
        return " ".join(p for p in parts if p)
    if kind == "email":
        return user.email
    if kind == "phone":
        return user.phone
    if kind == "date_of_birth":
        return user.date_of_birth.isoformat() if user.date_of_birth else None
    if kind == "address":
        return ", ".join(p for p in (user.address_line1, user.address_line2) if p) or None
    if kind == "city":
        return user.city
    if kind == "state":
        return user.state
    if kind == "postal_code":
        return user.postal_code
    if kind == "country":
        return user.country
    return None   # preferred_date, reason, doctor... are specific to one appointment, never in a profile


# What is remembered value by value and offered again as a choice (names, contact details, address parts).
POOL_KINDS = {"first_name", "last_name", "full_name", "email", "phone", "date_of_birth", "address", "city", "state",
              "postal_code", "country"}


def pool_kind(kind: str | None) -> str | None:
    """The kind of value a field takes for remembering ("role_full_name" - a Student Name - is a full name too)."""
    base = (kind or "").removeprefix("role_")
    return base if base in POOL_KINDS else None


_LABEL_STOP = {"your", "enter", "please", "select", "choose", "the", "a", "an", "of", "is", "what", "are", "you", "for",
               "in", "to", "and", "or", "my", "type", "pick", "required", "optional", "field", "name_of"}
_NOT_A_CONCEPT_TYPES = {"textarea", "file", "password", "hidden", "checkbox", "date", "datetime-local", "time", "submit"}


def concept_key(kind: str | None, label: str | None, name: str | None, ftype: str | None) -> str | None:
    """What a question is about, so the same thing asked under a different field name on another form finds the
    earlier answers: "Mobile No", "Phone", "contactNo" are all `phone`; "Name", "Patient Name" are `full_name`;
    anything else is keyed by its wording ("Blood group" -> `x_blood_group`, whatever the form calls the field).
    None for what must not be remembered: sensitive answers, free text, dates and times, and answers that belong
    to one appointment (message, doctor, department, preferred date...)."""
    text_ = re.sub(r"\s+", " ", (label or name or "")).strip()
    if SENSITIVE_RE.search(text_) or SENSITIVE_RE.search(name or ""):
        return None
    if not kind and text_:   # the caller did not say what kind of field it is: read it from its wording
        from .form_crawler import _classify
        kind = _classify(f"{name or ''} {text_}")
    pool = pool_kind(kind)
    if pool:
        return pool
    if (ftype or "") in _NOT_A_CONCEPT_TYPES or FORM_SPECIFIC_RE.search(text_) or \
            re.search(r"\b(date|time|slot|schedule|day|dd/mm)\b", text_, re.I):
        return None   # a day or time picked for one visit is out of date next time
    words = [w for w in re.findall(r"[a-z0-9]+", text_.lower()) if w not in _LABEL_STOP]
    return ("x_" + "_".join(words))[:40] if words else None


def remembered_ok(kind: str | None, label: str, value: str, name: str = "", ftype: str = "") -> bool:
    """May this answer be remembered?"""
    if not concept_key(kind, label, name, ftype):
        return False
    value = re.sub(r"\s+", " ", value or "").strip()
    return bool(value) and len(value) <= 200


def match_fields(user: User, fields: list[dict], doctor_label: str | None = None,
                 saved: dict[str, str] | None = None, history: dict[str, list[str]] | None = None) -> list[dict]:
    """Each field from form_crawler, plus a `value` (prefilled, or None) and a `source`: "profile" (the sign-up
    details), "saved" (a lasting fact from an earlier answer), "selection" (the doctor/specialty they just picked),
    "needs_confirmation" (a role-specific field such as "Student Name") or "needs_input" (the person must give it).
    `saved` maps attribute key -> value (see ATTRIBUTES)."""
    saved = saved or {}
    history = history or {}
    out = []
    for field in fields:
        kind = field.get("kind") or ""
        label = field.get("label") or field.get("name") or ""
        concept = canonical_attribute(label, field.get("type") or "")
        remembered = saved.get(concept[0]) if concept else None
        # every value this person has used for this kind of question (sign-up details first, then earlier forms,
        # most recent first): offered as choices, so they can pick one or type a new one
        pool = pool_kind(kind)
        ckey = concept_key(kind, label, field.get("name"), field.get("type"))
        options_here = [str(o) for o in (field.get("options") or [])]
        choices: list[str] = []
        no_choices_yet = field.get("type") in ("select", "radio") and not options_here   # a dependent dropdown: unknown until it loads
        if ckey and field.get("type") not in ("checkbox", "file") and not no_choices_yet:
            for v in ([_from_profile(user, pool)] if pool else []) + history.get(ckey, []):
                v = re.sub(r"\s+", " ", str(v or "")).strip()
                if options_here:
                    # a dropdown takes one of its own choices only (written exactly as the form writes it)
                    v = next((o for o in options_here if o.strip().lower() == v.lower()), "")
                if v and v.lower() not in (c.lower() for c in choices):
                    choices.append(v)
        if kind.startswith("role_"):
            # "Parent's Name", "Student Name"...: the account holder's details are only a suggestion, because we
            # cannot tell which person the field means. It is never filled in unconfirmed.
            out.append({**field, "value": None, "source": "needs_confirmation", "alternatives": choices,
                        "suggestion": _from_profile(user, kind.removeprefix("role_"))})
            continue
        value = _from_profile(user, kind)
        options = [str(o) for o in (field.get("options") or [])]
        if value and field.get("type") == "select" and options:
            # a dropdown only takes one of its own choices: use the profile value only if it is one of them
            value = next((o for o in options if o.strip().lower() == str(value).strip().lower()), None)
        source = "profile" if value else None
        if not value and remembered:
            value, source = remembered, "saved"
        if not value:
            source = "needs_input"
        if not value and choices:   # nothing in the profile for it, but it was answered before: the latest answer is the default
            value, source = choices[0], "saved"
        out.append({**field, "value": value, "source": source, "alternatives": choices})
    return out
