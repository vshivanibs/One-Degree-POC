"""Everything about finding a place: the browse-menu catalog (what a "resource" is, in OpenStreetMap's
own tags), turning a typed place name into coordinates (fixing spelling mistakes on the way), and the
free OpenStreetMap search services (Overpass, Nominatim, Photon) used both for a location's own address
and for what is near it.

The rest of the app only calls `search_places()`, `search_text()`, `get_menu()`, `get_resource()` and
`geocode()`. Everything here uses free, key-less services, tried in order so that when one is busy or
down the next one answers:

  1. Overpass API   - 7 free public servers, tried one after another (detailed results)
  2. Nominatim      - exact tag search (fast, but limited to 1 request per second)
  3. Photon         - OpenStreetMap search by komoot (last resort)

The data source can later be swapped for another provider (for example a One Degree resource API)
without touching the API routes or the frontend.

INDIA ONLY: geocode() only accepts places inside India. The world city list is kept only to RECOGNISE a
foreign name ("London", "Sydney") so it is refused instead of being "corrected" into some Indian village
with a similar spelling; the matches themselves, and the map lookups, are limited to India.
"""
import difflib
import math
import threading
import time
import unicodedata
from pathlib import Path

import httpx

# ---------------------------------------------------------------------------
# Browse-menu catalog: categories, options and how each option is found in OpenStreetMap.
# Each option is (name, [(osm_key, osm_value), ...]); any tag match counts.
# The menu shown to a user is filtered by what actually exists near their location (see get_menu),
# so options can be added here freely.
# ---------------------------------------------------------------------------
CATALOG: list[dict] = [
    {"label": "Healthcare", "icon": "➕", "options": [
        ("Clinics", [("amenity", "clinic")]),
        ("Hospitals", [("amenity", "hospital")]),
        ("Doctors", [("amenity", "doctors")]),
        ("Dentists", [("amenity", "dentist")]),
        ("Pharmacies", [("amenity", "pharmacy")]),
        ("Opticians", [("shop", "optician")]),
        ("Physiotherapy", [("healthcare", "physiotherapist")]),
        ("Mental health", [("healthcare", "psychotherapist"), ("healthcare:speciality", "psychiatry")]),
    ]},
    {"label": "Food", "icon": "\U0001F374", "options": [
        ("Food banks", [("social_facility", "food_bank"), ("amenity", "food_bank")]),
        ("Soup kitchens", [("social_facility", "soup_kitchen")]),
        ("Community fridges", [("amenity", "food_sharing")]),
        ("Supermarkets", [("shop", "supermarket")]),
        ("Grocery stores", [("shop", "convenience"), ("shop", "greengrocer")]),
        ("Bakeries", [("shop", "bakery")]),
        ("Marketplaces", [("amenity", "marketplace")]),
        ("Drinking water", [("amenity", "drinking_water")]),
    ]},
    {"label": "Housing & Basic Needs", "icon": "\U0001F3E0", "options": [
        ("Homeless shelters", [("social_facility", "shelter")]),
        ("Group homes", [("social_facility", "group_home")]),
        ("Assisted housing", [("social_facility", "assisted_living")]),
        ("Hostels", [("tourism", "hostel")]),
        ("Public toilets", [("amenity", "toilets")]),
        ("Showers", [("amenity", "shower")]),
        ("Laundry services", [("shop", "laundry")]),
    ]},
    {"label": "Education & Childcare", "icon": "\U0001F393", "options": [
        ("Childcare centers", [("amenity", "childcare")]),
        ("Kindergartens", [("amenity", "kindergarten")]),
        ("Schools", [("amenity", "school")]),
        ("Colleges", [("amenity", "college")]),
        ("Universities", [("amenity", "university")]),
        ("Libraries", [("amenity", "library")]),
        ("Language schools", [("amenity", "language_school")]),
        ("Driving schools", [("amenity", "driving_school")]),
    ]},
    {"label": "Employment", "icon": "\U0001F4BC", "options": [
        ("Employment agencies", [("office", "employment_agency")]),
        ("Job training centers", [("amenity", "training")]),
        ("Coworking spaces", [("amenity", "coworking_space")]),
        ("Internet cafes", [("amenity", "internet_cafe")]),
        ("Copy & print shops", [("shop", "copyshop")]),
        ("Sheltered workshops", [("social_facility", "workshop")]),
    ]},
    {"label": "Financial", "icon": "\U0001F3E6", "options": [
        ("Banks", [("amenity", "bank")]),
        ("ATMs", [("amenity", "atm")]),
        ("Tax advisers", [("office", "tax_advisor")]),
        ("Accountants", [("office", "accountant")]),
        ("Financial services", [("office", "financial")]),
        ("Insurance offices", [("office", "insurance")]),
        ("Money transfer", [("amenity", "money_transfer")]),
    ]},
    {"label": "Government & Legal", "icon": "✍", "options": [
        ("Lawyers", [("office", "lawyer")]),
        ("Notaries", [("office", "notary")]),
        ("Courthouses", [("amenity", "courthouse")]),
        ("Government offices", [("office", "government")]),
        ("Town halls", [("amenity", "townhall")]),
        ("Post offices", [("amenity", "post_office")]),
        ("Embassies", [("office", "diplomatic")]),
    ]},
    {"label": "Seniors & Disability", "icon": "\U0001F9D3", "options": [
        ("Nursing homes", [("amenity", "nursing_home")]),
        ("Senior services", [("social_facility:for", "senior")]),
        ("Disability services", [("social_facility:for", "disabled")]),
        ("Hospices", [("healthcare", "hospice")]),
        ("Rehabilitation centers", [("healthcare", "rehabilitation")]),
        ("Day care centers", [("social_facility", "day_care")]),
    ]},
    {"label": "Community", "icon": "\U0001F91D", "options": [
        ("Community centers", [("amenity", "community_centre")]),
        ("Social centers", [("amenity", "social_centre")]),
        ("Charity shops", [("shop", "charity")]),
        ("Places of worship", [("amenity", "place_of_worship")]),
        ("Youth centers", [("amenity", "youth_centre")]),
        ("Sports centers", [("leisure", "sports_centre")]),
        ("Parks", [("leisure", "park")]),
        ("Playgrounds", [("leisure", "playground")]),
    ]},
    {"label": "Transportation", "icon": "\U0001F68C", "options": [
        ("Bus stops", [("highway", "bus_stop")]),
        ("Bus stations", [("amenity", "bus_station")]),
        ("Train stations", [("railway", "station")]),
        ("Metro stations", [("station", "subway")]),
        ("Taxi stands", [("amenity", "taxi")]),
        ("Bicycle rental", [("amenity", "bicycle_rental")]),
        ("Car rental", [("amenity", "car_rental")]),
        ("Fuel stations", [("amenity", "fuel")]),
    ]},
    {"label": "Emergency", "icon": "⚠", "options": [
        ("Police stations", [("amenity", "police")]),
        ("Fire stations", [("amenity", "fire_station")]),
        ("Ambulance stations", [("emergency", "ambulance_station")]),
        ("Emergency assembly points", [("emergency", "assembly_point")]),
        ("Defibrillators", [("emergency", "defibrillator")]),
        ("Emergency phones", [("emergency", "phone")]),
    ]},
]

OPTION_TAGS: dict[str, list[tuple[str, str]]] = {
    name: tags for cat in CATALOG for name, tags in cat["options"]
}
OPTION_CATEGORY: dict[str, str] = {
    name: cat["label"] for cat in CATALOG for name, _ in cat["options"]
}


# Words people type that should run a menu option's search (matched as whole words).
SYNONYMS: dict[str, list[str]] = {
    "Clinics": ["health center", "health centre", "medical center", "medical centre", "urgent care", "walk in clinic"],
    "Hospitals": ["emergency room", "er", "medical emergency"],
    "Doctors": ["doctor", "physician", "gp", "general practitioner"],
    "Dentists": ["dental", "dentist", "teeth", "tooth"],
    "Pharmacies": ["pharmacy", "chemist", "drugstore", "drug store", "medicine", "medicines", "medical store"],
    "Opticians": ["eye care", "eye doctor", "glasses", "eyeglasses", "vision"],
    "Physiotherapy": ["physical therapy", "physio"],
    "Mental health": ["counseling", "counselling", "therapy", "therapist", "psychiatrist", "depression"],
    "Food banks": ["food pantry", "food pantries", "pantry", "free food", "food assistance", "food aid", "hungry", "hunger"],
    "Soup kitchens": ["free meals", "free meal", "meal program", "community kitchen"],
    "Community fridges": ["free fridge"],
    "Supermarkets": ["supermarket", "groceries"],
    "Grocery stores": ["grocery", "grocer", "kirana", "convenience store"],
    "Bakeries": ["bakery", "bread"],
    "Marketplaces": ["market", "bazaar"],
    "Drinking water": ["water fountain", "free water", "safe water"],
    "Homeless shelters": ["shelter", "homeless", "emergency housing", "night shelter"],
    "Assisted housing": ["assisted living", "supportive housing", "affordable housing", "low income housing"],
    "Hostels": ["hostel", "cheap stay"],
    "Public toilets": ["toilet", "restroom", "bathroom", "washroom"],
    "Laundry services": ["laundry", "laundromat", "laundrette"],
    "Childcare centers": ["childcare", "child care", "daycare", "day care", "nursery", "creche"],
    "Kindergartens": ["kindergarten", "preschool", "pre school", "playschool"],
    "Libraries": ["library"],
    "Language schools": ["esl", "english classes", "language classes", "learn english"],
    "Driving schools": ["driving lessons", "driving classes"],
    "Employment agencies": ["job agency", "jobs", "job placement", "staffing", "find work", "job search", "find a job"],
    "Job training centers": ["job training", "skills training", "vocational training", "training center", "training centre"],
    "Coworking spaces": ["coworking", "co working"],
    "Internet cafes": ["internet cafe", "internet access", "cyber cafe"],
    "Copy & print shops": ["print", "printing", "photocopy", "xerox", "copy shop"],
    "Banks": ["bank", "banking"],
    "ATMs": ["atm", "cash machine"],
    "Tax advisers": ["tax", "tax help", "tax preparation", "tax adviser", "tax advisor"],
    "Accountants": ["accountant", "accounting"],
    "Financial services": ["financial help", "financial advice", "financial aid"],
    "Insurance offices": ["insurance"],
    "Money transfer": ["remittance", "western union"],
    "Lawyers": ["lawyer", "attorney", "legal aid", "legal help", "legal advice"],
    "Notaries": ["notary"],
    "Courthouses": ["court", "courthouse"],
    "Government offices": ["government office", "govt office", "city office"],
    "Town halls": ["town hall", "city hall", "municipal office"],
    "Post offices": ["post office", "mail"],
    "Embassies": ["embassy", "consulate"],
    "Nursing homes": ["nursing home", "elder care", "senior care", "old age home"],
    "Senior services": ["seniors", "senior", "elderly"],
    "Disability services": ["disability", "disabled"],
    "Hospices": ["hospice"],
    "Rehabilitation centers": ["rehab", "rehabilitation"],
    "Day care centers": ["adult day care"],
    "Community centers": ["community center", "community centre"],
    "Social centers": ["social center", "social centre"],
    "Charity shops": ["charity shop", "thrift store", "second hand", "donation center"],
    "Places of worship": ["worship", "church", "temple", "mosque", "gurdwara", "synagogue"],
    "Youth centers": ["youth center", "youth centre"],
    "Sports centers": ["sports", "gym", "fitness"],
    "Parks": ["park", "garden"],
    "Playgrounds": ["playground"],
    "Bus stops": ["bus stop"],
    "Bus stations": ["bus station", "bus stand", "bus terminal"],
    "Train stations": ["train station", "railway station", "railway"],
    "Metro stations": ["metro", "subway", "underground station"],
    "Taxi stands": ["taxi", "cab"],
    "Bicycle rental": ["bike rental", "cycle rental", "bike share"],
    "Car rental": ["rent a car", "car hire"],
    "Fuel stations": ["fuel", "petrol", "petrol pump", "gas station", "gas"],
    "Police stations": ["police"],
    "Fire stations": ["fire station", "fire department", "fire brigade"],
    "Ambulance stations": ["ambulance"],
    "Emergency assembly points": ["assembly point"],
    "Defibrillators": ["defibrillator", "aed"],
    "Emergency phones": ["emergency phone", "sos phone"],
}


def _catalog_words(text: str) -> list[str]:
    """Lowercase words, with a simple plural -> singular fold (schools -> school)."""
    import re
    return [w[:-1] if len(w) > 3 and w.endswith("s") else w for w in re.findall(r"[a-z0-9]+", text.lower())]


def _sound(text: str) -> str:
    """Fold common sound-alike spellings so 'farmacy' and 'pharmacy' compare as equal."""
    return text.replace("ph", "f").replace("ck", "k").replace("kn", "n")


def _phrases() -> list[tuple[str, list[str], str]]:
    """Every phrase that refers to an option: (option, folded words, phrase as written)."""
    out = []
    for name in OPTION_TAGS:
        for phrase in [name] + SYNONYMS.get(name, []):
            out.append((name, _catalog_words(phrase), phrase.lower()))
    return out


def match_option_ex(query: str) -> tuple[str, str, bool] | None:
    """(option, phrase that matched, was_misspelt) for a typed service, or None.
    The longest exact phrase wins ("driving school" picks Driving schools, not Schools). If nothing
    matches exactly, close spellings are accepted: "dentst" -> dentist, "farmacy" -> pharmacy."""
    q = _catalog_words(query)
    if not q:
        return None
    best, best_len = None, 0
    for name, p, written in _phrases():
        if not p or len(p) > len(q):
            continue
        if any(q[i:i + len(p)] == p for i in range(len(q) - len(p) + 1)) and len(" ".join(p)) > best_len:
            best, best_len = (name, written, False), len(" ".join(p))
    if best:
        return best

    import difflib as _difflib
    top, top_score = None, 0.0
    for name, p, written in _phrases():
        if not p or len(p) > len(q):
            continue
        target = " ".join(p)
        for i in range(len(q) - len(p) + 1):
            window = " ".join(q[i:i + len(p)])
            # words under 5 letters are too short to guess ("bnk"), and a much longer word is not a typo
            if len(window) < 5 or abs(len(window) - len(target)) > 2:
                continue
            score = _difflib.SequenceMatcher(None, _sound(window), _sound(target)).ratio()
            if score >= 0.82 and score * len(target) > top_score:
                top, top_score = (name, written, True), score * len(target)
    return top


# ---------------------------------------------------------------------------
# OpenStreetMap search: Overpass, Nominatim, Photon
# ---------------------------------------------------------------------------
OVERPASS_SOURCE = "OpenStreetMap (Overpass API)"
NOMINATIM_SOURCE = "OpenStreetMap (Nominatim search)"
PHOTON_SOURCE = "OpenStreetMap (Photon search)"

# Free public Overpass servers, best first. Those that fail are skipped for a while.
OVERPASS_SERVERS = [
    "https://overpass.openstreetmap.fr/api/interpreter",
    "https://z.overpass-api.de/api/interpreter",
    "https://overpass-api.de/api/interpreter",
    "https://lz4.overpass-api.de/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
]
NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
NOMINATIM_LOOKUP_URL = "https://nominatim.openstreetmap.org/lookup"
PHOTON_URL = "https://photon.komoot.io/api/"
HEADERS = {"User-Agent": "OneDegreePOC/0.1 (community resource finder demo)"}

RADIUS_KM = 10                   # every search covers exactly this distance around the chosen place
RADIUS_M = RADIUS_KM * 1000
SERVER_TIMEOUT_S = 12            # per server; then the next one is tried
TIME_BUDGET_S = 30               # per Overpass search, then the next provider is used
SERVER_COOLDOWN_S = 120          # a server that just failed is skipped for this long
NOMINATIM_COOLDOWN_S = 300       # after HTTP 429 (rate limited) leave Nominatim alone for a while
NOMINATIM_MIN_INTERVAL_S = 1.05  # Nominatim usage policy: at most 1 request per second
MAX_RESULTS = 100
CACHE_TTL_S = 600
MENU_TTL_S = 1800

_cache: dict[tuple, tuple[float, dict]] = {}
_server_down_until: dict[str, float] = {}
_nominatim_down_until = 0.0
_nominatim_lock = threading.Lock()
_nominatim_last = 0.0


class DiscoveryError(Exception):
    pass


def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def _first_provider(providers: list) -> tuple[list[dict], str] | None:
    """Run providers in order. The first one that returns results wins. If none returns
    results but at least one answered, the (empty) answer of the last one that answered
    is returned. If all of them failed, None."""
    answered = None
    for fn in providers:
        try:
            results, source = fn()
        except DiscoveryError:
            continue
        if results:
            return results, source
        answered = (results, source)
    return answered


# ---------------------------------------------------------------------------
# 1. Overpass: several free servers, tried one after another
# ---------------------------------------------------------------------------
def _ordered_servers() -> list[str]:
    now = time.time()
    up = [u for u in OVERPASS_SERVERS if _server_down_until.get(u, 0) <= now]
    return up or list(OVERPASS_SERVERS)  # if all are marked down, try them all again


def _run_overpass(query: str, deadline: float) -> list[dict]:
    """POST the query to the first Overpass server that answers; on failure try the next one."""
    last_error = "no Overpass server answered"
    for url in _ordered_servers():
        remaining = deadline - time.time()
        if remaining <= 1:
            break
        try:
            resp = httpx.post(url, data={"data": query}, headers=HEADERS,
                              timeout=min(SERVER_TIMEOUT_S, remaining))
            if resp.status_code == 200:
                _server_down_until.pop(url, None)
                return resp.json().get("elements", [])
            last_error = f"{url.split('/')[2]} returned status {resp.status_code}"
        except (httpx.HTTPError, ValueError) as exc:
            last_error = f"{url.split('/')[2]} did not respond ({exc.__class__.__name__})"
        _server_down_until[url] = time.time() + SERVER_COOLDOWN_S
    raise DiscoveryError(last_error)


def _build_query(tags: list[tuple[str, str]], lat: float, lng: float, radius_m: int,
                 output: str = "out center tags 250;") -> str:
    parts = "".join(f'nwr["{k}"="{v}"](around:{radius_m},{lat},{lng});' for k, v in tags)
    return f"[out:json][timeout:20];({parts});{output}"


def _address(tags: dict) -> str:
    street = " ".join(filter(None, [tags.get("addr:housenumber"), tags.get("addr:street")]))
    parts = [street, tags.get("addr:suburb"), tags.get("addr:city"),
             tags.get("addr:state"), tags.get("addr:postcode")]
    return ", ".join(p for p in parts if p)


def _to_result(el: dict, option: str, category: str, lat: float, lng: float) -> dict | None:
    tags = el.get("tags", {})
    name = tags.get("name") or tags.get("name:en")
    if not name:
        return None  # unnamed features are not useful as resources
    plat = el.get("lat") or el.get("center", {}).get("lat")
    plon = el.get("lon") or el.get("center", {}).get("lon")
    if plat is None or plon is None:
        return None
    return {
        "id": f'{el["type"]}/{el["id"]}',
        "name": name,
        "category": category,
        "service": option,
        "description": tags.get("description") or tags.get("description:en") or "",
        "address": _address(tags),
        "distance_km": round(_haversine_km(lat, lng, plat, plon), 1),
        "lat": plat,
        "lng": plon,
        "phone": tags.get("phone") or tags.get("contact:phone") or "",
        "email": tags.get("email") or tags.get("contact:email") or "",
        "website": tags.get("website") or tags.get("contact:website") or tags.get("url") or "",
        "opening_hours": tags.get("opening_hours") or "",
        "osm_url": f'https://www.openstreetmap.org/{el["type"]}/{el["id"]}',
        "source": OVERPASS_SOURCE,
    }


# ---------------------------------------------------------------------------
# 2. Nominatim: exact tag search and free-text search
# ---------------------------------------------------------------------------
def _nominatim_get(params: dict, url: str = NOMINATIM_URL) -> list[dict]:
    global _nominatim_last, _nominatim_down_until
    if time.time() < _nominatim_down_until:
        raise DiscoveryError("the Nominatim server is rate-limiting requests right now")
    with _nominatim_lock:  # one request at a time, at most one per second
        wait = NOMINATIM_MIN_INTERVAL_S - (time.time() - _nominatim_last)
        if wait > 0:
            time.sleep(wait)
        _nominatim_last = time.time()  # spacing is measured start to start
        try:
            resp = httpx.get(url, params=params, headers=HEADERS, timeout=SERVER_TIMEOUT_S)
        except httpx.HTTPError as exc:
            raise DiscoveryError(f"the Nominatim server did not respond ({exc.__class__.__name__})")
    if resp.status_code in (403, 429):
        _nominatim_down_until = time.time() + NOMINATIM_COOLDOWN_S
        raise DiscoveryError("the Nominatim server is rate-limiting requests right now")
    try:
        resp.raise_for_status()
        return resp.json()
    except (httpx.HTTPError, ValueError) as exc:
        raise DiscoveryError(f"the Nominatim server returned an error ({exc.__class__.__name__})")


def _viewbox(lat: float, lng: float) -> str:
    """Bounding box just large enough to contain the RADIUS_KM circle around lat/lng."""
    dlat = RADIUS_KM / 111.32
    dlng = RADIUS_KM / (111.32 * max(math.cos(math.radians(lat)), 0.01))
    return f"{lng - dlng},{lat + dlat},{lng + dlng},{lat - dlat}"


def _nominatim_params(query: str, lat: float, lng: float) -> dict:
    return {
        "q": query, "format": "jsonv2", "limit": 40, "bounded": 1,
        "viewbox": _viewbox(lat, lng),
        "addressdetails": 1, "extratags": 1,
    }


def _nominatim_rows(key: str, value: str, lat: float, lng: float) -> list[dict]:
    """Places tagged key=value inside a box around lat/lng (exact tag search)."""
    return _nominatim_get(_nominatim_params(f"[{key}={value}]", lat, lng))


def _nominatim_named(rows: list[dict], lat: float, lng: float) -> list[dict]:
    """Keep named places within RADIUS_KM; drop administrative areas and roads (bus stops are kept)."""
    keep = []
    for r in rows:
        if not r.get("name"):
            continue
        if _haversine_km(lat, lng, float(r["lat"]), float(r["lon"])) > RADIUS_KM:
            continue  # the search box is square: trim the corners to a true 10 km circle
        cls = r.get("class")
        if cls in ("boundary", "place") or (cls == "highway" and r.get("type") != "bus_stop"):
            continue
        keep.append(r)
    return keep


def _row_to_result(row: dict, option: str, category: str, lat: float, lng: float) -> dict:
    plat, plon = float(row["lat"]), float(row["lon"])
    extra = row.get("extratags") or {}
    addr = row.get("address") or {}
    street = " ".join(filter(None, [addr.get("house_number"), addr.get("road")]))
    address = ", ".join(p for p in [street, addr.get("suburb"), addr.get("city") or addr.get("town")
                                    or addr.get("village"), addr.get("state"), addr.get("postcode")] if p)
    return {
        "id": f'{row.get("osm_type", "")}/{row.get("osm_id", "")}',
        "name": row["name"],
        "category": category,
        "service": option,
        "description": extra.get("description", ""),
        "address": address,
        "distance_km": round(_haversine_km(lat, lng, plat, plon), 1),
        "lat": plat,
        "lng": plon,
        "phone": extra.get("phone") or extra.get("contact:phone") or "",
        "email": extra.get("email") or extra.get("contact:email") or "",
        "website": extra.get("website") or extra.get("contact:website") or "",
        "opening_hours": extra.get("opening_hours", ""),
        "osm_url": f'https://www.openstreetmap.org/{row.get("osm_type", "node")}/{row.get("osm_id", "")}',
        "source": NOMINATIM_SOURCE,
    }


def _nominatim_search(option: str, category: str, lat: float, lng: float) -> tuple[list[dict], str]:
    results, seen = [], set()
    for key, value in OPTION_TAGS[option]:
        for row in _nominatim_named(_nominatim_rows(key, value, lat, lng), lat, lng):
            rid = f'{row.get("osm_type", "")}/{row.get("osm_id", "")}'
            if rid not in seen:
                seen.add(rid)
                results.append(_row_to_result(row, option, category, lat, lng))
    return results, NOMINATIM_SOURCE


def _nominatim_text(query: str, lat: float, lng: float) -> tuple[list[dict], str]:
    seen, results = set(), []
    for row in _nominatim_named(_nominatim_get(_nominatim_params(query, lat, lng)), lat, lng):
        rid = f'{row.get("osm_type", "")}/{row.get("osm_id", "")}'
        if rid not in seen:
            seen.add(rid)
            results.append(_row_to_result(row, row.get("type", "").replace("_", " ").title() or "Place",
                                          "Search results", lat, lng))
    return results, NOMINATIM_SOURCE


# ---------------------------------------------------------------------------
# 3. Photon: OpenStreetMap search by komoot (matches names, biased towards the user)
# ---------------------------------------------------------------------------
def _photon_get(query: str, lat: float, lng: float, osm_tag: str | None = None) -> list[dict]:
    params = {"q": query, "lat": lat, "lon": lng, "limit": 40, "lang": "en"}
    if osm_tag:
        params["osm_tag"] = osm_tag
    try:
        resp = httpx.get(PHOTON_URL, params=params, headers=HEADERS, timeout=SERVER_TIMEOUT_S)
        resp.raise_for_status()
        return resp.json().get("features", [])
    except (httpx.HTTPError, ValueError) as exc:
        raise DiscoveryError(f"the Photon server did not respond ({exc.__class__.__name__})")


def _photon_result(feature: dict, service: str, category: str, lat: float, lng: float) -> dict | None:
    props = feature.get("properties") or {}
    name = props.get("name")
    coords = (feature.get("geometry") or {}).get("coordinates")
    if not name or not coords:
        return None
    plon, plat = coords[0], coords[1]
    distance = _haversine_km(lat, lng, plat, plon)
    if distance > RADIUS_KM:
        return None  # Photon only biases towards the user, so drop far-away matches
    otype = {"N": "node", "W": "way", "R": "relation"}.get(props.get("osm_type"), "node")
    street = " ".join(filter(None, [props.get("housenumber"), props.get("street")]))
    address = ", ".join(p for p in [street, props.get("district"), props.get("city"),
                                    props.get("state"), props.get("postcode")] if p)
    return {
        "id": f'{otype}/{props.get("osm_id", "")}',
        "name": name,
        "category": category,
        "service": service,
        "description": "",
        "address": address,
        "distance_km": round(distance, 1),
        "lat": plat,
        "lng": plon,
        "phone": "",
        "email": "",
        "website": "",
        "opening_hours": "",
        "osm_url": f'https://www.openstreetmap.org/{otype}/{props.get("osm_id", "")}',
        "source": PHOTON_SOURCE,
    }


def _singular_term(option: str) -> str:
    """'Pharmacies' -> 'pharmacy', 'Food banks' -> 'food bank' (the word Photon matches on)."""
    words = option.lower().split()
    last = words[-1]
    words[-1] = last[:-3] + "y" if last.endswith("ies") else (last[:-1] if last.endswith("s") else last)
    return " ".join(words)


def _photon_search(option: str, category: str, lat: float, lng: float) -> tuple[list[dict], str]:
    results, seen = [], set()
    term = _singular_term(option)
    for key, value in OPTION_TAGS[option]:
        if ":" in key:  # Photon cannot filter on keys like social_facility:for
            continue
        for feature in _photon_get(term, lat, lng, f"{key}:{value}"):
            r = _photon_result(feature, option, category, lat, lng)
            if r and r["id"] not in seen:
                seen.add(r["id"])
                results.append(r)
    return results, PHOTON_SOURCE


def _photon_text(query: str, lat: float, lng: float) -> tuple[list[dict], str]:
    results, seen = [], set()
    for feature in _photon_get(query, lat, lng):
        props = feature.get("properties") or {}
        if props.get("osm_key") in ("place", "boundary", "highway") and props.get("osm_value") != "bus_stop":
            continue  # cities, districts and roads are not resources
        service = (props.get("osm_value") or "place").replace("_", " ").title()
        r = _photon_result(feature, service, "Search results", lat, lng)
        if r and r["id"] not in seen:
            seen.add(r["id"])
            results.append(r)
    return results, PHOTON_SOURCE


# ---------------------------------------------------------------------------
# Search by menu option
# ---------------------------------------------------------------------------
def _sorted(results: list[dict]) -> list[dict]:
    return sorted(results, key=lambda r: r["distance_km"])[:MAX_RESULTS]


def _fallback(option: str, category: str, lat: float, lng: float, overpass_error: Exception) -> dict:
    """Overpass could not answer: use the next free providers (not cached)."""
    found = _first_provider([
        lambda: _nominatim_search(option, category, lat, lng),
        lambda: _photon_search(option, category, lat, lng),
    ])
    if found is None:
        raise DiscoveryError(f"every free map server failed ({overpass_error})")
    results, source = found
    results = _sorted(results)
    return {
        "option": option, "category": category, "radius_km": RADIUS_KM,
        "count": len(results), "source": source, "fallback": True, "results": results,
    }


def search_places(option: str, category: str, lat: float, lng: float) -> dict:
    tags = OPTION_TAGS[option]
    key = (option, round(lat, 3), round(lng, 3))  # ~100 m: distances are measured from the origin
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < CACHE_TTL_S:
        return {**hit[1], "category": category}

    deadline = time.time() + TIME_BUDGET_S
    try:
        elements = _run_overpass(_build_query(tags, lat, lng, RADIUS_M), deadline)
    except DiscoveryError as exc:
        return _fallback(option, category, lat, lng, exc)
    seen, results = set(), []
    for el in elements:
        r = _to_result(el, option, category, lat, lng)
        if r and r["id"] not in seen:
            seen.add(r["id"])
            results.append(r)
    results = _sorted(results)
    data = {
        "option": option,
        "category": category,
        "radius_km": RADIUS_KM,
        "count": len(results),
        "source": OVERPASS_SOURCE,
        "results": results,
    }
    _cache[key] = (time.time(), data)
    return data


# ---------------------------------------------------------------------------
# Typed search (the header search box)
# ---------------------------------------------------------------------------
def search_text(query: str, lat: float, lng: float) -> dict:
    """What the user typed. A known service name or synonym runs that menu option's search;
    anything else becomes a free-text search around the user (Nominatim, then Photon)."""
    hit = match_option_ex(query)  # tolerates spelling mistakes: "dentst" -> dentist

    if hit:
        option, phrase, misspelt = hit
        try:
            data = dict(search_places(option, OPTION_CATEGORY[option], lat, lng))
            if data["count"]:
                return {**data, "query": query, "matched_option": option,
                        "corrected_to": phrase if misspelt else None}
        except DiscoveryError:
            pass  # fall through to the free-text providers below

    found = _first_provider([
        lambda: _nominatim_text(query, lat, lng),
        lambda: _photon_text(query, lat, lng),
    ])
    if found is None:
        raise DiscoveryError("every free map server failed")
    results, source = found
    results = _sorted(results)
    return {
        "query": query, "matched_option": None, "option": None, "category": "Search results",
        "radius_km": RADIUS_KM, "count": len(results),
        "source": source, "fallback": True, "results": results,
    }


# ---------------------------------------------------------------------------
# Browse-menu availability: only options with results near the user are shown.
# The check runs in a background thread and the menu fills in category by
# category, so the page never blocks on it.
# ---------------------------------------------------------------------------
AVAILABILITY_RADIUS_M = RADIUS_M
OPTION_BUDGET_S = 25
_menu_jobs: dict[tuple, dict] = {}
_menu_lock = threading.Lock()
TOTAL_OPTIONS = len(OPTION_TAGS)


def _available_nominatim(cat: dict, lat: float, lng: float, job: dict) -> list[str]:
    """Options of this category with at least one named place nearby (1 request per option)."""
    names = []
    for name, tags in cat["options"]:
        if any(_nominatim_named(_nominatim_rows(k, v, lat, lng), lat, lng) for k, v in tags):
            names.append(name)
        job["checked"] += 1
    return names


def _available_overpass(cat: dict, lat: float, lng: float, job: dict) -> list[str]:
    """Same, using Overpass: one small query per option (big combined queries are too heavy for
    the free public servers). Each query tries every server in turn."""
    names, failures = [], 0
    for name, tags in cat["options"]:
        # No ["name"] filter in the query itself: that makes it far too slow on the public servers.
        # Instead fetch a few dozen tag sets and look for a named place in the answer.
        try:
            elements = _run_overpass(_build_query(tags, lat, lng, AVAILABILITY_RADIUS_M, "out tags 60;"),
                                     time.time() + OPTION_BUDGET_S)
            if any((e.get("tags") or {}).get("name") for e in elements):
                names.append(name)
        except DiscoveryError:
            failures += 1
            if failures >= 3:  # every free server keeps failing for this category
                raise
        job["checked"] += 1
    return names


def _run_menu_job(job: dict, lat: float, lng: float) -> None:
    failed_categories = 0
    for cat in CATALOG:
        names = None
        if time.time() >= _nominatim_down_until:
            checked_before = job["checked"]
            try:
                names = _available_nominatim(cat, lat, lng, job)
            except DiscoveryError:
                job["checked"] = checked_before  # Nominatim is limited: use Overpass instead
        if names is None:
            try:
                names = _available_overpass(cat, lat, lng, job)
            except DiscoveryError:
                failed_categories += 1
                job["checked"] += len(cat["options"])
                if failed_categories >= 3:  # every free server keeps failing: stop early
                    job["done"], job["failed"] = True, True
                    return
                continue
        if names:
            job["categories"].append({"label": cat["label"], "icon": cat["icon"],
                                      "items": [{"name": n} for n in names]})
    job["done"] = True
    job["finished_at"] = time.time()


def get_menu(lat: float, lng: float) -> dict:
    """Current state of the availability check for this location (starts it if needed)."""
    key = (round(lat, 2), round(lng, 2))
    with _menu_lock:
        job = _menu_jobs.get(key)
        stale = job and job.get("finished_at") and time.time() - job["finished_at"] > MENU_TTL_S
        retry = job and job["failed"] and time.time() - job["started_at"] > 60
        if job is None or stale or retry:
            job = {"categories": [], "checked": 0, "done": False, "failed": False,
                   "started_at": time.time()}
            _menu_jobs[key] = job
            threading.Thread(target=_run_menu_job, args=(job, lat, lng), daemon=True).start()
    return {
        "done": job["done"],
        "failed": job["failed"],
        "progress": round(min(job["checked"], TOTAL_OPTIONS) / TOTAL_OPTIONS, 2),
        "radius_km": RADIUS_KM,
        "categories": [dict(c) for c in job["categories"]],
    }


# ---------------------------------------------------------------------------
# One resource, with every detail OpenStreetMap has for it (the details page)
# ---------------------------------------------------------------------------
RESOURCE_TTL_S = 3600
_resource_cache: dict[str, tuple[float, dict]] = {}


def _option_for_tags(tags: dict) -> tuple[str | None, str | None]:
    """Which menu option (and category) an OpenStreetMap feature belongs to."""
    for name, pairs in OPTION_TAGS.items():
        if any(tags.get(k) == v for k, v in pairs):
            return name, OPTION_CATEGORY[name]
    return None, None


def _resource_dict(osm_id: str, tags: dict, lat: float | None, lng: float | None, source: str) -> dict:
    service, category = _option_for_tags(tags)
    return {
        "id": osm_id,
        "name": tags.get("name") or tags.get("name:en") or "Unnamed place",
        "service": service,
        "category": category,
        "lat": lat,
        "lng": lng,
        "address": _address(tags),
        "phone": tags.get("phone") or tags.get("contact:phone") or "",
        "email": tags.get("email") or tags.get("contact:email") or "",
        "website": tags.get("website") or tags.get("contact:website") or tags.get("url") or "",
        "opening_hours": tags.get("opening_hours") or "",
        "description": tags.get("description") or tags.get("description:en") or "",
        "tags": tags,
        "osm_url": f"https://www.openstreetmap.org/{osm_id}",
        "source": source,
    }


def get_resource(osm_id: str) -> dict | None:
    """Full details of one place, or None if it does not exist. `osm_id` looks like "node/123".
    Overpass first (all tags); if it cannot answer, Nominatim's lookup (fewer tags)."""
    hit = _resource_cache.get(osm_id)
    if hit and time.time() - hit[0] < RESOURCE_TTL_S:
        return hit[1]

    kind, num = osm_id.split("/")
    result, overpass_error = None, None
    try:
        elements = _run_overpass(f"[out:json][timeout:20];{kind}({num});out center tags;", time.time() + 20)
        if not elements:
            return None  # a server answered: there is no such place
        el = elements[0]
        lat = el.get("lat") or (el.get("center") or {}).get("lat")
        lng = el.get("lon") or (el.get("center") or {}).get("lon")
        result = _resource_dict(osm_id, el.get("tags") or {}, lat, lng, OVERPASS_SOURCE)
    except DiscoveryError as exc:
        overpass_error = exc

    if result is None:
        letter = {"node": "N", "way": "W", "relation": "R"}[kind]
        rows = _nominatim_get({"osm_ids": f"{letter}{num}", "format": "jsonv2", "extratags": 1,
                               "addressdetails": 1}, url=NOMINATIM_LOOKUP_URL) if time.time() >= _nominatim_down_until else None
        if rows is None:
            raise DiscoveryError(str(overpass_error) if overpass_error else "no map server answered")
        if not rows:
            return None
        r = rows[0]
        a = r.get("address") or {}
        tags = dict(r.get("extratags") or {})
        tags["name"] = r.get("name") or ""
        for src, dst in (("house_number", "addr:housenumber"), ("road", "addr:street"), ("suburb", "addr:suburb"),
                         ("postcode", "addr:postcode"), ("state", "addr:state")):
            if a.get(src):
                tags[dst] = a[src]
        city = a.get("city") or a.get("town") or a.get("village")
        if city:
            tags["addr:city"] = city
        result = _resource_dict(osm_id, tags, float(r["lat"]), float(r["lon"]), NOMINATIM_SOURCE)

    _resource_cache[osm_id] = (time.time(), result)
    return result


# ---------------------------------------------------------------------------
# Typed location -> coordinates, fixing spelling mistakes on the way
#   1. GeoNames city list (data/cities.tsv, CC BY 4.0) - exact or fuzzy match on ~34,000 cities
#   2. Photon (OpenStreetMap), restricted to places, for areas and neighbourhoods
#   3. Nominatim (OpenStreetMap)
# Examples: "Hyderbad" -> Hyderabad, "Chenai" -> Chennai, "Banglore" -> Bengaluru,
# "Uppal, Hyderbad" -> Uppal, Hyderabad.
# ---------------------------------------------------------------------------
DATA_FILE = Path(__file__).resolve().parent.parent / "data" / "cities.tsv"
INDIA_PHOTON_BBOX = "68.0,6.0,97.6,37.6"     # minLon,minLat,maxLon,maxLat: a box around India (Photon)
INDIA_BOX = (6.0, 37.6, 68.0, 97.6)          # minLat, maxLat, minLon, maxLon


class PlaceNotFound(Exception):
    pass


def _norm(text: str) -> str:
    """lowercase, accents removed, letters/digits/spaces only: 'Hyderābād!' -> 'hyderabad'."""
    import re
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", text.lower())).strip()


def _edits(a: str, b: str) -> int:
    """Edit distance where swapping two neighbouring letters counts as one edit (Yrok -> York)."""
    d = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]
    for i in range(len(a) + 1):
        d[i][0] = i
    for j in range(len(b) + 1):
        d[0][j] = j
    for i in range(1, len(a) + 1):
        for j in range(1, len(b) + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[len(a)][len(b)]


def _max_edits(length: int) -> int:
    return 1 if length <= 5 else 2 if length <= 9 else 3


# ----- city index (loaded once, on first use) -----
_lock = threading.Lock()
_cities: list[dict] = []
_by_key: dict[str, list[int]] = {}
_display: dict[str, str] = {}          # normalised spelling -> how it is written properly
_keys: list[str] = []
_keys_by_first: dict[str, list[str]] = {}
_states: set[str] = set()              # normalised state and country codes, to recognise "Telangana", "IN"


def _load() -> None:
    if _cities or not DATA_FILE.exists():
        return
    with _lock:
        if _cities:
            return
        for line in DATA_FILE.read_text(encoding="utf-8").splitlines():
            name, country, state, lat, lon, pop, spellings = line.split("\t")
            idx = len(_cities)
            _cities.append({"name": name, "country": country, "state": state,
                            "lat": float(lat), "lon": float(lon), "pop": int(pop)})
            _states.update(x for x in (_norm(state), _norm(country)) if x)
            for s in [name] + spellings.split("|"):
                variants = [(s, _norm(s))]
                if _norm(s).endswith(" city"):  # "New York City" is also written "New York"
                    import re as _re
                    variants.append((_re.sub(r"(?i)\s+city$", "", s), _norm(s)[:-5]))
                for spelling, key in variants:
                    if len(key) >= 3:
                        if idx not in _by_key.setdefault(key, []):
                            _by_key[key].append(idx)
                        _display.setdefault(key, spelling)
        _keys.extend(_by_key)
        for k in _keys:
            _keys_by_first.setdefault(k[0], []).append(k)


def _rank(c: dict, near: tuple[float, float] | None) -> float:
    """Bigger cities win; cities close to the user win over same-named ones on the other side of the world."""
    score = math.log10(c["pop"] + 10) * 3
    if near:
        d = _haversine_km(near[0], near[1], c["lat"], c["lon"])
        score += 12 if d < 500 else 6 if d < 2500 else 0
    return score


def match_city(text: str, near: tuple[float, float] | None = None) -> dict | None:
    """The city a typed name refers to, or None: {city, spelling, fixed}. `spelling` is the name
    written properly and `fixed` says the typed text was misspelt. Exact spellings are used as they
    are; close-but-different spellings (within a few letters) are corrected."""
    _load()
    q = _norm(text)
    if len(q) < 3 or not _cities:
        return None

    # India only. A name that exists only abroad ("London", "Sydney") is refused here, and is never "corrected"
    # into an Indian place that merely looks a bit like it.
    indian = [i for i in _by_key.get(q, []) if _cities[i]["country"] == "IN"]
    if q in _by_key and not indian:
        return None

    # candidate cities: exact spelling, or within a few edits of a known spelling
    exact_best = None
    if indian:
        i = max(indian, key=lambda i: _rank(_cities[i], near))
        exact_best = {"city": _cities[i], "spelling": _display[q], "fixed": False}

    fuzzy_best = None
    if len(q) >= 5:  # shorter words are too easy to confuse
        allowed = _max_edits(len(q))
        cutoff = 0.82 if len(q) <= 6 else 0.85
        scored: dict[int, tuple[float, str]] = {}
        sm = difflib.SequenceMatcher(None, q)  # q is compared against every candidate spelling

        def scan(pool: list[str]) -> None:
            for key in pool:
                if key == q or abs(len(key) - len(q)) > allowed:
                    continue
                sm.set_seq2(key)
                if sm.real_quick_ratio() < cutoff or sm.quick_ratio() < cutoff:
                    continue
                ratio = sm.ratio()
                if ratio >= cutoff and _edits(q, key) <= allowed:
                    for i in _by_key[key]:
                        if _cities[i]["country"] != "IN":
                            continue   # India only
                        # the official spelling wins over an alias that is equally close ("Delhi" over "Deli")
                        official = 0.03 if key == _norm(_cities[i]["name"]) else 0
                        if ratio + official > scored.get(i, (0, ""))[0]:
                            scored[i] = (ratio + official, key)

        scan(_keys_by_first.get(q[0], []))  # typos rarely change the first letter, so look there first
        if not scored:
            scan(_keys)
        if scored:
            i = max(scored, key=lambda i: scored[i][0] * 100 + _rank(_cities[i], near))
            fuzzy_best = {"city": _cities[i], "spelling": _display[scored[i][1]], "fixed": True}

    if exact_best and fuzzy_best:
        # a tiny place that happens to share the exact spelling loses to a much bigger, almost identical city
        if exact_best["city"]["pop"] < 200_000 and fuzzy_best["city"]["pop"] >= 10 * (exact_best["city"]["pop"] + 1):
            return fuzzy_best
    return exact_best or fuzzy_best


def _foreign_only(name: str) -> bool:
    """True if this exact name is a known city abroad and there is no city of that name in India."""
    _load()
    q = _norm(name)
    return q in _by_key and not any(_cities[i]["country"] == "IN" for i in _by_key[q])


def _label(m: dict) -> str:
    c = m["city"]
    return ", ".join(p for p in [m["spelling"], c["state"], c["country"]] if p)


# ----- Photon / Nominatim for areas and neighbourhoods -----
_PLACE_WEIGHT = {"city": 6, "town": 5, "borough": 4, "suburb": 4, "quarter": 3, "neighbourhood": 3,
                 "district": 3, "village": 2, "locality": 1, "hamlet": 1}


def _photon_places(query: str, near: tuple[float, float] | None, want_name: str) -> dict | None:
    params = {"q": query, "osm_tag": "place", "limit": 6, "lang": "en", "bbox": INDIA_PHOTON_BBOX}
    if near:
        params["lat"], params["lon"] = near
    try:
        resp = httpx.get(PHOTON_URL, params=params, headers=HEADERS, timeout=SERVER_TIMEOUT_S)
        resp.raise_for_status()
        features = resp.json().get("features", [])
    except (httpx.HTTPError, ValueError) as exc:
        raise DiscoveryError(f"the Photon server did not respond ({exc.__class__.__name__})")

    want = _norm(want_name)
    best, best_score = None, -1.0
    for f in features:
        p = f.get("properties") or {}
        name = p.get("name")
        coords = (f.get("geometry") or {}).get("coordinates")
        if not name or not coords:
            continue
        if (p.get("countrycode") or "").upper() != "IN":
            continue   # India only
        similarity = difflib.SequenceMatcher(None, want, _norm(name)).ratio()
        if similarity < 0.75:
            continue
        lat, lon = coords[1], coords[0]
        score = similarity * 100 + _PLACE_WEIGHT.get(p.get("osm_value"), 0)
        if near:
            d = _haversine_km(near[0], near[1], lat, lon)
            score += 12 if d < 500 else 6 if d < 2500 else 0
        if score > best_score:
            city = p.get("city") or ""
            label = ", ".join(x for x in [name, city if city and city != name else "", p.get("state", ""),
                                          (p.get("countrycode") or "")] if x)
            best, best_score = {"lat": lat, "lon": lon, "label": label, "name": name}, score
    return best


def _nominatim_place(query: str) -> dict | None:
    rows = _nominatim_get({"q": query, "format": "jsonv2", "limit": 1, "addressdetails": 1, "countrycodes": "in"})
    if not rows:
        return None
    r = rows[0]
    a = r.get("address") or {}
    city = a.get("city") or a.get("town") or a.get("village") or a.get("county") or ""
    specific = a.get("suburb") or a.get("neighbourhood") or a.get("city_district") or r.get("name") or ""
    label = ", ".join(x for x in [specific if specific != city else "", city, a.get("state", ""),
                                  (a.get("country_code") or "").upper()] if x)
    return {"lat": float(r["lat"]), "lon": float(r["lon"]),
            "label": label or r["display_name"], "name": specific or city}


# ----- is a point inside India? -----
_country_cache: dict[tuple[float, float], bool] = {}


def in_india(lat: float, lng: float) -> bool:
    """True if the point is in India. A box around India rules out most of the world at once; inside it (which also
    holds parts of Pakistan, Nepal, Bangladesh, Sri Lanka...) the country is asked from a free reverse-geocoding
    service. If no service answers, the box alone decides, so a service outage never blocks people in India."""
    min_lat, max_lat, min_lng, max_lng = INDIA_BOX
    if not (min_lat <= lat <= max_lat and min_lng <= lng <= max_lng):
        return False
    key = (round(lat, 1), round(lng, 1))
    if key in _country_cache:
        return _country_cache[key]
    code = None
    for lookup in (
        lambda: httpx.get("https://api.bigdatacloud.net/data/reverse-geocode-client",
                          params={"latitude": lat, "longitude": lng, "localityLanguage": "en"},
                          headers=HEADERS, timeout=4).json().get("countryCode"),
        lambda: (httpx.get("https://nominatim.openstreetmap.org/reverse",
                           params={"lat": lat, "lon": lng, "format": "jsonv2", "zoom": 3},
                           headers=HEADERS, timeout=4).json().get("address") or {}).get("country_code"),
    ):
        try:
            code = lookup()
        except (httpx.HTTPError, ValueError, AttributeError):
            continue
        if code:
            break
    if not code:
        return True   # nobody answered: inside the India box, so let it through (and do not remember it)
    _country_cache[key] = code.upper() == "IN"
    return _country_cache[key]


# ----- public entry point -----
def geocode(text: str, near: tuple[float, float] | None = None) -> dict:
    """{lat, lon, label, typed, corrected_to}: corrected_to is set only when the spelling was fixed.
    Raises PlaceNotFound if the place cannot be found, DiscoveryError if every server failed."""
    _load()
    typed = text.strip()
    parts = [p.strip() for p in typed.split(",") if p.strip()]
    if not parts or len(_norm(typed)) < 3:
        raise PlaceNotFound(typed)

    # 1) the whole text is one city name (exact or misspelt)
    whole = match_city(typed, near)
    if whole and len(parts) == 1:
        c = whole["city"]
        return {"lat": c["lat"], "lon": c["lon"], "label": _label(whole), "typed": typed,
                "corrected_to": whole["spelling"] if whole["fixed"] else None}

    # 2) split into cities, states/countries and everything else (areas, neighbourhoods)
    cities, areas = [], []
    for part in parts:
        if _norm(part) in _states:
            continue  # "Telangana", "IN": only there to help, nothing to search for
        m = match_city(part, near)
        if m:
            m["part"] = part
            cities.append(m)
        else:
            areas.append(part)

    # "Kondapur, Hyderabad": "Kondapur" is a neighbourhood, not a misspelt "Kundapur" (a town 500 km away). A name
    # that was only guessed by spelling correction, and that is far from the other place named beside it, is an
    # area of that place, not a city of its own.
    sure = [m for m in cities if not m["fixed"]]
    if sure and len(cities) > 1:
        anchor = sure[0]["city"]
        for m in [m for m in cities if m["fixed"]]:
            if _haversine_km(anchor["lat"], anchor["lon"], m["city"]["lat"], m["city"]["lon"]) > 200:
                cities.remove(m)
                areas.append(m["part"])

    def from_city(m: dict) -> dict:
        c = m["city"]
        return {"lat": c["lat"], "lon": c["lon"], "label": _label(m), "typed": typed,
                "corrected_to": m["spelling"] if any(x["fixed"] for x in cities) else None}

    if not cities and not areas:
        # only a state or country was typed ("Telangana", "New York", "France"). An Indian state searches around its
        # biggest city; anything else is not India.
        for part in parts:
            in_state = [c for c in _cities if c["country"] == "IN" and _norm(c["state"]) == _norm(part)]
            if in_state:
                c = max(in_state, key=lambda c: c["pop"])
                return {"lat": c["lat"], "lon": c["lon"], "label": ", ".join(x for x in [c["name"], c["state"], c["country"]] if x),
                        "typed": typed, "corrected_to": None}
        raise PlaceNotFound(typed)

    if not cities:
        # India only: a name that is only known abroad ("London", "Paris, France", "Sydney") is refused here, before
        # the map lookups get a chance to "find" some Indian village with a similar spelling
        for area in areas:
            if _foreign_only(area):
                raise PlaceNotFound(typed)

    if cities and not areas:
        # "City", "City, State", or two known places such as "Hyderabad, Uppal": the smallest one is
        # what the user means, as long as the others are just its surroundings (within 200 km)
        smallest = min(cities, key=lambda m: m["city"]["pop"])
        s = smallest["city"]
        consistent = all(_haversine_km(s["lat"], s["lon"], m["city"]["lat"], m["city"]["lon"]) <= 200 for m in cities)
        return from_city(smallest if consistent else cities[0])

    # "Area, City": the area is what to find; the (corrected) city only gives context
    target = areas[0]
    query = ", ".join([target] + [m["spelling"] for m in cities])
    context = cities[0]["city"] if cities else None

    place, answered, last_error = None, False, None
    for lookup in (lambda: _photon_places(query, near, target), lambda: _nominatim_place(query)):
        try:
            found = lookup()
            answered = True
        except DiscoveryError as exc:
            last_error = exc
            continue
        # sanity check: an area named next to a city must actually be near that city
        if found and (not context or _haversine_km(context["lat"], context["lon"], found["lat"], found["lon"]) <= 150):
            place = found
            break

    if not place:
        if cities:
            return from_city(cities[0])  # the area is unknown: at least search around its city
        if answered or not last_error:
            raise PlaceNotFound(typed)
        raise last_error

    respelt = _norm(target) != _norm(place["name"]) and \
        difflib.SequenceMatcher(None, _norm(target), _norm(place["name"])).ratio() >= 0.75
    return {"lat": place["lat"], "lon": place["lon"], "label": place["label"], "typed": typed,
            "corrected_to": place["name"] if (respelt or any(m["fixed"] for m in cities)) else None}
