"""Crawling a place's own website for a way to book an appointment online, and reading one specific
booking/intake page's form field by field (see the architecture diagram).

Two jobs, kept in one file because the second only exists to serve the first:
  * `crawl()` - the "Site Crawler": given a place's own website, crawls it (politely: robots.txt,
    public addresses only, rate-limited, bounded pages) looking for a way to book an appointment
    online. A free Hugging Face model (see services.py) reads the crawled pages and the links found on
    them to decide whether online booking exists at all, whether it is one generic link or a separate
    one per specialty/department, and whether logging in is required first. The model is only ever
    given links the crawl actually found (a numbered list) and asked to choose from them, and every URL
    it returns is checked against that list before being trusted - it cannot invent an address that
    does not exist on the site. It also lists every ordinary web form found along the way (contact,
    admission, volunteer...), not just appointment booking.
  * `crawl_form()` - the "Form Crawler": reads ONE specific page - a URL the crawl above already found
    - and works out what its web form actually asks for. Deliberately not an LLM step: a form's fields
    are structured markup (<input name=... required>, a <label for=...>), not prose, so parsing the
    HTML directly is both cheaper and more reliable than asking a model to read it.

The same safety rules as web_lookup.py apply throughout (robots.txt, public addresses only,
rate-limited). Many real booking pages do not have their own <form> at all: they embed a third-party
scheduler (Calendly, JotForm...) in an <iframe>; when that happens this module also tries to read the
embedded page itself, since it is just another public URL.
"""
import json
import logging
import re
import time
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

from . import services, web_lookup

log = logging.getLogger("onedegree.form_crawler")

SKIP_INPUT_TYPES = {"hidden", "submit", "button", "image", "reset"}

FIELD_KINDS = (
    # "Doctor Name" and "Specialist Name" must be classified as doctor/specialty, never as full_name just
    # because they contain the word "name" too - checked first, ahead of the (deliberately broad) \bname\b
    # pattern below, so a "pick your doctor" field is never mistaken for "what is your own name" and
    # auto-filled with the signed-in patient's own name.
    # Kept apart from each other: a hospital form's "Department/Specialty" and its "Doctor" are two different
    # questions, one usually feeding the other (pick a specialty, then a doctor within it) - conflating them
    # into one kind would mix up what is remembered for each, and made the chat unable to ask them in the
    # order that actually makes sense (see _reorder_specialty_before_doctor below).
    ("specialty", re.compile(r"specialist|specialty|specialties|speciality|specialities|department", re.I)),
    ("doctor", re.compile(r"doctor|physician|provider", re.I)),
    ("first_name", re.compile(r"first.?name|fname|given.?name", re.I)),
    ("last_name", re.compile(r"last.?name|lname|surname|family.?name", re.I)),
    ("full_name", re.compile(r"\bname\b", re.I)),
    ("email", re.compile(r"e.?mail", re.I)),
    ("phone", re.compile(r"phone|tel(?:ephone)?|mobile|cell", re.I)),
    ("date_of_birth", re.compile(r"birth|\bdob\b", re.I)),
    ("preferred_date", re.compile(r"\bdate\b|preferred.?time|appointment.?date|schedule", re.I)),
    ("insurance", re.compile(r"insurance|payer|policy", re.I)),
    ("reason", re.compile(r"reason|message|comment|note|concern|symptom", re.I)),
    # address parts: answered from the sign-up details (users table), read-only
    ("postal_code", re.compile(r"\bzip\b|postal|post ?code|pin ?code|\bpincode\b", re.I)),
    ("city", re.compile(r"\bcity\b|\btown\b|\bdistrict\b", re.I)),
    ("state", re.compile(r"\bstate\b|\bprovince\b", re.I)),
    ("country", re.compile(r"\bcountry\b", re.I)),
    ("address", re.compile(r"address|street|residence", re.I)),
)

EMBED_PROVIDERS = re.compile(
    r"calendly\.com|jotform\.com|wufoo\.com|acuityscheduling\.com|square\.(?:site|com)|setmore\.com|"
    r"zocdoc\.com|appointlet\.com|typeform\.com|formstack\.com|cognitoforms\.com|myturn\.com|"
    r"nopaperforms\.com|leadsquared\.com|forms\.zohopublic|forms\.zoho\.|zohoforms|docs\.google\.com/forms|"
    r"forms\.gle|forms\.office\.com|forms\.microsoft\.com|tally\.so|paperform\.co|airtable\.com/embed|"
    r"formsite\.com|123formbuilder\.com|smartsheet\.com|hsforms|hubspot\.com|monday\.com|fillout\.com|"
    r"formspree\.io|getform\.io|wpforms|ninjaforms|gravityforms|enquiry|admission", re.I)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _event(events: list[dict], kind: str, message: str) -> None:
    events.append({"time": _now(), "type": kind, "message": message})
    (log.warning if kind == "error" else log.info)("[form-crawl] %s", message)


RENDER_TIMEOUT_MS = 20000


def render_html(url: str) -> str | None:
    """The page's HTML AFTER its JavaScript has run, read with a headless browser. Many sites (Elementor
    MetForm, Wix, React...) draw their forms with JavaScript, so a plain download of the page has none.
    Only call this for a URL that web_lookup._get already fetched (so it is public and robots-allowed).
    Slow (seconds), so callers limit how often they use it. Returns None if it fails."""
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            try:
                page = browser.new_page()
                page.goto(url, wait_until="load", timeout=RENDER_TIMEOUT_MS)
                try:   # give scripts time to draw the form, but a chatty page that never goes idle is still usable
                    page.wait_for_load_state("networkidle", timeout=8000)
                except Exception:
                    pass
                return page.content()
            finally:
                browser.close()
    except Exception as exc:
        log.info("[form-crawl] could not render %s: %s", url, exc)
        return None


# ---------------------------------------------------------------------------
# Reading a form the way a person's browser sees it: inside iframes (third-party form widgets such as
# NoPaperForms, JotForm...), drawn by JavaScript, hidden tracking fields left out.
# ---------------------------------------------------------------------------
_FORMS_JS = """() => {
  const visible = el => {
    const r = el.getBoundingClientRect(), s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
  };
  const labelOf = el => {
    if (el.id) { const l = document.querySelector('label[for="' + CSS.escape(el.id) + '"]'); if (l) return l.innerText; }
    const p = el.closest('label'); if (p) return p.innerText;
    // a <label> written right before the box without being linked to it ("Patient Name*" above a box whose
    // placeholder just says "Name") is the real question
    const before = el.previousElementSibling;
    if (before && before.tagName === 'LABEL' && before.innerText && before.innerText.trim().length < 120) return before.innerText;
    const own = el.getAttribute('aria-label') || el.placeholder || el.getAttribute('title');
    if (own) return own;
    const prev = el.previousElementSibling;
    if (prev && prev.innerText && prev.innerText.length < 120) return prev.innerText;
    const wrap = el.parentElement && el.parentElement.querySelector('label');
    return wrap ? wrap.innerText : '';
  };
  const SKIP = ['hidden', 'submit', 'button', 'image', 'reset'];
  // a styled file picker often hides the real <input type=file> behind its own button: it still counts if its form shows
  const shown = el => visible(el) || ((el.type || '').toLowerCase() === 'file' && el.form && visible(el.form));
  // Dropdown libraries (select2, nice-select, chosen, bootstrap-select...) hide the real <select> and draw their own
  // widget next to it: the hidden <select> is still the question, and it still holds the choices.
  const WIDGET = '.select2, .nice-select, .chosen-container, .bootstrap-select, .selectize-control, .ms-parent, .choices, [class*="select2"], [class*="custom-select"], [class*="dropdown"]';
  const drawnBySelectWidget = el => {
    if (el.tagName !== 'SELECT') return false;
    // the widget sits beside the <select>: in its container, or in the container around that (browsers even pull a
    // <div> out of a <p>, so it can end up one level higher)
    for (const holder of [el.parentElement, el.parentElement && el.parentElement.parentElement]) {
      const w = holder ? holder.querySelector(WIDGET) : null;
      if (w && visible(w)) return true;
    }
    return false;
  };
  let counter = 0;
  const collect = (root, gid) => Array.from(root.querySelectorAll('input,select,textarea'))
    .filter(el => !SKIP.includes((el.type || '').toLowerCase()) && !el.disabled && (shown(el) || drawnBySelectWidget(el)))
    .map(el => {
      // every field is tagged in the page itself, so it can be found again exactly - a page often holds two copies
      // of the same form (desktop / mobile, page / pop-up) whose fields have identical names
      const uid = 'odf' + (counter++);
      el.setAttribute('data-odf', uid);
      const label = (labelOf(el) || '').replace(/\\s+/g, ' ').trim().slice(0, 160);
      const tag = el.tagName.toLowerCase();
      return {uid: uid, gid: gid, name: el.name || '', id: el.id || '', label: label, value: el.value || '',

              type: tag === 'select' ? 'select' : tag === 'textarea' ? 'textarea' : (el.type || 'text').toLowerCase(),
              required: !!el.required || /\\*\\s*$/.test(label) || el.getAttribute('aria-required') === 'true',
              // an option with no value ("Book an Appointment", "Select city") is the prompt, not a choice
              options: tag === 'select' ? (() => { const all = Array.from(el.options).slice(0, 80);
                  const real = all.filter(o => (o.value || '').trim() !== '');
                  return (real.length ? real : all).map(o => o.text.trim()).filter(Boolean); })() : [],
              // the field's own rules, so an answer can be checked BEFORE the form is submitted
              pattern: el.getAttribute('pattern') || '', minlength: el.minLength > 0 ? el.minLength : 0,
              maxlength: el.maxLength > 0 ? el.maxLength : 0, min: el.getAttribute('min') || '', max: el.getAttribute('max') || '',
              placeholder: el.getAttribute('placeholder') || '', title: el.getAttribute('title') || ''};
    });
  // radio buttons that share a name are ONE question whose choices are their labels
  const merge = fields => {
    const out = [], radios = {};
    fields.forEach(f => {
      if (f.type !== 'radio') { out.push(f); return; }
      const key = f.name || f.id;
      if (!radios[key]) {
        const el0 = document.querySelector('[data-odf="' + f.uid + '"]');
        const box = el0 ? (el0.closest('fieldset') || el0.closest('.form-group, .field, div')) : null;
        let head = '';
        if (box) {
          const legend = box.querySelector('legend');
          const lead = Array.from(box.children).find(c => !c.querySelector('input[type=radio]') && !c.matches('input, label') && c.innerText && c.innerText.trim());
          head = ((legend || lead || {}).innerText || '').replace(/\\s+/g, ' ').trim().slice(0, 120);
        }
        radios[key] = Object.assign({}, f, {label: head, options: [], choices: []});
        out.push(radios[key]);
      }
      const choiceLabel = f.label || f.value;
      radios[key].options.push(choiceLabel);
      radios[key].choices.push({uid: f.uid, label: choiceLabel, value: f.value});
      radios[key].required = radios[key].required || f.required;
    });
    return out;
  };
  const groups = Array.from(document.forms).map((f, i) => { f.setAttribute('data-odform', 'odg' + i); return merge(collect(f, 'odg' + i)); })
    .filter(g => g.length);
  if (!groups.length) { const g = merge(collect(document.body || document, '')); if (g.length) groups.push(g); }
  return groups;
}"""

APPLY_BUTTONS = ("Apply Now", "Apply now", "Enquire Now", "Enquire now", "Admission Enquiry", "Enquiry", "Get in touch",
                 "Book an Appointment", "Book Appointment", "Request Appointment", "Request an Appointment",
                 "Make an Appointment", "Contact Us", "Request a callback", "Book Now", "Register")


def field_selector(f: dict) -> str:
    """A CSS selector for exactly one field of a form read by find_form_in_page: the tag put on it in the page itself,
    else its name/id."""
    if f.get("uid"):
        return f'[data-odf="{f["uid"]}"]'
    if f.get("name"):
        return f'[name="{f["name"]}"]'
    return f'[id="{f["id"]}"]'


def _synth_name(label: str, taken: set[str]) -> str:
    """A name for a question that has none (or shares one with another question - a page whose Mobile and Date boxes
    are both called "mob"): made from its wording, so the chat and the live page arrive at the same one."""
    base = re.sub(r"[^a-z0-9]+", "_", re.sub(r"[*:?]+", "", (label or "").lower())).strip("_")[:40] or "field"
    name, n = base, 2
    while name.lower() in taken:
        name, n = f"{base}_{n}", n + 1
    return name


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", re.sub(r"[*:?]+", "", (text or "").lower()))


def _score_group(group: list[dict], prefer: list[dict] | None = None) -> tuple[int, int, int]:
    """(how many of the fields are the ones we were told to expect, how many we understand, how many there are).
    A page often holds several forms; when the caller knows which one it wants (the one it read earlier, by its
    field names and wording) that one wins even if another form on the page looks "more complete"."""
    overlap = 0
    if prefer:
        names = {(p.get("name") or "").lower() for p in prefer if p.get("name")}
        labels = {_slug(p.get("label")) for p in prefer if p.get("label")}
        overlap = sum(3 if f["name"].lower() in names else 1 for f in group
                      if f["name"].lower() in names or _slug(f.get("label")) in labels)
    return (overlap, sum(1 for f in group if f["kind"]), len(group))


def _is_wanted(fields: list[dict], prefer: list[dict] | None) -> bool:
    """True when `fields` is the form `prefer` describes: enough of its fields share the same name with a form
    on the page now (labels alone are too common - nearly every form has a Name and an Email), or, if the wanted
    form has no field names, the wording matches. A page can hold both the real form and a much smaller one (a
    newsletter box, a small "contact us" aside) that happens to share just a name/email field too, so a SINGLE
    shared name is never enough once the real form has several fields of its own - it must share a good fraction
    of them, not just the one or two most forms have anyway."""
    if not prefer:
        return True
    names = {(p.get("name") or "").lower() for p in prefer if p.get("name")}
    if names:
        overlap = sum(1 for f in fields if f["name"].lower() in names)
        needed = 1 if len(names) <= 2 else max(2, len(names) // 3)
        return overlap >= needed
    return _score_group(fields, prefer)[0] > 0


def _safe_to_read(frame, page) -> bool:
    """False for a third-party iframe that is not one of our own site's frames and not a recognised form
    provider (an embedded Google Map, an ad, a chat widget...): never read one of these. Reading `frame.url`
    is not enough - some of them (Google Maps among them) never report a URL to Playwright even once fully
    loaded, so evaluating THEM can simply never return; the src the parent page itself gave the <iframe> is
    asked for instead, which needs nothing from the (possibly stuck) frame itself."""
    if frame == page.main_frame:
        return True
    src = frame.url or ""
    if not src:
        try:
            src = frame.frame_element().get_attribute("src") or ""
        except Exception:
            return False   # the frame is gone, or cannot be reached from here: nothing safe to read
    if not src or src.startswith(("about:", "javascript:", "data:")):
        return True   # a blank/inline frame is part of the page itself, not a third party
    return urlparse(src).netloc == urlparse(page.url).netloc or bool(EMBED_PROVIDERS.search(src))


def _scan_frames(page, prefer: list[dict] | None = None):
    """(frame, fields) of the form that looks most like an intake form across the page and its iframes - or,
    when `prefer` lists the fields of a form read earlier, the form that matches it best."""
    best, best_score = (None, []), (0, 0, 0)
    for frame in page.frames:
        if not _safe_to_read(frame, page):
            continue
        try:
            groups = frame.evaluate(_FORMS_JS)
        except Exception:
            continue   # a frame that is still loading or was removed
        for group in groups:
            fields, seen = [], set()
            for f in group:
                key = (f["name"] or f["id"]).lower()
                label = f["label"] or humanize_name(f["name"] or f["id"]) or f.get("placeholder", "")
                if key and key in seen and f["type"] in ("radio", "checkbox"):
                    continue   # a radio/checkbox group already counted
                fname = f["name"] or f["id"]
                if not key or key in seen:
                    # no name, or one already used by another question on the form: named after its wording instead
                    if not (f["label"] or f.get("placeholder")):
                        continue   # nothing to call it: not a question a person is asked
                    fname = _synth_name(label, seen)
                    key = fname.lower()
                seen.add(key)
                fields.append({"name": fname, "id": f["id"], "type": f["type"],
                               "uid": f.get("uid", ""), "gid": f.get("gid", ""), "choices": f.get("choices", []),
                               "label": label, "required": f["required"], "options": f["options"],
                               "pattern": f.get("pattern", ""), "minlength": f.get("minlength", 0), "maxlength": f.get("maxlength", 0),
                               "min": f.get("min", ""), "max": f.get("max", ""), "placeholder": f.get("placeholder", ""),
                               "title": f.get("title", ""),
                               "kind": _classify(f"{f['name']} {f['id']} {label}")})
            if len(fields) < 2 and any(re.search(r"search|^s$|^q$", (f["name"] + f["label"]).lower()) for f in fields):
                continue   # a site search box
            if any(f["type"] == "password" for f in fields) and len(fields) <= 3:
                continue   # a login form
            score = _score_group(fields, prefer)
            if fields and score > best_score:
                best, best_score = (frame, fields), score
    return best


_FOLDED_TRIGGERS_JS = """() => {
    const out = [];
    document.querySelectorAll('form').forEach(f => {
        if (!f.querySelector('input:not([type=hidden]),textarea,select')) return;
        const r = f.getBoundingClientRect();
        if (r.width > 2 && r.height > 2) return;              // already showing
        // a floating widget keeps its form folded until its tab is clicked: the tabs sit around the form
        let box = f.parentElement;
        for (let up = 0; box && up < 4; up++, box = box.parentElement) {
            box.querySelectorAll('a,button,[role=button],span,div,li').forEach(e => {
                if (e.contains(f) || f.contains(e) || out.includes(e)) return;
                const b = e.getBoundingClientRect(), s = getComputedStyle(e);
                if (b.width < 4 || b.height < 4 || s.visibility === 'hidden') return;
                if (s.cursor !== 'pointer' && !/^(a|button)$/i.test(e.tagName)) return;
                if (e.querySelector('a,button')) return;      // click the innermost tab, not its wrapper
                out.push(e);
            });
            if (out.length) break;
        }
    });
    out.forEach((e, i) => e.setAttribute('data-odtrig', i));
    return out.length;
}"""


def _open_folded_forms(page, prefer):
    """Sticky "Contact us" style widgets fold their form to zero width until the tab is clicked: click the tabs
    around such a form, one at a time, and look again."""
    try:
        page.mouse.move(3, 400)                         # these widgets slide in only once a visitor moves/scrolls
        page.mouse.wheel(0, 300)
        page.wait_for_timeout(1500)
        page.mouse.wheel(0, -300)
        page.wait_for_timeout(300)
        page.evaluate("""() => document.querySelectorAll('[class*="popup"], [class*="modal"], [role="dialog"]').forEach(c => {
            const r = c.getBoundingClientRect();
            if (r.width < 2 || r.height < 2 || c.querySelector('form')) return;      // a welcome pop-up that moving the mouse woke up
            const x = c.querySelector('[class*="close"], [aria-label*="close" i], [data-dismiss]');
            if (x) { try { x.click(); } catch (e) {} }
            if (c.getBoundingClientRect().width > 2) c.style.setProperty('display', 'none', 'important');
        })""")
        page.wait_for_timeout(600)
        frame, fields = _scan_frames(page, prefer)      # waking the widget may already have opened it
        if frame is not None and _is_wanted(fields, prefer):
            return frame, fields
        count = page.evaluate(_FOLDED_TRIGGERS_JS)
    except Exception:
        return None, []
    for i in range(min(count, 6)):
        try:
            tab = page.locator(f"[data-odtrig='{i}']").first
            try:
                tab.hover(timeout=1200)                 # some open on hover, some on click
                page.wait_for_timeout(700)
                _, shown = _scan_frames(page, prefer)
                if not shown:
                    tab.click(timeout=1200)
            except Exception:
                tab.dispatch_event("click")             # a tab tucked half off-screen can't be clicked normally
            page.wait_for_timeout(1000)
            frame, fields = _scan_frames(page, prefer)
            if frame is not None and (not prefer or _is_wanted(fields, prefer)):
                return frame, fields
        except Exception:
            continue
    return None, []


def find_form_in_page(page, prefer: list[dict] | None = None):
    """Looks for a form on the live Playwright `page` - in the page itself and in every iframe on it - and,
    if none is showing, clicks the site's own "Apply Now" / "Enquire" style button once and looks again.
    `prefer` ({name, label} of the fields of the form wanted) picks that form when the page has several.
    Returns (frame, fields); frame is None when nothing was found."""
    try:
        page.wait_for_load_state("networkidle", timeout=8000)
    except Exception:
        pass
    frame, fields = _scan_frames(page, prefer)
    if frame is not None and (not prefer or _is_wanted(fields, prefer)):
        return frame, fields
    frame, fields = _open_folded_forms(page, prefer)
    if frame is not None:
        return frame, fields
    for label in APPLY_BUTTONS:
        try:
            # a page often has more than one button with this wording (a hidden duplicate for another screen size,
            # a decoy in an unopened tab): `.first` would pick whichever comes first in the HTML, hidden or not, and
            # a click that never lands (because it never becomes visible) only wastes this label's turn - so every
            # match is looked at, and the first one actually showing on screen right now is the one clicked
            candidates = list(page.get_by_role("button", name=re.compile(re.escape(label), re.I)).all()) + \
                         list(page.get_by_role("link", name=re.compile(re.escape(label), re.I)).all())
            target = next((c for c in candidates if c.is_visible()), None)
            if target is not None:
                try:
                    target.click(timeout=3000)
                except Exception:
                    # something (a sticky header, a banner, even the button's OWN floating bar) covers it, so a real
                    # click - forced or not - lands on WHATEVER is on top at that pixel, not the button; dispatching
                    # the click straight at the button sidesteps the geometry question and reaches its own listener
                    try:
                        target.evaluate("e => e.dispatchEvent(new MouseEvent('click', {bubbles: true, cancelable: true, view: window}))")
                    except Exception:
                        continue
                page.wait_for_timeout(2500)
                frame, fields = _scan_frames(page, prefer)
                if frame is not None and (not prefer or _is_wanted(fields, prefer)):
                    return frame, fields
        except Exception:
            continue
    # last resort: some sites only show the intake form at a phone-sized width (a section their desktop layout
    # simply never reveals, the rest of the page working normally at any size) - never tried until now because
    # every step above is worth trying first at the width most pages actually expect
    try:
        original = page.viewport_size
        page.set_viewport_size({"width": 390, "height": 844})
        page.wait_for_timeout(600)
        frame, fields = _scan_frames(page, prefer)
        if frame is None:
            frame, fields = _open_folded_forms(page, prefer)
        if frame is not None and (not prefer or _is_wanted(fields, prefer)):
            return frame, fields   # stays at this width: the form the rest of the session works with lives here
        if original:
            page.set_viewport_size(original)
    except Exception:
        pass
    if not prefer:
        return None, []
    frame, fields = _scan_frames(page, prefer)
    return (frame, fields) if frame is not None and _is_wanted(fields, prefer) else (None, [])


def browser_read_form(url: str) -> dict | None:
    """Opens `url` in a headless browser and reads the form it shows (see find_form_in_page):
    {"fields": [...], "frame_url": address of the iframe the form lives in, or None if on the page itself}."""
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            try:
                page = browser.new_page(viewport={"width": 1280, "height": 900})
                page.goto(url, wait_until="load", timeout=RENDER_TIMEOUT_MS)
                frame, fields = find_form_in_page(page)
                if frame is None:
                    return None
                return {"fields": fields, "frame_url": None if frame == page.main_frame else frame.url}
            finally:
                browser.close()
    except Exception as exc:
        log.info("[form-crawl] could not read %s with a browser: %s", url, exc)
        return None


def _label_for(field, soup: BeautifulSoup) -> str:
    fid = field.get("id")
    if fid:
        lbl = soup.find("label", attrs={"for": fid})
        if lbl:
            return lbl.get_text(" ", strip=True)
    parent_label = field.find_parent("label")
    if parent_label:
        return parent_label.get_text(" ", strip=True)
    before = field.find_previous_sibling()   # a <label> written right before the box, not linked to it
    if before is not None and before.name == "label" and before.get_text(strip=True):
        return before.get_text(" ", strip=True)
    return field.get("placeholder") or field.get("aria-label") or ""


PERSONAL_KINDS = {"first_name", "last_name", "full_name", "email", "phone", "date_of_birth",
                  "address", "city", "state", "postal_code", "country"}
# A field that asks about a specific role ("Parent's Name", "Student Name", "Emergency contact phone"):
# the account holder could be that person or someone else, so it is never filled in without asking.
ROLE_RE = re.compile(r"parent|guardian|student|child(?:ren)?\b|kid|patient|spouse|husband|wife|father|mother|"
                     r"emergency|next.?of.?kin|relative|referr|employer|contact.?person|"
                     r"pupil|ward\b|sibling|dependent|reference", re.I)


def _classify(hay: str) -> str | None:
    for kind, pattern in FIELD_KINDS:
        if pattern.search(hay):
            if kind in PERSONAL_KINDS and ROLE_RE.search(hay):
                return "role_" + kind   # e.g. role_full_name: needs the person's confirmation
            return kind
    return None


def _extract_fields(form, soup: BeautifulSoup) -> list[dict]:
    fields, seen = [], set()
    for tag in form.find_all(["input", "select", "textarea"]):
        # a select element's real kind is its tag, never a stray "type" attribute some sites paste onto it
        # (e.g. <select type="text" ...> on ambicareclinics.com) - trust that over what the attribute says
        ftype = "select" if tag.name == "select" else (tag.get("type") or "text").lower()
        if ftype in SKIP_INPUT_TYPES:
            continue
        name = tag.get("name") or tag.get("id") or ""
        label = _label_for(tag, soup)
        if name and name.lower() in seen and ftype in ("radio", "checkbox"):
            continue   # the rest of a radio/checkbox group
        if not name or name.lower() in seen:
            # no name, or one another question already has (Mobile and Date both called "mob"): named after its wording
            if not (label or tag.get("placeholder")):
                continue   # nothing to call it and no way to point at it: not a question a person is asked
            name = _synth_name(label or tag.get("placeholder") or "", seen)
        seen.add(name.lower())
        options = []
        if ftype == "radio":
            # radio buttons sharing a name are one question; their labels are the choices
            group = [r for r in form.find_all("input", attrs={"type": "radio"}) if (r.get("name") or r.get("id")) == name]
            options = list(dict.fromkeys(_label_for(r, soup) or r.get("value") or "" for r in group))
            options = [o for o in options if o]
            legend = (tag.find_parent("fieldset") or tag).find("legend") if tag.find_parent("fieldset") else None
            label = (legend.get_text(" ", strip=True) if legend else "") or humanize_name(name)
        if tag.name == "select":
            tags = tag.find_all("option")
            options = [o.get_text(" ", strip=True) for o in tags]
            first = options[0] if options else ""
            real = [o.get_text(" ", strip=True) for o in tags if (o.get("value") or "").strip()]
            if real and len(real) < len(tags):
                options = real    # an option with no value is the prompt, not a choice
            if not label and re.match(r"^\s*(select|choose|--)", first, re.I):
                label = re.sub(r"^\s*(select|choose|--)\s*(an?|the|your)?\s*", "", first, flags=re.I).strip(" -:")
            options = list(dict.fromkeys(o for o in options if o and not re.match(r"^\s*(select|choose|--)", o, re.I)))
        label = label or humanize_name(name)   # "cityId" -> "City": a question a person can read
        kind = _classify(f"{name} {tag.get('id', '')} {label}")
        field = {"name": name[:80], "type": ftype, "label": label[:100] or None,
                 "required": tag.has_attr("required") or bool(re.search(r"\*\s*$", label or "")), "kind": kind}
        if tag.name == "select" or ftype == "radio":
            field["options"] = options[:80]
        fields.append(field)
    return fields


def humanize_name(name: str) -> str:
    """A field's technical name as a readable label: "cityId" -> "City", "patient_mobile_no" -> "Patient mobile no"."""
    text = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", name or "")
    text = re.sub(r"[_\-.]+", " ", text).strip()
    text = re.sub(r"\s+(id|ids)$", "", text, flags=re.I)
    return (text[:1].upper() + text[1:]).strip() or (name or "")


def _is_search_form(form) -> bool:
    """A site's header/nav search box, not a booking form: it has exactly one visible field, and that
    field is clearly a search box (type=search, name like "s"/"q", or a "Search..." placeholder)."""
    if (form.get("role") or "").lower() == "search":
        return True
    visible = [f for f in form.find_all(["input", "select", "textarea"])
              if (f.get("type") or "text").lower() not in SKIP_INPUT_TYPES]
    # A filter or search box: a couple of fields (a dropdown, a "type a name here" box) and a button that only says
    # Search / Filter / Find - a directory of doctors, products or branches, not a form that sends anything to anyone.
    buttons = [(b.get_text(" ", strip=True) or b.get("value") or "").strip()
               for b in form.find_all(["button", "input"]) if b.name == "button" or (b.get("type") or "").lower() in ("submit", "button")]
    if visible and len(visible) <= 4 and buttons and all(
            re.fullmatch(r"(?i)(search|find|filter|go|show|look ?up|apply filters?|search now|find now|reset|clear)\W*", b) for b in buttons if b):
        return True
    if 1 < len(visible) <= 3 and not any(f.name == "textarea" or (f.get("type") or "").lower() in ("email", "tel")
                                         for f in visible) \
            and any(re.search(r"search|filter|keyword|find |type .{0,20}here", f"{f.get('placeholder') or ''} {f.get('name') or ''}", re.I)
                    for f in visible):
        return True
    if len(visible) != 1:
        return False
    f = visible[0]
    name = (f.get("name") or f.get("id") or "").lower()
    hay = f"{(f.get('type') or '').lower()} {name} {(f.get('placeholder') or '').lower()}"
    return bool(re.search(r"\bsearch\b|^s$|^q$|^query$", hay))


def best_form(forms: list, soup: BeautifulSoup):
    """The form on the page that most looks like an intake form: most fields recognized as a name,
    contact detail, date etc. (never a lone search box), not just whichever has the most fields.
    Returns (the <form> element or None, its fields)."""
    best_form_el, best_fields = None, []
    best_score = (-1, -1)
    for form in forms:
        if _is_search_form(form):
            continue
        fields = _extract_fields(form, soup)
        score = (sum(1 for f in fields if f["kind"]), len(fields))
        if score > best_score:
            best_score, best_form_el, best_fields = score, form, fields
    return best_form_el, best_fields


def _pick_form(forms: list, soup: BeautifulSoup) -> tuple[list[dict], str | None]:
    form, fields = best_form(forms, soup)
    return fields, (form.get("action") if form is not None else None)


def _reorder_specialty_before_doctor(fields: list[dict]) -> list[dict]:
    """A "Doctor" question makes sense only once the "Department/Specialty" it belongs to is known - a
    hospital's own cascading dropdown reflects that, but the raw HTML the two are written in does not
    always list them in that order. Moves specialty right before doctor when the page had it the other
    way round; leaves everything else exactly where it was."""
    specialty_i = next((i for i, f in enumerate(fields) if f.get("kind") == "specialty"), None)
    doctor_i = next((i for i, f in enumerate(fields) if f.get("kind") == "doctor"), None)
    if specialty_i is not None and doctor_i is not None and specialty_i > doctor_i:
        specialty_field = fields.pop(specialty_i)
        fields.insert(doctor_i, specialty_field)
    return fields


def crawl_form(url: str) -> dict:
    """Reads `url` (one booking page) and returns its fields, or notes that it could not be read /
    has no readable form. Never submits anything - this only looks at what a form asks for."""
    events: list[dict] = []
    result = {"form_url": url, "status": "ok", "usable": False, "requires_login": False,
             "fields": [], "form_action": None, "embed_url": None}
    _event(events, "crawl_start", f"Form crawl start: {url}")

    if not web_lookup._allowed(url):
        result["status"] = "blocked"
        _event(events, "error", "robots.txt does not allow reading this page")
        result["log"] = events
        return result
    try:
        final, html = web_lookup._get(url)
    except web_lookup.WebError as exc:
        result["status"] = "unreachable"
        _event(events, "error", f"Could not load the page: {exc}")
        result["log"] = events
        return result
    result["form_url"] = final

    soup = BeautifulSoup(html, "html.parser")
    forms = soup.find_all("form")
    if not forms:   # the page may draw its form with JavaScript: look at it the way a browser does
        rendered = render_html(final)
        if rendered:
            html = rendered
            soup = BeautifulSoup(html, "html.parser")
            forms = soup.find_all("form")
            if forms:
                _event(events, "page", "The form on this page is drawn by JavaScript: read it with a browser")
    fields, action = _pick_form(forms, soup) if forms else ([], None)
    if fields:
        result["form_action"] = urljoin(final, action) if action else final
        _event(events, "page", f"Found a web form on the page with {len(fields)} usable field(s)")
    elif forms:
        _event(events, "skip", "The only form(s) on this page look like site search, not a booking form")

    if not fields:
        iframe = next((f for f in soup.find_all("iframe", src=True) if EMBED_PROVIDERS.search(f["src"])), None)
        if iframe:
            embed_url = urljoin(final, iframe["src"])
            result["embed_url"] = embed_url
            _event(events, "page", f"No form on the page itself; found an embedded booking widget: {embed_url}")
            if web_lookup._allowed(embed_url):
                try:
                    _efinal, ehtml = web_lookup._get(embed_url)
                    esoup = BeautifulSoup(ehtml, "html.parser")
                    eforms = esoup.find_all("form")
                    if not eforms and (erendered := render_html(embed_url)):   # the widget draws its form with JavaScript
                        esoup = BeautifulSoup(erendered, "html.parser")
                        eforms = esoup.find_all("form")
                    fields, _eaction = _pick_form(eforms, esoup) if eforms else ([], None)
                    if fields:
                        _event(events, "page", f"Read {len(fields)} field(s) from the embedded widget")
                    else:
                        _event(events, "skip", "The embedded widget did not expose a readable form "
                                              "(it likely builds its fields with JavaScript)")
                except web_lookup.WebError as exc:
                    _event(events, "skip", f"Could not load the embedded widget: {exc}")
            else:
                _event(events, "skip", "The embedded widget's robots.txt does not allow reading it")
        else:
            _event(events, "skip", "No web form (or a recognized booking widget) was found on this page")

    if not fields:   # nothing readable in the HTML: read it the way a person's browser sees it (iframes, JavaScript)
        seen_by_browser = browser_read_form(final)
        if seen_by_browser and seen_by_browser["fields"]:
            fields = seen_by_browser["fields"]
            result["frame_url"] = seen_by_browser["frame_url"]
            where = "inside an embedded widget" if seen_by_browser["frame_url"] else "on the page"
            _event(events, "page", f"Read {len(fields)} field(s) {where} with a browser")

    if fields and any(f["type"] == "select" and len(f.get("options") or []) <= 1 for f in fields):
        # a dropdown whose choices the HTML does not hold (an Angular / JavaScript page fills them in): the browser sees them
        seen_by_browser = browser_read_form(final)
        if seen_by_browser and len(seen_by_browser["fields"]) >= len(fields) and \
                sum(len(f.get("options") or []) for f in seen_by_browser["fields"]) > sum(len(f.get("options") or []) for f in fields):
            fields = seen_by_browser["fields"]
            result["frame_url"] = seen_by_browser["frame_url"]
            _event(events, "page", f"Read {len(fields)} field(s) with a browser, which sees the dropdown choices the page loads itself")

    result["fields"] = fields = _reorder_specialty_before_doctor(fields)
    kinds = {f["kind"].removeprefix("role_") for f in fields if f["kind"]}   # "Parent's name" still counts as a name field
    has_identity = bool({"first_name", "last_name", "full_name"} & kinds)
    has_contact = bool({"phone", "email"} & kinds)
    result["usable"] = bool(fields) and has_identity and has_contact
    result["requires_login"] = not fields and bool(re.search(r"\btype=[\"']password[\"']|log[- ]?in required|"
                                                             r"sign[- ]?in to continue", html, re.I))
    _event(events, "goal", f"Goal resolved: usable={result['usable']} ({len(fields)} field(s))")
    _event(events, "done", "Form crawl finished")
    result["log"] = events
    return result


# ---------------------------------------------------------------------------
# The "Book appointment" site crawler
# ---------------------------------------------------------------------------
MAX_PAGES = 15
MAX_RENDERED_PAGES = 4  # pages re-read with a real browser because their form is drawn by JavaScript (slow)
MAX_CANDIDATE_LINKS = 40

APPT_RE = re.compile(r"\bbook(?:ing)?\b|appointment|schedule.*visit|make.*appointment|patient portal|"
                     r"request.*visit|\breserv|\bconsult", re.I)
DOCTOR_RE = re.compile(r"doctor|physician|specialist|department|our[- ]?team|provider|find[- ]a[- ]doctor|"
                       r"meet[- ]the|staff|services?\b", re.I)
SKIP_RE = re.compile(r"privacy|terms|cookie|sitemap|blog|news|log[- ]?in|sign[- ]?in", re.I)


def _score(url: str, text: str) -> int:
    hay = (url + " " + text).lower()
    if SKIP_RE.search(hay):
        return -1
    score = 0
    if APPT_RE.search(hay):
        score += 3
    if DOCTOR_RE.search(hay):
        score += 1
    return score


def _canon(url: str) -> str:
    """Treats "http://host", "http://host/" and "http://host/foo/" the same as "http://host/foo":
    different pages sometimes link to a site's own pages with or without a trailing slash, and
    without this the crawler could waste its page budget fetching the same page twice."""
    parsed = urlparse(url)
    path = (parsed.path or "/").rstrip("/") or "/"
    if re.fullmatch(r"/(?:index|home|default)(?:\.(?:html?|php|aspx?))?", path, re.I):
        path = "/"   # "/index", "/index.php" and "/" are the same home page
    return f"{parsed.scheme}://{parsed.netloc}{path}"


def _related_host(link_host: str | None, site_host: str) -> bool:
    """True for the site's own host AND its subdomains - real hospital sites often run their booking
    system on a sibling subdomain (e.g. the main site on "example.org" links to "app.example.org" or
    "booking.example.org" for the actual appointment form)."""
    if not link_host:
        return False
    base = site_host[4:] if site_host.startswith("www.") else site_host
    link_base = link_host[4:] if link_host.startswith("www.") else link_host
    return link_base == base or link_base.endswith("." + base)


def _page_links(html: str, page_url: str, host: str) -> list[tuple[str, str]]:
    soup = BeautifulSoup(html, "html.parser")
    out = []
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if re.match(r"^(javascript|mailto|tel|data|file|ftp|sms|about|blob|vbscript):", href, re.I):
            continue
        url = urljoin(page_url, href).split("#")[0]
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https") or not _related_host(parsed.hostname, host):
            continue
        out.append((url, a.get_text(" ", strip=True)[:100]))
    return out


FORM_RE = re.compile(r"apply|application|intake|enrol|admission|request|contact|inquir|enquir|help[- ]?desk|volunteer|"
                     r"donat|referral|\bform|sign[- ]?up|get[- ]help|assistance|register|career|scholarship|grievance|"
                     r"complain|redress|feedback|counsel|callback|call[- ]?back|visit|tour|book|trial|demo|quote|"
                     r"membership|join|support|reach[- ]us|get[- ]in[- ]touch", re.I)


GENERIC_SUBMIT_RE = re.compile(r"^(submit|send|go|search|ok|save|continue|next|post|enter|click here)\W*$", re.I)


# Words a form-building plugin puts in its own ids/classes ("forminator-module-36", "forminator-ui",
# "ninja-forms-form", "hs-form"): they say what BUILT the form, never what the form is for, so an id/class made only
# of these (plus numbers) is not a usable name - the search moves on to a heading, the page title, or the address.
_GENERIC_LABEL_WORDS = {"form", "forms", "module", "ui", "custom", "design", "bold", "default", "ajax", "field",
                        "fields", "input", "builder", "widget", "block", "container", "wrap", "wrapper", "holder",
                        "box", "panel", "section", "embed", "iframe", "plugin", "forminator", "ninja", "hs", "hubspot",
                        "freeform", "typeform", "metform", "gravity", "gform", "cf7", "wpcf7", "wpforms", "fluent",
                        "fluentform", "caldera", "formidable", "jetpack", "elementor"}


def _readable(ident: str) -> str:
    """"contact-form-7" -> "contact form 7"; an auto-generated id (mostly digits/hex, wp/elementor
    prefixes, very short, or made only of a form-plugin's own boilerplate words) is not a name."""
    text = re.sub(r"[-_]+", " ", re.sub(r"(?<=[a-z])(?=[A-Z])", " ", ident or "")).strip()   # also "correctionForm"
    if len(text) < 4 or re.search(r"\d{3,}|^[0-9a-f ]{8,}$|validate", text, re.I):
        return ""
    words = re.findall(r"[a-z]+|\d+", text.lower())
    if all(w in _GENERIC_LABEL_WORDS or w.isdigit() for w in words):
        return ""
    return text


def _form_label(form, soup: BeautifulSoup, page_url: str = "") -> str:
    """A human name for a form, from the most specific clue to the least: its aria-label/title, the
    legend or heading inside it, its own submit button ("Book Appointment"), the heading just above
    it, a readable id/name, the page title, the page address. Never empty."""
    heading = form.find(["legend", "h1", "h2", "h3", "h4"])
    submit_text = next((t for t in ((b.get("value") or b.get_text(" ", strip=True) or "").strip()
                                    for b in form.find_all(["button", "input"])
                                    if b.name == "button" or (b.get("type") or "").lower() in ("submit", "button"))
                        if t and not GENERIC_SUBMIT_RE.match(t)), "")
    prev = form.find_previous(["h1", "h2", "h3"])
    slug = urlparse(page_url).path.rstrip("/").rsplit("/", 1)[-1]
    css_name = next((_readable(c) for c in (form.get("class") or []) if re.search(r"form", c, re.I) and _readable(c)), "")
    for text in ((form.get("aria-label") or form.get("title") or "").strip(),
                 heading.get_text(" ", strip=True) if heading else "",
                 _readable(form.get("id") or "") or _readable(form.get("name") or "") or css_name,
                 submit_text,
                 prev.get_text(" ", strip=True) if prev else "",
                 soup.title.get_text(" ", strip=True) if soup.title else "",
                 _readable(slug).title()):
        if text:
            return text[:70][:1].upper() + text[:70][1:]
    return "Online form"


FORM_TYPES = (   # (name shown on the button, words that give it away), most specific first
    ("Appointment form", r"appointment|\bbook(?:ing)?\b|consult|schedule|reserv|\bvisit\b"),
    ("Job application form", r"career|\bjobs?\b|vacanc|resume|\bcv\b|hiring"),
    ("Volunteer form", r"volunteer"),
    ("Donation form", r"donat|contribut"),
    ("Feedback form", r"feedback|review|complain|testimonial"),
    ("Newsletter form", r"newsletter|subscribe|mailing list"),
    ("Application / intake form", r"appl(?:y|ication)|intake|enrol|eligib|assistance|referral"),
    ("Contact form", r"contact|touch|reach|enquir|inquir|query|call ?back|message|help|details below|write to"),
)

# Login / account sign-up forms are the only forms never offered as buttons.
ACCOUNT_RE = re.compile(r"log[- ]?in|sign[- ]?in|sign[- ]?up|signup|create.{0,12}account|forgot|password", re.I)


def _is_blog_comment_form(form) -> bool:
    """WordPress's own "Leave a Reply" box under a blog post: not something a visitor fills in to reach the
    place, so - like a login form - it is never offered as a form to fill in."""
    ident = f"{form.get('id') or ''} {' '.join(form.get('class') or [])}".lower()
    action = (form.get("action") or "").lower()
    return "commentform" in ident or "comment-form" in ident or "wp-comments-post.php" in action


def _form_text(form, label: str, fields: list[dict], page_url: str) -> str:
    """Everything that says what a form is for, lower-cased: its name, page address, submit button,
    id/class and field names."""
    submits = [(b.get("value") or b.get_text(" ", strip=True) or "")
               for b in form.find_all(["button", "input"]) if (b.get("type") or "submit").lower() == "submit"]
    return " ".join([label, urlparse(page_url).path, " ".join(submits), form.get("id") or "",
                     " ".join(form.get("class") or []),
                     " ".join(f"{f['name']} {f['label'] or ''}" for f in fields)]).lower()


def _form_type(hay: str, fields: list[dict]) -> str | None:
    """The kind of form (see FORM_TYPES), or None when it fits none of them - then the form's own name
    is shown instead."""
    for name, words in FORM_TYPES:
        if re.search(words, hay):
            return name
    kinds = {(f["kind"] or "").removeprefix("role_") for f in fields}
    # short lead-capture pop-ups (Name + Phone, maybe a dropdown) whose page gives no clue what they are FOR:
    # a plain, honest name beats showing the page's heading or title as if it described the form
    if "phone" in kinds and not any(f["type"] == "textarea" for f in fields) and len(fields) <= 4:
        return "Enquiry form"
    return None


def _page_form(html: str, page_url: str) -> dict | None:
    """The form on this page that looks like a real form to fill in (see best_form), or None. Site
    search boxes, filters and login/sign-up forms do not count."""
    soup = BeautifulSoup(html, "html.parser")
    form, fields = best_form(soup.find_all("form"), soup)
    person_kinds = {"first_name", "last_name", "full_name", "email", "phone", "date_of_birth"}
    kinds = {(f["kind"] or "").removeprefix("role_") for f in fields}
    # it must ask who the person is - and how to reach them, or carry a message: a form of only a name and a
    # dropdown or two is a filter (a doctors directory, a product list), not something that sends anything anywhere
    collects_contact = bool(kinds & {"email", "phone"}) or any(f["type"] == "textarea" for f in fields) or len(fields) >= 5
    if form is not None and _is_blog_comment_form(form):
        return None
    if form is not None and fields and any((f["kind"] or "").removeprefix("role_") in person_kinds for f in fields) and collects_contact:
        label = _form_label(form, soup, page_url)
        hay = _form_text(form, label, fields, page_url)
        newsletter = re.search(FORM_TYPES[5][1], hay)   # "sign up for our newsletter" is not an account form
        if any(f["type"] == "password" for f in fields) or (ACCOUNT_RE.search(hay) and not newsletter):
            return None   # a login / account sign-up form: never shown
        # The type comes from the form's visible NAME (its heading/label) and page address only. Ids, CSS
        # classes and field names are often a site template's leftovers (a school's contact form whose id
        # is "appointment_form"), so they must not decide what a form is called.
        name_text = f"{label} {urlparse(page_url).path}".lower()
        ftype = _form_type(name_text, fields) or label   # no known type: the form's own name says what it is
        quality, placement = _form_quality(form, fields, page_url, ftype)
        return {"url": page_url, "label": label, "type": ftype, "field_count": len(fields), "embedded": False,
                "quality": quality, "placement": placement}
    iframe = next((f for f in soup.find_all("iframe", src=True) if EMBED_PROVIDERS.search(f["src"])), None)
    if iframe:   # no form of its own, but an embedded booking/intake widget (a third-party form service)
        title = soup.title.get_text(" ", strip=True) if soup.title else ""
        src = iframe["src"].lower()
        if re.search(r"calendly|acuity|zocdoc|setmore|appointlet|square\.", src):
            ftype = "Appointment booking form"
        elif re.search(r"nopaperforms|leadsquared|admission|enquiry|enquire|register|apply|application", src):
            ftype = "Application / enquiry form"
        elif re.search(r"contact|message", src):
            ftype = "Contact form"
        else:
            ftype = "Online form"
        return {"url": page_url, "label": (title or ftype)[:80], "type": ftype, "field_count": 0, "embedded": True}
    return None


TYPE_PATH_WORDS = {   # words in a page address that say the page is really about that kind of form
    "appointment": r"appointment|book|schedule|consult", "contact": r"contact|reach|touch|enquir|inquir",
    "application": r"appl(y|ication)|admission|intake|enrol", "job": r"career|job|vacanc",
    "volunteer": r"volunteer", "donation": r"donat", "feedback": r"feedback|review",
}


def _form_quality(form, fields: list[dict], page_url: str, ftype: str) -> tuple[int, str]:
    """How much this looks like THE proper form of its kind (higher is better), and where on the page it sits.
    A form that is complete, sits in the page's main content, has its own Submit button and lives on a page about
    that very subject beats a copy in a footer, a pop-up or a sidebar."""
    recognised = sum(1 for f in fields if f["kind"])   # fields we understand: name, phone, email, date...
    score = 3 * recognised + min(len(fields), 8)
    if form.find(["button", "input"], attrs={"type": re.compile(r"^submit$", re.I)}) or form.find("button", attrs={"type": None}):
        score += 2   # it has a Submit button of its own
    placement = "page"
    for parent in form.parents:
        name = getattr(parent, "name", "") or ""
        blob = " ".join([" ".join(parent.get("class") or []) if hasattr(parent, "get") else "", (parent.get("id") or "") if hasattr(parent, "get") else ""]).lower()
        if name in ("footer", "header", "nav", "aside") or re.search(r"footer|sidebar|widget-area", blob):
            placement = "footer or sidebar"
            break
        if re.search(r"popup|modal|newsletter|subscribe|exit-intent|cookie", blob):
            placement = "pop-up"
            break
        if name in ("main", "article") or (hasattr(parent, "get") and parent.get("role") == "main"):
            placement = "main content"
            break
    score += {"main content": 3, "page": 0, "footer or sidebar": -4, "pop-up": -5}[placement]
    path = urlparse(page_url).path.lower()
    for key, words in TYPE_PATH_WORDS.items():
        if key in (ftype or "").lower() and re.search(words, path):
            score += 3   # a page about exactly this (e.g. /book-appointment for the Appointment form)
            break
    return score, placement


def _dedupe_forms(forms: list[dict]) -> list[dict]:
    """One entry per kind of form. The same form is often repeated on many pages (a contact box in every footer,
    the same enquiry form on each department page), and two entries with the same meaning - same type, or the same
    name - would only confuse the person. Of several with the same meaning the PROPER one is kept: the best by
    `quality` (complete, in the page's main content, with its own Submit button, on a page about that subject),
    then the one with the most fields."""
    def rank(f: dict) -> tuple:
        return (f.get("quality", 0), f.get("field_count") or 0)

    best: dict[str, dict] = {}
    order: list[str] = []
    for f in forms:
        key = (f.get("type") or f.get("label") or "").strip().lower()
        if key not in best:
            best[key] = f
            order.append(key)
        elif rank(f) > rank(best[key]):
            best[key] = f
    return [best[k] for k in order]


def _crawl_snippet(text: str) -> str:
    """Lines that mention appointments, booking or doctors, plus a little context each."""
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    keep: list[str] = []
    for i, ln in enumerate(lines):
        if len(ln) < 220 and (APPT_RE.search(ln) or DOCTOR_RE.search(ln)):
            for j in range(max(0, i - 1), min(len(lines), i + 2)):
                if lines[j] not in keep:
                    keep.append(lines[j])
    return "\n".join(keep)[:2000]


def _ask_llm(place_name: str, category: str, page_texts: list[tuple[str, str]],
            candidate_links: dict[str, str]) -> tuple[dict | None, str | None]:
    if not services.configured() or not candidate_links:
        return None, None
    snippets = "\n---\n".join(f"{url}\n{_crawl_snippet(text)}" for url, text in page_texts if _crawl_snippet(text))[:6000]
    if not snippets:
        return None, None
    links_block = "\n".join(f"{i + 1}. {url} -- \"{text}\"" for i, (url, text) in
                            enumerate(list(candidate_links.items())[:MAX_CANDIDATE_LINKS]))
    prompt = (
        "You are looking at pages crawled from a healthcare website to find out how a patient can book an "
        f"appointment online. Place: {place_name}" + (f" ({category})" if category else "") + ".\n\n"
        "TEXT SNIPPETS FROM THE PAGES (lines mentioning appointments, booking or doctors):\n" + snippets + "\n\n"
        "LINKS FOUND ON THE SITE (choose URLs ONLY from this numbered list, copied exactly, never invent one):\n" +
        links_block + "\n\n"
        "Reply with JSON only, no other text:\n"
        '{"has_appointment": <true/false>, "appointment_url": <one URL from the list above, or null>, '
        '"requires_login": <true only if the text says a patient account or login is required first>, '
        '"specialties": [{"name": <department or doctor type, e.g. "Neurology">, '
        '"url": <one URL from the list above, or null>, '
        '"doctors": [{"name": <a named doctor under this specialty, e.g. "Dr. Jane Doe">, '
        '"url": <that doctor\'s OWN booking URL from the list above, or null to use the specialty\'s url>}]}]}\n'
        "Rules: If every specialty shares the same one booking link, leave specialties as an empty list and just "
        "set appointment_url. Only list a specialty if the text shows it has its OWN different booking or contact "
        "link, OR if it names individual doctors. List AT MOST 3 doctors per specialty (pick any 3 if there are "
        "more) - only include doctors whose names are actually written in the text, never invent one; leave "
        "doctors as an empty list if no individual doctors are named for that specialty. If nothing on the site "
        "suggests appointments can be booked online, set has_appointment to false, appointment_url to null and "
        "specialties to an empty list."
    )
    answer = services.chat(prompt, max_tokens=700)
    if not answer:
        return None, None
    content, provider = answer
    try:
        parsed = json.loads(re.search(r"\{.*\}", content, re.S).group(0))
    except (ValueError, AttributeError):
        return None, provider
    return (parsed if isinstance(parsed, dict) else None), provider


def _heuristic(candidate_links: dict[str, str]) -> dict:
    """Used when no LLM is configured or it could not answer: the single strongest appointment-looking
    link, if any. It never guesses at per-specialty links (that needs the model to read the pages)."""
    best_url, best_score = None, 0
    for url, text in candidate_links.items():
        s = _score(url, text)
        if s > best_score:
            best_url, best_score = url, s
    has_appt = best_score >= 3
    return {"has_appointment": has_appt, "appointment_url": best_url if has_appt else None,
           "requires_login": False, "specialties": []}


def crawl(website: str, place_name: str, category: str | None = None, place_category: str | None = None) -> dict:
    """Crawls `website` (a place's own site) looking for online appointment booking. Bounded to
    MAX_PAGES pages, obeys robots.txt and the same politeness rules as web_lookup.py."""
    events: list[dict] = []
    result = {"website": website, "status": "ok", "has_appointment": False, "appointment_url": None,
             "requires_login": False, "specialties": [], "pages_crawled": [], "ai_provider": None,
             "forms": []}   # every web form found on the crawled pages, one per page: {url, label, field_count, embedded}
    form_urls: set = set()
    rendered_pages = 0
    broken_urls: set[str] = set()
    host = urlparse(website).hostname
    _event(events, "crawl_start", f"Crawl start: {website} (max {MAX_PAGES} pages)")

    frontier: list[tuple[int, str, str]] = [(5, website, "homepage")]
    seen: set[str] = set()
    candidate_links: dict[str, str] = {}
    page_texts: list[tuple[str, str]] = []

    while frontier and len(seen) < MAX_PAGES:
        frontier.sort(key=lambda t: -t[0])
        _score_hint, url, _text = frontier.pop(0)
        if _canon(url) in seen:
            continue
        seen.add(_canon(url))
        if not web_lookup._allowed(url):
            _event(events, "skip", f"Skipped (robots.txt does not allow it): {url}")
            continue
        try:
            final, html = web_lookup._get(url)
        except web_lookup.WebError as exc:
            _event(events, "skip", f"Could not load {url}: {exc}")
            broken_urls.add(_canon(url))   # a dead link (e.g. a 404 "Book now" page) is never offered
            continue
        if _canon(final) in seen and _canon(final) != _canon(url):
            continue  # redirected to a page already crawled under a different address
        seen.add(_canon(final))
        result["pages_crawled"].append(final)
        _event(events, "page", f"Page [{len(result['pages_crawled'])}/{MAX_PAGES}] {final}")
        page = web_lookup.extract(html, final)
        page_texts.append((final, page["text"][:4000]))

        found_form = _page_form(html, final)
        # a page with no <form> in its downloaded HTML may draw one with JavaScript: read it with a browser,
        # but only the home page and pages that sound like they hold a form (each browser read is slow)
        looks_formish = len(result["pages_crawled"]) == 1 or bool(FORM_RE.search(final))
        if not found_form and rendered_pages < MAX_RENDERED_PAGES and looks_formish \
                and BeautifulSoup(html, "html.parser").find("form") is None:
            rendered_pages += 1   # no form in the downloaded page: it may be drawn by JavaScript
            rendered = render_html(final)
            found_form = _page_form(rendered, final) if rendered else None
        same_form = found_form and (found_form["label"].lower(), found_form["field_count"]) in form_urls
        if found_form and not same_form and _canon(final) not in form_urls:   # same form repeated on many pages: keep one
            form_urls.add(_canon(final))
            form_urls.add((found_form["label"].lower(), found_form["field_count"]))
            result["forms"].append(found_form)
            _event(events, "form", f"Form found: \"{found_form['label']}\" at {final}")

        for link_url, link_text in _page_links(html, final, host):
            if _canon(link_url) in seen:
                continue
            s = _score(link_url, link_text)
            if s > 0 and link_url not in candidate_links:
                candidate_links[link_url] = link_text
            if s >= 0:   # pages that sound like they hold a form are visited before the rest
                frontier.append((max(s, 2) if FORM_RE.search(link_url + " " + link_text) else s, link_url, link_text))

    if not result["pages_crawled"]:
        result["status"] = "unreachable"
        _event(events, "error", "Crawl finished: the website could not be read")
        result["log"] = events
        return result

    _event(events, "crawled", f"Crawled {len(result['pages_crawled'])} page(s), "
                              f"found {len(candidate_links)} appointment/doctor-looking link(s)")

    result["forms"] = _dedupe_forms(result["forms"])
    valid_urls = {u for u in set(candidate_links) | set(result["pages_crawled"]) if _canon(u) not in broken_urls}
    result["appointments_checked"] = (place_category or "").lower() == "healthcare"
    if not result["appointments_checked"]:
        # "Book an appointment" only makes sense for healthcare places: a job portal's "book a free
        # counselling call" or a shop's "book now" is not a medical appointment. Forms are still listed.
        _event(events, "goal", f"Appointment booking not checked (place category: {place_category or 'unknown'})")
        parsed, provider = None, None
    else:
        parsed, provider = _ask_llm(place_name, category or "", page_texts, candidate_links)

    if not result["appointments_checked"]:
        pass
    elif parsed is not None:
        appt_url = parsed.get("appointment_url")
        appt_url = appt_url if isinstance(appt_url, str) and appt_url in valid_urls else None
        specialties = []
        for item in (parsed.get("specialties") or [])[:12]:
            if not isinstance(item, dict):
                continue
            name, s_url = item.get("name"), item.get("url")
            s_url = s_url if isinstance(s_url, str) and s_url in valid_urls else None
            doctors = []
            for doc in (item.get("doctors") or [])[:3]:   # at most 3, even if the site lists more
                if not isinstance(doc, dict):
                    continue
                d_name, d_url = doc.get("name"), doc.get("url")
                d_url = d_url if isinstance(d_url, str) and d_url in valid_urls else None
                if isinstance(d_name, str) and d_name.strip() and (d_url or s_url):  # must have SOME link to open
                    doctors.append({"name": d_name.strip()[:80], "url": d_url})
            if isinstance(name, str) and name.strip() and (s_url or doctors):
                specialties.append({"name": name.strip()[:80], "url": s_url, "doctors": doctors})
        has_appt = bool(parsed.get("has_appointment")) and bool(appt_url or specialties)
        result.update(has_appointment=has_appt, appointment_url=appt_url, specialties=specialties,
                      requires_login=bool(parsed.get("requires_login")), ai_provider=provider)
        _event(events, "goal", f"Goal resolved by {provider}: has_appointment={has_appt}"
                              + (f", {len(specialties)} specialt(y/ies)" if specialties else ""))
    else:
        guess = _heuristic({u: t for u, t in candidate_links.items() if u in valid_urls})
        result.update(guess)
        _event(events, "goal", f"Goal resolved by keyword match: has_appointment={guess['has_appointment']}"
                              + (" (no AI model available)" if not services.configured() else " (AI model gave no answer)"))

    _event(events, "done", "Crawl finished")
    result["log"] = events
    return result
