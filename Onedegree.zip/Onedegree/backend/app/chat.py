"""Understand a sentence typed in the home-page chat: what service the person wants and where.

    "hi i am looking for some schools near kondapur"  ->  service Schools, place "kondapur"
    "my son has a fever, any clinic near my location" ->  service Clinics, current location

The steps are small, classic NLP:
  1. Normalise and tokenise the text, fold plurals to a base form (lemmatise), drop stop-words.
  2. Place: a "near / in / at / around ..." phrase is cut at the next clause word ("for my child"), checked
     against what a place name can look like, and, when there is no preposition, a gazetteer (the offline
     city list) is scanned for a known place name.
  3. Service: (a) the longest phrase match from the catalog and its synonyms (spelling mistakes tolerated);
     otherwise (b) keyword intent scoring - every catalog option has a bag of words, rarer words carry more
     weight (TF-IDF), so "fever" -> Clinics and "loan" -> Banks even though the person never named the service.
  4. If nothing matched, the Hugging Face model (when configured) is asked to fill in the service and place.
"""
import difflib
import json
import logging
import math
import re

from . import location

log = logging.getLogger("onedegree.chat")

# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------
STOPWORDS = set("""
hi hii hello hey hola good morning afternoon evening namaste
i m am im is are was be been do does did have has had can could would should will shall may might
me my mine we us our you your he she it his her they them their
a an the this that these those some any many much more most few little lot lots
and or but so as if of for to from with without at in on by about into over under near nearby around within
please pls plz kindly thanks thank
looking look searching search find finding need needs want wants wanted like require required get give show tell help
know where what which who whom how there here available
child children kid kids son daughter baby family friend mother father mom dad wife husband
best top good nice cheap free
today now urgent urgently asap quickly
place places location area locality
""".split())

# words that never identify a service on their own
GENERIC = {"center", "centre", "service", "services", "home", "house", "general", "office", "shop", "store", "station", "stand"}

# words that end a place phrase: "near kondapur FOR my child"
CLAUSE_END = set("""for with who that which because since as and but so my our his her their your me
please pls thanks need needs want wants looking should could can will also or""".split())

NOT_PLACE_START = set("""need case order addition fact general particular my our your this that those these some any
here there time future hurry emergency a an""".split())

NEAR_ME = re.compile(
    r"\b(near\s*me|nearby|near\s*by|around\s*me|close\s*to\s*me|close\s*by|"
    r"(?:near(?:\s+to)?|around|in|at|from|close\s+to)\s+(?:my|the|our)\s+(?:current\s+|present\s+)?(?:location|area|place|locality|neighbou?rhood|home|house)|"
    r"(?:near(?:\s+to)?|around|in|at)\s+(?:here|home))\b", re.I)

PREPOSITION = re.compile(r"\b(?:near(?:\s+to)?|nearest\s+to|close\s+to|within|around|in|at|from)\s+", re.I)
WORDS = re.compile(r"[A-Za-z0-9][A-Za-z0-9'\-]*")


def lemma(word: str) -> str:
    """A very small lemmatiser: schools -> school, pharmacies -> pharmacy, glasses -> glass."""
    w = word.lower().strip("'-")
    if len(w) > 4 and w.endswith("ies"):
        return w[:-3] + "y"
    if len(w) > 4 and re.search(r"(ses|xes|ches|shes)$", w):
        return w[:-2]
    if len(w) > 3 and w.endswith("s") and not w.endswith("ss"):
        return w[:-1]
    return w


def tokens(text: str) -> list[str]:
    return [lemma(w) for w in WORDS.findall(text or "")]


def content_tokens(text: str) -> list[str]:
    return [t for t in tokens(text) if t not in STOPWORDS and t not in GENERIC and len(t) > 1]


# ---------------------------------------------------------------------------
# Service understanding: keyword intent scoring (TF-IDF over the catalog)
# ---------------------------------------------------------------------------
# What people say when they describe a need instead of naming the service.
INTENT_WORDS: dict[str, list[str]] = {
    "Schools": ["admission", "student", "education", "classroom", "study", "studying", "tuition", "cbse", "icse", "syllabus"],
    "Colleges": ["degree", "engineering", "graduation", "intermediate", "junior college", "btech", "polytechnic"],
    "Universities": ["phd", "postgraduate", "masters", "mba", "campus"],
    "Kindergartens": ["lkg", "ukg", "nursery school"],
    "Childcare centers": ["babysitting", "babysitter", "childminder", "toddler"],
    "Libraries": ["books", "reading", "borrow", "novel"],
    "Clinics": ["fever", "cold", "cough", "sick", "ill", "unwell", "checkup", "check up", "treatment", "consultation", "illness", "infection"],
    "Hospitals": ["surgery", "operation", "accident", "icu", "admit", "admitted", "delivery", "maternity", "injury", "injured"],
    "Doctors": ["appointment", "specialist", "consult", "paediatrician", "pediatrician", "gynecologist", "cardiologist"],
    "Dentists": ["toothache", "cavity", "braces", "root canal", "gum"],
    "Pharmacies": ["tablet", "tablets", "pill", "pills", "prescription", "drug", "drugs", "syrup", "ointment"],
    "Opticians": ["spectacles", "specs", "eyesight", "lens", "lenses", "contact lens"],
    "Mental health": ["stress", "stressed", "anxiety", "anxious", "sad", "lonely", "counselor", "counsellor", "psychologist"],
    "Physiotherapy": ["back pain", "joint pain", "sprain", "exercise therapy"],
    "Food banks": ["food", "meal", "meals", "eat", "starving", "ration", "rations", "hungry"],
    "Grocery stores": ["vegetable", "vegetables", "milk", "provisions", "daily needs", "kirana"],
    "Supermarkets": ["shopping", "mart", "hypermarket"],
    "Bakeries": ["cake", "cakes", "biscuit", "pastry", "bun"],
    "Banks": ["loan", "account", "deposit", "savings", "cheque", "check book", "passbook", "ifsc", "fixed deposit"],
    "ATMs": ["cash", "withdraw", "withdrawal", "money"],
    "Insurance offices": ["policy", "premium", "lic", "claim"],
    "Employment agencies": ["job", "work", "employment", "hiring", "career", "vacancy", "vacancies", "recruitment", "placement"],
    "Job training centers": ["skill", "skills", "training", "course", "certification"],
    "Lawyers": ["legal", "divorce", "advocate", "case", "litigation", "dispute", "will"],
    "Notaries": ["affidavit", "notarize", "attest", "attestation"],
    "Post offices": ["parcel", "courier", "stamp", "speed post", "postal", "letter"],
    "Government offices": ["certificate", "aadhaar", "aadhar", "ration card", "passport", "license", "licence", "pan card", "voter"],
    "Police stations": ["theft", "robbery", "complaint", "fir", "crime", "stolen", "harassment", "cheated"],
    "Fire stations": ["fire", "blaze"],
    "Ambulance stations": ["ambulance"],
    "Fuel stations": ["refuel", "diesel", "petrol", "gas"],
    "Taxi stands": ["cab", "taxi", "ride"],
    "Bus stops": ["bus", "buses"],
    "Train stations": ["train", "railway", "rail"],
    "Metro stations": ["metro", "subway"],
    "Hostels": ["pg", "accommodation", "lodging", "paying guest", "room to stay"],
    "Homeless shelters": ["homeless", "sleep", "roof", "night stay", "nowhere to stay"],
    "Public toilets": ["toilet", "restroom", "washroom", "bathroom", "urinal"],
    "Places of worship": ["pray", "prayer", "god", "worship", "church", "temple", "mosque"],
    "Parks": ["walk", "walking", "jogging", "garden", "picnic"],
    "Playgrounds": ["play", "swings", "slide"],
    "Sports centers": ["cricket", "football", "gym", "workout", "swimming", "badminton", "fitness", "yoga"],
    "Nursing homes": ["elderly", "old age", "senior care", "elder care"],
    "Community centers": ["community hall", "function hall", "event"],
    "Coworking spaces": ["coworking", "workspace", "desk"],
    "Internet cafes": ["internet", "wifi", "browsing", "cyber"],
    "Copy & print shops": ["print", "printout", "xerox", "photocopy", "lamination", "scan"],
    "Drinking water": ["water", "thirsty", "thirst"],
}


def _build_index():
    """Bag of lemmas for every catalog option, plus the document frequency of each lemma."""
    docs: dict[str, set[str]] = {}
    for name in location.OPTION_TAGS:
        phrases = [name] + location.SYNONYMS.get(name, []) + INTENT_WORDS.get(name, [])
        docs[name] = {t for p in phrases for t in tokens(p) if t not in STOPWORDS and t not in GENERIC and len(t) > 1}
    df: dict[str, int] = {}
    for words in docs.values():
        for w in words:
            df[w] = df.get(w, 0) + 1
    n = len(docs)
    idf = {w: math.log((n + 1) / (c + 0.5)) for w, c in df.items()}
    return docs, idf


_DOCS, _IDF = _build_index()
_VOCAB = sorted(_IDF)


def _known_word(word: str) -> str | None:
    """The catalog word this lemma is, or a close spelling of it ("scools" -> school)."""
    if word in _IDF:
        return word
    if len(word) >= 5:
        close = difflib.get_close_matches(word, _VOCAB, n=1, cutoff=0.82)
        if close:
            return close[0]
    return None


def score_services(text: str) -> list[tuple[str, float]]:
    """[(option, score)], best first: sum of the TF-IDF weight of the words the text shares with each option."""
    words = {_known_word(t) for t in content_tokens(text)} - {None}
    if not words:
        return []
    scored = []
    for name, doc in _DOCS.items():
        shared = words & doc
        if shared:
            scored.append((name, sum(_IDF[w] for w in shared)))
    return sorted(scored, key=lambda s: -s[1])


# ---------------------------------------------------------------------------
# Place understanding
# ---------------------------------------------------------------------------
def _looks_like_service(text: str) -> bool:
    return bool(text) and location.match_option_ex(text) is not None


def _place_from_preposition(text: str) -> tuple[str, tuple[int, int]] | None:
    """The last "near X / in X / at X" phrase that can be a place -> (X, span of the whole phrase)."""
    best = None
    for m in PREPOSITION.finditer(text):
        words = []
        end = m.end()
        for w in WORDS.finditer(text, m.end()):
            if text[end:w.start()].strip(" ,"):   # something other than a space or comma between words: stop
                break
            low = w.group().lower()
            if low in CLAUSE_END or (words and PREPOSITION.match(text, w.start())):
                break
            words.append(w.group())
            end = w.end()
            if len(words) == 4:
                break
        while words and words[0].lower() in ("the", "a", "an"):
            words.pop(0)
        while words and (words[-1].lower() in STOPWORDS or lemma(words[-1]) in STOPWORDS):
            words.pop()
        if not words or words[0].lower() in NOT_PLACE_START:
            continue
        candidate = " ".join(words)
        if _looks_like_service(candidate) and not location.match_city(candidate):
            continue   # "in schools", "near hospitals": a service, not a place
        best = (candidate, (m.start(), end))
    return best


def _place_from_gazetteer(text: str) -> tuple[str, tuple[int, int]] | None:
    """No preposition ("schools kondapur"): look for a word group that is a known place name."""
    found = list(WORDS.finditer(text))
    for size in (3, 2, 1):
        for i in range(len(found) - size + 1):
            group = found[i:i + size]
            phrase = " ".join(w.group() for w in group)
            if any(lemma(w.group()) in _IDF or lemma(w.group()) in STOPWORDS for w in group) or len(phrase) < 4:
                continue
            m = location.match_city(phrase)
            if m and not m["fixed"]:
                return phrase, (group[0].start(), group[-1].end())
    return None


# ---------------------------------------------------------------------------
# Optional last resort: the language model
# ---------------------------------------------------------------------------
def _ask_model(message: str) -> dict:
    try:
        from . import services
        options = ", ".join(location.OPTION_TAGS)
        prompt = ("Extract a place-search request from the message. Reply with JSON only, like "
                  '{"service": "Schools", "place": "Kondapur"}. "service" must be exactly one of: ' + options +
                  '; use "" if none fits. "place" is the place name written in the message, or "" if the person '
                  'means near them / near me.\nMessage: ' + message)
        answer = services.chat(prompt, max_tokens=80)
        if not answer:
            return {}
        raw = re.search(r"\{.*?\}", answer[0], re.S)
        data = json.loads(raw.group()) if raw else {}
        service = data.get("service") if data.get("service") in location.OPTION_TAGS else ""
        place = str(data.get("place") or "").strip()[:60]
        return {"service": service, "place": place}
    except Exception as exc:   # the model is a bonus: never let it break the chat
        log.warning("chat model fallback failed: %s", exc)
        return {}


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def parse(message: str) -> dict:
    """{service, query, place, near_me, matched_option, method}

    `query` is what to search for (the catalog option when one was understood, else the person's own words)."""
    text = re.sub(r"\s+", " ", (message or "").strip())

    # ----- where -----
    near_me = bool(NEAR_ME.search(text))
    rest = NEAR_ME.sub(" ", text)
    place = None
    found = _place_from_preposition(rest) or (None if near_me else _place_from_gazetteer(rest))
    if found:
        place, (start, end) = found
        rest = rest[:start] + " " + rest[end:]

    # ----- what -----
    option, method, confidence = None, "", 0.0
    hit = location.match_option_ex(rest)            # a service named outright, spelling mistakes tolerated
    if hit:
        option, method, confidence = hit[0], "phrase", 1.0
        if not place and not near_me and len(WORDS.findall(rest)) <= 3:
            # a short message like "schools kondapur": the one word that is not a service word is the place
            unknown = [w.group() for w in WORDS.finditer(rest)
                       if lemma(w.group()) not in STOPWORDS and lemma(w.group()) not in GENERIC
                       and _known_word(lemma(w.group())) is None]
            if len(unknown) == 1:
                place = unknown[0]
    else:
        ranked = score_services(rest)               # a need described in other words
        if ranked:
            option, method = ranked[0][0], "keywords"
            runner_up = ranked[1][1] if len(ranked) > 1 else 0.0
            confidence = round(ranked[0][1] / (ranked[0][1] + runner_up), 2)

    if not option:
        model = _ask_model(text)
        if model.get("service"):
            option, method, confidence = model["service"], "model", 0.7
        if model.get("place") and not place and not near_me:
            place = model["place"]

    # the person's own words (not lemmatised) when no catalog service was understood: "shoe store"
    leftover = " ".join(w for w in WORDS.findall(rest) if lemma(w) not in STOPWORDS)
    query = option or leftover
    return {
        "service": option or leftover,
        "query": query,
        "place": place,
        "near_me": place is None,
        "matched_option": option,
        "method": method or ("text" if leftover else ""),
        "confidence": confidence,
    }
