"""Everything about finding out more from the open web for a place OpenStreetMap under-describes:
  * reading a place's OWN website (phone, email, hours, rating) - free, no keys, "the Site Crawler"
  * finding that website in the first place, when OpenStreetMap does not list one
  * the paid/keyless search tools (Serper, SerpAPI, HERE, TomTom, Foursquare, and keyless DuckDuckGo/
    Yahoo/Bing/Startpage through the "ddgs" library) used only for what a website cannot answer
Free, no keys required for the website reading itself. It is deliberately polite and careful:
  * only http/https, and only public internet addresses (never localhost or private networks: the
    URLs come from OpenStreetMap, which anyone can edit)
  * obeys robots.txt, identifies itself, at most 1 request per second per site
  * at most 3 pages per site (home page plus a contact/about page or two), 1.5 MB per page, short timeouts
  * never logs in, submits forms or bypasses anything
Wikidata (free, open) is used for well-known places that have a Wikidata entry.
"""
import difflib
import ipaddress
import json
import logging
import math
import os
import re
import socket
import threading
import time
import unicodedata
import urllib.robotparser
from urllib.parse import quote, urljoin, urlparse

import httpx
from bs4 import BeautifulSoup
from sqlalchemy import text

from .db import engine

log = logging.getLogger("onedegree.web_lookup")

USER_AGENT = "OneDegreePOC/0.1 (community resource finder demo; reads public contact details)"
WEB_TIMEOUT_S = 8
MAX_BYTES = 1_500_000
MAX_PAGES = 3
MAX_REDIRECTS = 3
MIN_INTERVAL_S = 1.0
ALLOWED_PORTS = {None, 80, 443, 8080, 8443}

ALLOW_PRIVATE = os.getenv("WEB_ENRICH_ALLOW_PRIVATE") == "1"  # tests only: lets the crawler reach localhost


class WebError(Exception):
    """This page/site cannot or should not be read."""


# ---------------------------------------------------------------------------
# Safe fetching
# ---------------------------------------------------------------------------
def normalize_website(raw: str) -> str | None:
    """First website from an OpenStreetMap tag value, with a scheme, or None."""
    for part in (raw or "").split(";"):
        part = part.strip()
        if not part or re.match(r"^(javascript|mailto|tel|data|file|ftp|sms|about|blob|vbscript):", part, re.I):
            continue  # not a web address at all
        if not re.match(r"^[a-z][a-z0-9+.-]*://", part, re.I):
            part = "https://" + part
        try:
            parsed = urlparse(part)
            valid = parsed.scheme in ("http", "https") and parsed.hostname and (parsed.port in ALLOWED_PORTS or ALLOW_PRIVATE)
        except ValueError:  # e.g. a port that is not a number
            continue
        if valid:
            return part
    return None


def _check_public(url: str) -> None:
    try:
        parsed = urlparse(url)
        port = parsed.port
    except ValueError:
        raise WebError("invalid address")
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise WebError("not an http(s) address")
    if port not in ALLOWED_PORTS and not ALLOW_PRIVATE:
        raise WebError("unusual port")
    if ALLOW_PRIVATE:
        return
    try:
        infos = socket.getaddrinfo(parsed.hostname, parsed.port or (443 if parsed.scheme == "https" else 80))
    except socket.gaierror:
        raise WebError("address not found")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if not ip.is_global:  # private, loopback, link-local, reserved...
            raise WebError("address is not on the public internet")


_last_hit: dict[str, float] = {}
_hit_lock = threading.Lock()


def _polite_wait(host: str) -> None:
    with _hit_lock:
        wait = MIN_INTERVAL_S - (time.time() - _last_hit.get(host, 0))
        _last_hit[host] = time.time() + max(wait, 0)
    if wait > 0:
        time.sleep(wait)


def _get(url: str, want_html: bool = True) -> tuple[str, str]:
    """(final url, text) of a page. Follows up to 3 redirects, re-checking each address."""
    for _ in range(MAX_REDIRECTS + 1):
        _check_public(url)
        _polite_wait(urlparse(url).hostname)
        try:
            with httpx.stream("GET", url, headers={"User-Agent": USER_AGENT, "Accept": "text/html,text/plain;q=0.9"},
                              timeout=WEB_TIMEOUT_S, follow_redirects=False) as resp:
                if resp.status_code in (301, 302, 303, 307, 308) and resp.headers.get("location"):
                    url = urljoin(url, resp.headers["location"])
                    continue
                if resp.status_code != 200:
                    raise WebError(f"status {resp.status_code}")
                ctype = resp.headers.get("content-type", "").lower()
                if want_html and "html" not in ctype and "xml" not in ctype:
                    raise WebError("not a web page")
                body = b""
                for chunk in resp.iter_bytes():
                    body += chunk
                    if len(body) > MAX_BYTES:
                        break  # big enough: the contact details are near the top or in the structured data
                enc = resp.encoding or "utf-8"
                return url, body.decode(enc, errors="replace")
        except httpx.HTTPError as exc:
            raise WebError(f"could not load ({exc.__class__.__name__})")
    raise WebError("too many redirects")


_robots: dict[str, tuple[float, urllib.robotparser.RobotFileParser | None, str]] = {}


def _robots_entry(url: str) -> tuple[urllib.robotparser.RobotFileParser | None, str]:
    """(parser, state) for a site. state: "ok", "down" (the site cannot be reached at all) or "error"
    (robots.txt itself failed with a server error, so the site is not read this time)."""
    parsed = urlparse(url)
    origin = f"{parsed.scheme}://{parsed.netloc}"
    hit = _robots.get(origin)
    if not hit or time.time() - hit[0] > 3600:
        rp, state = urllib.robotparser.RobotFileParser(), "ok"
        try:
            _check_public(origin)
            _polite_wait(parsed.hostname)
            resp = httpx.get(origin + "/robots.txt", headers={"User-Agent": USER_AGENT}, timeout=WEB_TIMEOUT_S,
                             follow_redirects=True)
            if resp.status_code == 200:
                rp.parse(resp.text.splitlines())
            elif 400 <= resp.status_code < 500:
                rp.parse([])  # no usable robots.txt: everything is allowed
            else:
                rp, state = None, "error"   # server error: do not crawl now
        except (httpx.HTTPError, WebError):
            rp, state = None, "down"        # the address does not exist or the site does not answer
        _robots[origin] = (time.time(), rp, state)
        hit = _robots[origin]
    return hit[1], hit[2]


def _allowed(url: str) -> bool:
    """robots.txt permission. Missing robots.txt (404) means allowed; an unreachable or failing one does not."""
    rp, _state = _robots_entry(url)
    return bool(rp and rp.can_fetch(USER_AGENT, url))


def _refusal(url: str) -> str:
    """Why a page may not be read: "down" (site unreachable), "error" or "disallowed" (robots.txt says no)."""
    rp, state = _robots_entry(url)
    return state if rp is None else "disallowed"

# ---------------------------------------------------------------------------
# Extracting details from a page
# ---------------------------------------------------------------------------
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}")
BAD_EMAIL_DOMAINS = {"example.com", "domain.com", "email.com", "sentry.io", "wixpress.com", "sentry-next.wixpress.com"}
BAD_EMAIL_SUFFIX = (".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".css", ".js")
NOT_A_PLACE = {"Review", "Person", "Product", "Offer", "Article", "NewsArticle", "BlogPosting", "WebSite", "WebPage",
               "ImageObject", "BreadcrumbList", "Event", "Question", "Answer", "Recipe", "VideoObject"}
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
ABBR = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]


def _walk(node):
    """Every dict inside a JSON-LD document."""
    if isinstance(node, dict):
        yield node
        for v in node.values():
            yield from _walk(v)
    elif isinstance(node, list):
        for v in node:
            yield from _walk(v)


def _as_list(v) -> list:
    return v if isinstance(v, list) else [] if v in (None, "") else [v]


def _phone_ok(p: str) -> str | None:
    p = re.sub(r"\s+", " ", (p or "").replace("tel:", "")).strip(" .,;")
    digits = re.sub(r"\D", "", p)
    return p if 7 <= len(digits) <= 15 else None


def _email_ok(e: str) -> str | None:
    e = (e or "").replace("mailto:", "").split("?")[0].strip().strip(".,;<>").lower()
    if not EMAIL_RE.fullmatch(e) or e.endswith(BAD_EMAIL_SUFFIX):
        return None
    domain = e.rsplit("@", 1)[1]
    if domain in BAD_EMAIL_DOMAINS or e.startswith(("noreply", "no-reply", "donotreply")):
        return None
    return e


def _decode_cfemail(hexstr: str) -> str | None:
    """Cloudflare hides addresses as hex: the first byte is the XOR key for the rest."""
    try:
        key = int(hexstr[:2], 16)
        return "".join(chr(int(hexstr[i:i + 2], 16) ^ key) for i in range(2, len(hexstr), 2))
    except ValueError:
        return None


def _day_index(value: str) -> int | None:
    v = (value or "").rsplit("/", 1)[-1].strip().lower()
    for i, name in enumerate(DAYS):
        if v in (name.lower(), ABBR[i].lower(), name[:3].lower()):
            return i
    return None


def _hhmm(t: str) -> str | None:
    m = re.match(r"^(\d{1,2}):(\d{2})", (t or "").strip())
    return f"{int(m.group(1)):02d}:{m.group(2)}" if m else None


def _hours_from_spec(specs) -> str | None:
    """schema.org openingHoursSpecification -> "Mo-Fr 09:00-17:00; Sa 10:00-14:00" (OpenStreetMap style)."""
    per_day: dict[int, list[str]] = {}
    for spec in _as_list(specs):
        if not isinstance(spec, dict):
            continue
        opens, closes = _hhmm(spec.get("opens", "")), _hhmm(spec.get("closes", ""))
        if not opens or not closes:
            continue
        for d in _as_list(spec.get("dayOfWeek")):
            i = _day_index(str(d))
            if i is not None:
                per_day.setdefault(i, []).append(f"{opens}-{closes}")
    return _group_days(per_day)


def _group_days(per_day: dict[int, list[str]]) -> str | None:
    """{0: ["09:00-17:00"], ..., 6: ["off"]} -> "Mo-Fr 09:00-17:00; Sa-Su off" (days with the same hours merge)."""
    if not per_day:
        return None
    groups, i = [], 0
    while i < 7:
        if i in per_day:
            j = i
            while j + 1 < 7 and per_day.get(j + 1) == per_day[i]:
                j += 1
            label = ABBR[i] if i == j else f"{ABBR[i]}-{ABBR[j]}"
            groups.append(f"{label} {','.join(per_day[i])}")
            i = j + 1
        else:
            i += 1
    return "; ".join(groups)


_CLOCK = r"(\d{1,2})(?::(\d{2}))?\s*(AM|PM)?"
_RANGE_RE = re.compile(_CLOCK + r"\s*(?:–|—|-|to)\s*" + _CLOCK, re.I)


def _to_24h(hour: int, minute: int, meridiem: str | None) -> int:
    """Minutes since midnight; "12 AM" is 0."""
    if meridiem:
        hour = hour % 12 + (12 if meridiem.upper() == "PM" else 0)
    return hour * 60 + minute


def _google_day_ranges(text_: str) -> list[str] | None:
    """One Google Maps day ("9 AM-5 PM", "9 AM-1 PM, 4-8 PM", "Closed", "Open 24 hours") -> ["09:00-17:00"],
    ["off"], ["00:00-24:00"], or None when it cannot be read."""
    text_ = re.sub(r"[   ]", " ", str(text_ or "")).strip()
    if re.search(r"closed", text_, re.I):
        return ["off"]
    if re.search(r"24 hours|open 24|all day", text_, re.I):
        return ["00:00-24:00"]
    out = []
    for m in _RANGE_RE.finditer(text_):
        h1, m1, ap1, h2, m2, ap2 = int(m.group(1)), int(m.group(2) or 0), m.group(3), int(m.group(4)), int(m.group(5) or 0), m.group(6)
        end = _to_24h(h2, m2, ap2)
        start = _to_24h(h1, m1, ap1 or ap2)
        if not ap1 and ap2 and start >= end:   # "10-2 PM": the start is in the morning
            start = _to_24h(h1, m1, "AM")
        if ap2 and end == 0:
            end = 24 * 60   # "... - 12 AM" is midnight at the end of the day
        if not (0 <= start < 24 * 60 and 0 < end <= 24 * 60) or not (h1 <= 24 and h2 <= 24):
            return None
        out.append(f"{start // 60:02d}:{start % 60:02d}-{end // 60:02d}:{end % 60:02d}")
    return out or None


def hours_from_google(raw) -> str | None:
    """Google Maps weekly hours -> OpenStreetMap style "Mo-Fr 09:00-17:00; Sa 10:00-14:00; Su off".
    Accepts {"monday": "9 AM-5 PM", ...} or a list of such dicts / {"day": ..., "hours": ...} rows.
    Returns None unless every day that is given can be read - half-understood hours are never shown."""
    pairs: list[tuple[str, str]] = []
    if isinstance(raw, dict):
        pairs = [(str(k), v) for k, v in raw.items()]
    elif isinstance(raw, list):
        for row in raw:
            if isinstance(row, dict) and ("day" in row or "name" in row):
                pairs.append((str(row.get("day") or row.get("name")), row.get("hours") or row.get("time") or row.get("value")))
            elif isinstance(row, dict):
                pairs += [(str(k), v) for k, v in row.items()]
    per_day: dict[int, list[str]] = {}
    for day, value in pairs:
        i = _day_index(day)
        if i is None:
            continue
        if isinstance(value, list):
            value = ", ".join(str(v) for v in value)
        ranges = _google_day_ranges(value)
        if ranges is None:
            return None
        per_day[i] = ranges
    return _group_days(per_day) if len(per_day) >= 5 else None


def _hours_from_strings(values) -> str | None:
    lines = [str(v).strip() for v in _as_list(values) if re.match(r"^\s*(Mo|Tu|We|Th|Fr|Sa|Su)", str(v))]
    return "; ".join(lines) if lines else None


POSTAL_RE = re.compile(r"\b\d{6}\b|\b\d{5}(?:-\d{4})?\b")
STREET_RE = re.compile(r"\b(road|rd\.?|street|st\.?|lane|nagar|colony|avenue|ave\.?|marg|block|sector|plot|floor|"
                       r"opp\.?|opposite|near|beside|main|cross|circle|hills|junction|highway|hwy|phase)\b", re.I)


def _address_ok(text_: str) -> str | None:
    """Tidy one address candidate; None unless it looks like a real postal address (a postcode, or several
    comma-separated parts one of which is a street/area word) - never a sentence or a menu."""
    text_ = re.sub(r"\s+", " ", (text_ or "")).strip(" ,;:-|")
    text_ = re.sub(r"^(?:our\s+)?(?:address|location|find us|visit us|head office|corporate office)\s*[:\-]\s*", "", text_, flags=re.I)
    if not 12 <= len(text_) <= 220 or "@" in text_ or text_.count(".") > 6:
        return None
    parts = [p for p in text_.split(",") if p.strip()]
    if POSTAL_RE.search(text_) and (len(parts) >= 2 or STREET_RE.search(text_)):
        return text_
    return text_ if len(parts) >= 3 and STREET_RE.search(text_) else None


def _address_from_jsonld(value) -> str | None:
    """schema.org `address`: a PostalAddress object, a list of them (the first is used), or plain text."""
    for item in _as_list(value):
        if isinstance(item, dict):
            country = item.get("addressCountry")
            country = country.get("name") if isinstance(country, dict) else country
            parts = [item.get("streetAddress"), item.get("addressLocality"), item.get("addressRegion"),
                     item.get("postalCode"), country]
            text_ = ", ".join(str(p).strip() for p in parts if p and str(p).strip())
            if len(text_) >= 8:
                return text_[:220]
        elif isinstance(item, str) and (ok := _address_ok(item)):
            return ok
    return None


def _address_from_markup(soup) -> str | None:
    """microdata (itemprop="address"/streetAddress...) or an <address> element."""
    box = soup.find(attrs={"itemprop": "address"})
    if box is not None:
        parts = [(el.get("content") or el.get_text(" ", strip=True)) for prop in
                 ("streetAddress", "addressLocality", "addressRegion", "postalCode")
                 for el in box.find_all(attrs={"itemprop": prop})]
        text_ = ", ".join(p.strip() for p in parts if p and p.strip()) or box.get_text(" ", strip=True)
        if (ok := _address_ok(text_)):
            return ok
    for tag in soup.find_all("address"):
        if (ok := _address_ok(tag.get_text(", ", strip=True))):
            return ok
    return None


def _address_from_text(text_: str) -> str | None:
    """A line (or the line after a lone "Address" heading) in the visible text that reads like an address."""
    lines = [ln.strip() for ln in (text_ or "").splitlines() if ln.strip()]
    for i, line in enumerate(lines):
        if re.match(r"^(?:our\s+)?(?:address|location|find us|visit us|head office)\s*:?\s*$", line, re.I):
            block = []
            for nxt in lines[i + 1:i + 4]:   # stop at the next heading (phone, email, hours...)
                if re.match(r"^(?:call|phone|tel|email|e-mail|mobile|contact|timings?|hours|open|follow|whatsapp|fax)\b", nxt, re.I) \
                        or "*" in nxt or re.search(r"\b(name|message|submit|subject)\b", nxt, re.I):
                    break   # the next heading, or the start of a contact form
                block.append(nxt)
                if POSTAL_RE.search(nxt) or re.search(r"\b(india|usa|united states|united kingdom|uk)\b", nxt, re.I):
                    break   # the address ends at its postcode / country
            following = ", ".join(block)
            if (ok := _address_ok(following[:220])):
                return ok
        elif re.match(r"^(?:our\s+)?(?:address|location|find us|visit us)\s*[:\-]", line, re.I):
            if (ok := _address_ok(line)):
                return ok
    return None


def extract(html: str, page_url: str) -> dict:
    """Phones, emails, opening hours and rating found on one page."""
    soup = BeautifulSoup(html, "html.parser")
    out = {"phones": [], "emails": [], "opening_hours": None, "rating": None, "rating_count": None, "text": "",
           "address": None}
    for junk in soup(["script", "style", "noscript", "svg"]):
        junk.extract()  # only what a visitor can read is kept as text (JSON-LD is read separately below)
    out["text"] = soup.get_text("\n", strip=True)[:30000]
    soup = BeautifulSoup(html, "html.parser")

    for tag in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(tag.string or tag.get_text() or "")
        except ValueError:
            continue
        for node in _walk(data):
            types = {str(t).rsplit("/", 1)[-1] for t in _as_list(node.get("@type"))}
            if types & NOT_A_PLACE:
                continue
            for p in _as_list(node.get("telephone")):
                if (ok := _phone_ok(str(p))):
                    out["phones"].append(ok)
            for e in _as_list(node.get("email")):
                if (ok := _email_ok(str(e))):
                    out["emails"].append(ok)
            if not out["opening_hours"]:
                out["opening_hours"] = _hours_from_spec(node.get("openingHoursSpecification")) or \
                    _hours_from_strings(node.get("openingHours"))
            if not out["address"] and (addr := _address_from_jsonld(node.get("address"))):
                out["address"] = addr
            rating = node.get("aggregateRating")
            if isinstance(rating, dict) and out["rating"] is None:
                try:
                    value, best = float(rating.get("ratingValue")), float(rating.get("bestRating") or 5)
                    count = int(float(rating.get("reviewCount") or rating.get("ratingCount") or 0))
                    if 0 < value <= best and count > 0:
                        out["rating"], out["rating_count"] = round(value / best * 5, 1), count
                except (TypeError, ValueError):
                    pass

    for el in soup.find_all(attrs={"itemprop": True}):
        prop = el.get("itemprop")
        value = el.get("content") or el.get_text(" ", strip=True)
        if prop == "telephone" and (ok := _phone_ok(value)):
            out["phones"].append(ok)
        elif prop == "email" and (ok := _email_ok(value)):
            out["emails"].append(ok)
        elif prop == "openingHours" and not out["opening_hours"]:
            out["opening_hours"] = _hours_from_strings(el.get("content") or value)

    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if href.lower().startswith("tel:") and (ok := _phone_ok(href[4:])):
            out["phones"].append(ok)
        elif href.lower().startswith("mailto:") and (ok := _email_ok(href[7:])):
            out["emails"].append(ok)
    for el in soup.find_all(attrs={"data-cfemail": True}):
        if (decoded := _decode_cfemail(el["data-cfemail"])) and (ok := _email_ok(decoded)):
            out["emails"].append(ok)

    if not out["emails"]:  # last resort: an address written out in the page text
        text_ = soup.get_text(" ", strip=True)
        for match in EMAIL_RE.findall(text_)[:20]:
            if (ok := _email_ok(match)):
                out["emails"].append(ok)
    if not out["address"]:
        out["address"] = _address_from_markup(soup) or _address_from_text(out["text"])
    return out


def _contact_links(html: str, page_url: str) -> list[str]:
    host = urlparse(page_url).hostname
    soup = BeautifulSoup(html, "html.parser")
    found: list[str] = []
    for a in soup.find_all("a", href=True):
        label = (a.get_text(" ", strip=True) + " " + a["href"]).lower()
        if re.search(r"contact|about|reach|location|visit|hours|find[- ]us|get[- ]in[- ]touch", label):
            url = urljoin(page_url, a["href"]).split("#")[0]
            if urlparse(url).hostname == host and urlparse(url).scheme in ("http", "https") and url not in found:
                found.append(url)
    return found


# ---------------------------------------------------------------------------
# Wikidata (free, open): official website, phone and email of well-known places
# ---------------------------------------------------------------------------
def wikidata_facts(qid: str) -> dict:
    if not re.fullmatch(r"Q\d{1,12}", qid or ""):
        return {}
    try:
        resp = httpx.get(f"https://www.wikidata.org/wiki/Special:EntityData/{qid}.json",
                         headers={"User-Agent": USER_AGENT}, timeout=WEB_TIMEOUT_S)
        resp.raise_for_status()
        claims = next(iter(resp.json().get("entities", {}).values())).get("claims", {})
    except (httpx.HTTPError, ValueError, StopIteration):
        return {}

    def values(prop):
        out = []
        for c in claims.get(prop, []):
            v = (c.get("mainsnak", {}).get("datavalue") or {}).get("value")
            if isinstance(v, str):
                out.append(v)
        return out

    return {"website": (values("P856") or [None])[0], "phones": [p for p in map(_phone_ok, values("P1329")) if p],
            "emails": [e for e in map(_email_ok, values("P968")) if e], "url": f"https://www.wikidata.org/wiki/{qid}"}


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def _unique(items: list[str], key=lambda s: re.sub(r"\D", "", s)) -> list[str]:
    seen, out = set(), []
    for item in items:
        k = key(item)
        if k not in seen:
            seen.add(k)
            out.append(item)
    return out


# ---------------------------------------------------------------------------
# Is the website working, and is it really this place's website?
# ---------------------------------------------------------------------------
_GENERIC_WORDS = {"the", "and", "for", "of", "in", "at", "de", "la", "le", "les", "el", "clinic", "clinics", "hospital", "hospitals",
                  "centre", "center", "centres", "centers", "school", "college", "university", "pharmacy", "bank", "library",
                  "office", "offices", "medical", "health", "care", "services", "service", "community", "public", "limited",
                  "ltd", "inc", "co", "company", "store", "shop", "branch", "main", "new", "old", "city", "district"}


def _squash(text_: str) -> str:
    text_ = unicodedata.normalize("NFKD", text_ or "").encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "", text_.lower())


def _name_words(names: list[str]) -> list[str]:
    words: list[str] = []
    for name in names:
        ascii_name = unicodedata.normalize("NFKD", name or "").encode("ascii", "ignore").decode().lower()
        words += [w for w in re.findall(r"[a-z0-9]+", ascii_name) if len(w) >= 3 and w not in _GENERIC_WORDS]
    return list(dict.fromkeys(words))


def _judge_site(html: str, final_url: str, names: list[str]) -> dict:
    """The site loaded. Does it mention the place? Looks at the page title, headings, site name,
    the domain and the start of the text."""
    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.get_text(" ", strip=True) if soup.title else ""
    meta = " ".join(m.get("content", "") for m in soup.find_all("meta", attrs={"property": ["og:site_name", "og:title"]}))
    meta += " " + " ".join(m.get("content", "") for m in soup.find_all("meta", attrs={"name": ["application-name", "apple-mobile-web-app-title"]}))
    headings = " ".join(h.get_text(" ", strip=True) for h in soup.find_all(["h1", "h2"])[:4])
    structured_names = []   # the name a site gives itself in its structured data (JSON-LD)
    for tag in soup.find_all("script", type="application/ld+json"):
        try:
            for node in _walk(json.loads(tag.string or tag.get_text() or "")):
                structured_names += [str(node[k]) for k in ("name", "legalName", "alternateName") if isinstance(node.get(k), str)]
        except ValueError:
            continue
    for junk in soup(["script", "style", "noscript", "svg"]):
        junk.extract()
    hay = _squash(" ".join([title, meta, headings, " ".join(structured_names[:10]), urlparse(final_url).hostname or "",
                            soup.get_text(" ", strip=True)[:500]]))
    words = _name_words(names)
    verdict = {"status": "ok", "final_url": final_url, "title": title[:120], "matched": []}
    if not words:  # a name in another script, or only generic words: nothing to compare
        verdict["detail"] = "the website loads (its name could not be compared)"
        return verdict
    hits = [w for w in words if w in hay]
    verdict["matched"] = hits
    needed = 1 if len(words) <= 2 else max(1, len(words) // 2)
    if len(hits) >= needed:
        verdict["detail"] = "the website loads and mentions this place"
    else:
        verdict["status"] = "unmatched"
        verdict["detail"] = "the website loads, but nothing on it mentions this place"
    return verdict


def _judge_error(error: str) -> dict:
    """A page that could not be read: broken, or just unwilling to be read by a program?"""
    code = re.match(r"status (\d+)", error)
    if code and int(code.group(1)) in (401, 403, 405, 406, 429, 451, 999):
        return {"status": "blocked", "detail": f"the website refuses automatic checks (HTTP {code.group(1)})"}
    if error == "not a web page":
        return {"status": "ok", "detail": "the link opens a document (for example a PDF)"}
    return {"status": "unreachable", "detail": error}

def enrich(tags: dict) -> dict:
    """Details for a place from its own website (and Wikidata). `tags` are its OpenStreetMap tags."""
    website = normalize_website(tags.get("website") or tags.get("contact:website") or tags.get("url") or "")
    result = {"website": website, "phones": [], "emails": [], "opening_hours": None, "rating": None,
              "rating_count": None, "sources": {}, "pages": [], "problem": None, "hours_by_ai": False,
              "website_check": None, "address": None}
    texts: list[tuple[str, str]] = []   # (page url, visible text)
    names = [tags.get(k) for k in ("name", "name:en", "brand", "operator", "official_name", "short_name") if tags.get(k)]

    wd = wikidata_facts(tags.get("wikidata", ""))
    if wd and not website:
        website = normalize_website(wd.get("website") or "")
        result["website"] = website

    if website:
        queue, seen = [website], set()
        while queue and len(seen) < MAX_PAGES:
            url = queue.pop(0)
            if url in seen:
                continue
            seen.add(url)
            try:
                if not _allowed(url):
                    why = _refusal(url)
                    if why == "down":   # the address does not exist, or the site does not answer at all
                        result["problem"] = "the website could not be reached"
                        result["website_check"] = {"status": "unreachable", "detail": "the website could not be reached"}
                    else:
                        result["problem"] = "the website's robots.txt does not allow automatic reading"
                        result["website_check"] = {"status": "blocked", "detail": "the website does not allow automatic checks"}
                    break
                final, html = _get(url)
            except WebError as exc:
                if not result["pages"]:
                    result["problem"] = f"the website could not be read ({exc})"
                    result["website_check"] = _judge_error(str(exc))
                continue
            if not result["pages"]:  # the first page decides: does the website work, and is it this place?
                result["website_check"] = _judge_site(html, final, names)
            result["pages"].append(final)
            page = extract(html, final)
            texts.append((final, page["text"]))
            for field in ("phones", "emails"):
                if page[field] and not result["sources"].get(field):
                    result["sources"][field] = final
                result[field] += page[field]
            for field in ("opening_hours", "rating", "address"):
                if page[field] and not result[field]:
                    result[field] = page[field]
                    result["sources"][field] = final
                    if field == "rating":
                        result["rating_count"] = page["rating_count"]
            if len(result["pages"]) == 1:
                queue += _contact_links(html, final)[:2]  # contact/about pages hold what the home page lacks
            if result["phones"] and result["emails"] and result["opening_hours"] and result["address"]:
                break

        _ai_fill(result, texts)  # plain-text hours (and contact details) that no structured data gave

    if wd:  # Wikidata fills what the website did not give
        for field in ("phones", "emails"):
            if wd.get(field) and not result[field]:
                result[field] = wd[field]
                result["sources"][field] = wd["url"]

    site_host = (urlparse(website).hostname or "").removeprefix("www.") if website else ""
    result["emails"] = sorted(_unique(result["emails"], key=str.lower),
                              key=lambda e: 0 if site_host and e.endswith(site_host.split(".", 1)[-1] if site_host.count(".") > 1 else site_host) else 1)[:3]
    result["phones"] = _unique(result["phones"])[:3]
    return result

# ---------------------------------------------------------------------------
# Optional: a free Hugging Face model reads plain-text hours. Everything it returns is checked.
# ---------------------------------------------------------------------------
_RULE = r"(?:(?:Mo|Tu|We|Th|Fr|Sa|Su)(?:-(?:Mo|Tu|We|Th|Fr|Sa|Su))?)(?:,(?:Mo|Tu|We|Th|Fr|Sa|Su)(?:-(?:Mo|Tu|We|Th|Fr|Sa|Su))?)*"
_TIMES = r"(?:\d{2}:\d{2}-\d{2}:\d{2}(?:,\d{2}:\d{2}-\d{2}:\d{2})*|off)"
HOURS_SYNTAX = re.compile(rf"^{_RULE} {_TIMES}(?:; {_RULE} {_TIMES})*$")
_KEYWORDS = re.compile(r"hour|open|clos|mon|tue|wed|thu|fri|sat|sun|contact|phone|tel|call|email|e-mail|mail", re.I)


def _snippet(text_: str) -> str:
    """The lines of a page that mention hours or contact details, plus a line of context each."""
    lines = [ln.strip() for ln in text_.splitlines() if ln.strip()]
    keep: list[str] = []
    for i, ln in enumerate(lines):
        if _KEYWORDS.search(ln) and len(ln) < 200:
            for j in range(max(0, i - 1), min(len(lines), i + 3)):
                if lines[j] not in keep:
                    keep.append(lines[j])
    return "\n".join(keep)[:2500]


def _ai_fill(result: dict, texts: list[tuple[str, str]]) -> None:
    from . import services
    if result["opening_hours"] or not texts or not services.configured():
        return  # the model is only a fallback for opening hours, and only if a provider is set up
    for url, page_text in texts:
        snippet = _snippet(page_text)
        if len(snippet) < 20 or not re.search(r"\d", snippet):
            continue
        prompt = (
            "From the text of a business web page, extract ONLY what is written explicitly. Never guess.\n"
            'Reply with JSON only: {"opening_hours": <string or null>}\n'
            "opening_hours must use OpenStreetMap syntax with 24-hour times. Days are ONLY these two-letter codes: "
            "Mo Tu We Th Fr Sa Su. Example: \"Mo-Fr 09:00-17:00; Sa 10:00-14:00; Su off\". Several time ranges on one day are "
            "separated by commas, e.g. \"Mo-Sa 08:30-13:00,16:00-20:00\". Use null if no opening hours are stated.\n\nTEXT:\n" + snippet)
        answer = services.chat(prompt, max_tokens=120)   # the first free provider that can answer
        if not answer:
            return  # every provider is busy or out of allowance: skip quietly
        content, provider = answer
        try:
            hours = json.loads(re.search(r"\{.*\}", content, re.S).group(0)).get("opening_hours")
        except (ValueError, AttributeError):
            continue
        if isinstance(hours, str):  # models sometimes write "Sat" or "Mon" instead of the two-letter code
            hours = re.sub(r"\b(Mo|Tu|We|Th|Fr|Sa|Su)[a-z]{1,6}\b",
                           lambda m: m.group(1), hours.strip())
        if isinstance(hours, str) and HOURS_SYNTAX.fullmatch(hours.strip()):
            result["opening_hours"] = hours.strip()
            result["sources"]["opening_hours"] = url
            result["hours_by_ai"] = True   # shown with a "please confirm" label
            result["ai_provider"] = provider
            return


# ---------------------------------------------------------------------------
# Finds a place's OWN website when OpenStreetMap does not list one.
#
# Every free source is used, cheapest and most reliable first, and a candidate address is never trusted
# just because a source produced it: each one is opened and must prove it belongs to this place.
#
# Where candidates come from
#   1. the e-mail address the place already has (info@school.org -> school.org)
#   2. Wikidata: a search by the place's name, kept only if its coordinates are close by
#   3. guesses from the name (ambituskinderworld.com / .in / .org ...), each one opened to see if it exists
#   4. Google's web search through Serper / SerpAPI when their free keys are set (including Google's own
#      "knowledge panel" website)
#   5. keyless web search (DuckDuckGo, Yahoo, Bing, Startpage), by name + city, and by the place's phone number
#
# How a candidate is checked (see `_verify`)
#   it must load, be allowed by robots.txt, and mention the place's name (title, headings, site name, structured
#   data or domain); extra evidence - the place's phone number on the page, its city, its e-mail domain - raises
#   the score. Directories, maps and social networks are never accepted as "the website".
# ---------------------------------------------------------------------------
FINDER_BUDGET_S = 40            # the whole search for one place
MAX_SEARCH_HOSTS = 8           # search results that get opened
TLDS = (".com", ".in", ".org", ".co.in", ".edu.in", ".net", ".org.in", ".ac.in", ".info")
FREE_MAIL = {"gmail.com", "yahoo.com", "yahoo.in", "yahoo.co.in", "outlook.com", "hotmail.com", "live.com", "rediffmail.com",
             "icloud.com", "proton.me", "protonmail.com", "aol.com", "ymail.com", "msn.com", "mail.com", "zoho.com"}


def _digits(text_: str) -> str:
    return re.sub(r"\D", "", text_ or "")


def _home(url: str) -> str:
    p = urlparse(url)
    return f"{p.scheme}://{p.netloc}/" if p.scheme and p.netloc else ""


def _own_site_candidate(url: str) -> bool:
    low = (url or "").lower()
    return bool(re.match(r"^https?://", low)) and not any(bad in low for bad in NOT_OWN_SITE)


def _verify(url: str, names: list[str], phones: list[str], city_words: list[str], email_domains: set[str]) -> dict | None:
    """{"url", "score", "evidence"} if `url` is this place's website, else None."""
    try:
        if not _allowed(url):
            return None
        final, html = _get(url)
    except WebError:
        return None
    verdict = _judge_site(html, final, names)
    if verdict.get("status") != "ok":
        return None   # loads, but never mentions this place
    text_ = re.sub(r"<[^>]+>", " ", re.sub(r"(?is)<(script|style|noscript|svg).*?</\1>", " ", html))
    visible = re.sub(r"\s+", " ", text_).strip()
    key_words = _name_words(names[:1])
    # a parked or empty domain that merely has the name in its address is not the place's website: the name must
    # also be written in the page's own content
    if len(visible) < 150 or (key_words and not any(w in _squash(visible[:6000]) for w in key_words)):
        return None
    text_digits = _digits(text_)
    evidence, score = ["its name is on the page"], 2
    for phone in phones:
        tail = _digits(phone)[-9:]
        if len(tail) >= 8 and tail in text_digits:
            evidence.append("its phone number is on the page")
            score += 3
            break
    low = text_.lower()
    if city_words and any(w in low for w in city_words):
        evidence.append("its city is on the page")
        score += 1
    host = (urlparse(final).hostname or "").removeprefix("www.")
    key = max(_name_words(names[:1]) or [""], key=len)
    if len(key) >= 5 and key in _squash(host):
        evidence.append("its domain carries the name")
        score += 1
    if any(host == d or host.endswith("." + d) for d in email_domains):
        evidence.append("its e-mail address is on this domain")
        score += 2
    return {"url": final, "score": score, "evidence": evidence}


def _from_email(email_domains: set[str]) -> list[str]:
    out = []
    for domain in sorted(email_domains):
        out += [f"https://www.{domain}/", f"https://{domain}/"]
    return out


def _from_wikidata(name: str, lat: float, lng: float) -> list[str]:
    """Wikidata entities whose name matches and whose coordinates are within ~3 km; their official website."""
    try:
        resp = httpx.get("https://www.wikidata.org/w/api.php",
                         params={"action": "wbsearchentities", "search": name, "language": "en", "limit": 5, "format": "json"},
                         headers={"User-Agent": USER_AGENT}, timeout=WEB_TIMEOUT_S)
        resp.raise_for_status()
        ids = [h["id"] for h in resp.json().get("search", []) if re.fullmatch(r"Q\d+", h.get("id", ""))]
    except (httpx.HTTPError, ValueError, KeyError):
        return []
    out = []
    for qid in ids:
        try:
            entity = httpx.get(f"https://www.wikidata.org/wiki/Special:EntityData/{qid}.json",
                               headers={"User-Agent": USER_AGENT}, timeout=WEB_TIMEOUT_S).json()
            claims = next(iter(entity.get("entities", {}).values())).get("claims", {})
        except (httpx.HTTPError, ValueError, StopIteration):
            continue
        coords = [(c.get("mainsnak", {}).get("datavalue") or {}).get("value") for c in claims.get("P625", [])]
        near = any(isinstance(v, dict) and _haversine_km(lat, lng, v.get("latitude", 0), v.get("longitude", 0)) <= 3
                   for v in coords)
        if not near:
            continue   # a namesake somewhere else
        for c in claims.get("P856", []):
            value = (c.get("mainsnak", {}).get("datavalue") or {}).get("value")
            if isinstance(value, str):
                out.append(value)
    return out


def _resolving(urls: list[str]) -> list[str]:
    """The addresses among `urls` whose host name exists in DNS (checked in parallel, ~1 s in all), so guesses
    that cannot be websites are dropped without being opened one by one."""
    from concurrent.futures import ThreadPoolExecutor

    def ok(url: str) -> bool:
        try:
            socket.getaddrinfo(urlparse(url).hostname, 443, proto=socket.IPPROTO_TCP)
            return True
        except (socket.gaierror, UnicodeError, OSError):
            return False
    with ThreadPoolExecutor(max_workers=24) as pool:
        flags = list(pool.map(ok, urls))
    return [u for u, alive in zip(urls, flags) if alive]


def _from_name_guesses(words_all: list[str], words_key: list[str]) -> list[str]:
    """"Ambitus Kinder World" -> ambituskinderworld.com / .in / ...; "Refracto Eye Hospital" -> refracto.in ...
    Tries the whole name, the distinctive words, the first two words and the first word (if it is unusual)."""
    stems = []
    for words in (words_all, words_key, words_all[:2], words_key[:2], words_all[:1], words_key[:1]):
        stem = "".join(words)
        if 5 <= len(stem) <= 40 and stem not in stems:
            stems.append(stem)
    out = []
    for stem in stems:
        for tld in TLDS:
            out += [f"https://{stem}{tld}/", f"https://www.{stem}{tld}/"]   # many sites answer on only one of the two
    return _resolving(out)


def _from_search(name: str, city: str, phones: list[str]) -> list[str]:
    """Websites that web searches return for the place: by name + city, and by its phone number."""
    queries = [f"{name} {city}".strip(), f"{name} {city} official website".strip()]
    for phone in phones[:1]:
        if len(_digits(phone)) >= 8:
            queries.append(f'"{phone}"')
    urls: list[str] = []
    for q in queries:
        for hit in web_search(q):
            href = hit.get("href") or ""
            if _own_site_candidate(href):
                urls.append(href)
    return urls


def find(name: str, lat: float, lng: float, tags: dict, city: str = "", budget_s: float = FINDER_BUDGET_S) -> dict | None:
    """{"url", "source", "score", "evidence"} for the place's own website, or None if no source produced one
    that could be confirmed. Slow (it opens pages and runs searches): use it only on the details page."""
    deadline = time.time() + budget_s
    names = [n for n in (tags.get(k) for k in ("name", "name:en", "brand", "operator", "official_name", "short_name")) if n] or [name]
    words_key = _name_words(names[:1])
    plain_name = re.sub(r"\(.*?\)|\[.*?\]", " ", names[0] or "")   # "(A GROUP OF ...)" is not part of the name
    ascii_name = re.sub(r"[^a-z0-9 ]+", " ", plain_name.encode("ascii", "ignore").decode().lower())
    words_all = [w for w in ascii_name.split() if len(w) >= 2 and w not in ("the", "and", "of")]
    phones = [p for p in re.split(r"[;,]", str(tags.get("phone") or tags.get("contact:phone") or "")) if _digits(p)]
    email_domains = set()
    for e in re.split(r"[;,\s]+", str(tags.get("email") or tags.get("contact:email") or "")):
        if "@" in e:
            d = e.rsplit("@", 1)[1].lower().strip(".")
            if d and d not in FREE_MAIL:
                email_domains.add(d)
    city_words = [w for w in re.findall(r"[a-z]{4,}", (city or "").lower())]

    sources = [
        ("its e-mail domain", lambda: _from_email(email_domains), 2),
        ("Wikidata", lambda: _from_wikidata(name, lat, lng), 2),
        ("a guess from its name", lambda: _from_name_guesses(words_all, words_key), 0),
        ("a web search", lambda: _from_search(name, city, phones), 0),
    ]
    tried: set[str] = set()
    for label, produce, bonus in sources:
        if time.time() > deadline:
            break
        try:
            urls = produce()
        except Exception as exc:   # one broken source must not stop the others
            log.info("[site-finder] %s failed: %s", label, exc)
            continue
        best = None
        opened = 0
        for url in urls:
            host = urlparse(url).hostname or ""
            if not host or host in tried or time.time() > deadline:
                continue
            tried.add(host)
            if label == "a web search":
                if opened >= MAX_SEARCH_HOSTS:
                    break
                url = _home(url) or url   # the site's front page tells more about whose site it is than a deep link
                opened += 1
            result = _verify(url, names, phones, city_words, email_domains)
            if not result:
                continue
            result["score"] += bonus
            if result["score"] >= 3 and (best is None or result["score"] > best["score"]):
                best = result
                if label != "a web search" or result["score"] >= 5:
                    break   # a strong, direct answer: no need to open more
        if best:
            best["source"] = label
            log.info("[site-finder] %s -> %s via %s (score %s)", name, best["url"], label, best["score"])
            return best
    return None


# ---------------------------------------------------------------------------
# Look a place up with web-search tools to find what OpenStreetMap does not have: its website,
# phone number and a rating. Tools are tried in order; if one has no key, no free calls left or fails,
# the next one is used.
#
#     SERPER_API_KEY=       https://serper.dev            (2,500 free queries, no card)   website, phone, rating
#     SERPAPI_API_KEY=      https://serpapi.com           (250 free searches a month)     website, phone, rating
#     HERE_API_KEY=         https://developer.here.com    (free plan)                     website, phone, email
#     TOMTOM_API_KEY=       https://developer.tomtom.com  (2,500 free requests a day)     website, phone
#     FOURSQUARE_API_KEY=   https://foursquare.com/developers (free credits)              website, phone, email, rating
#     (no key needed)       DuckDuckGo, Yahoo, Bing, Startpage through the "ddgs" library  website + snippets
#     <NAME>_MONTHLY_LIMIT= calls the site allows itself per month for each tool above (e.g. HERE_MONTHLY_LIMIT)
#     DDGS_ENABLED=0        turns the keyless searches off
#
# Tools are used in that order, and only for what is still missing. A tool with no key is skipped; one that
# answers "limit reached" / "not allowed" / an error is left alone for a while and the next one is used.
#
# A result is used only if it is really the same place: the name must be similar and the position
# must be within a few hundred metres of the OpenStreetMap place. Nothing here can provide an email
# address or user comments (the website reader looks for emails on the place's own website).
# ---------------------------------------------------------------------------
PROVIDERS = {
    # tools that need a free key: they know the place by position, so the match is checked against its coordinates
    "serper": {"key": "SERPER_API_KEY", "base": "https://google.serper.dev", "default_limit": 100},
    "serpapi": {"key": "SERPAPI_API_KEY", "base": "https://serpapi.com", "default_limit": 200},
    "here": {"key": "HERE_API_KEY", "base": "https://discover.search.hereapi.com", "default_limit": 3000},
    "tomtom": {"key": "TOMTOM_API_KEY", "base": "https://api.tomtom.com", "default_limit": 3000},
    "foursquare": {"key": "FOURSQUARE_API_KEY", "base": "https://places-api.foursquare.com", "default_limit": 300},
    # keyless web search through the ddgs library, one search engine at a time
    "duckduckgo": {"key": None, "backend": "duckduckgo", "default_limit": 1500},
    "yahoo": {"key": None, "backend": "yahoo", "default_limit": 1500},
    "bing": {"key": None, "backend": "bing", "default_limit": 1500},
    "startpage": {"key": None, "backend": "startpage", "default_limit": 1500},
}
ORDER = ["serper", "serpapi", "here", "tomtom", "foursquare", "duckduckgo", "yahoo", "bing", "startpage"]
KEYLESS = [n for n in ORDER if PROVIDERS[n]["key"] is None]
MAX_KEYLESS_PER_LOOKUP = 2   # each keyless engine costs seconds: try at most this many per place
DDGS_MIN_INTERVAL_S = 3.0    # be gentle: these are unofficial, keyless sources
SEARCH_TIMEOUT_S = 15
MAX_KM = 0.4
# Directories, social networks and maps are not the place's own website.
NOT_A_WEBSITE = ("facebook.", "instagram.", "twitter.", "x.com", "linkedin.", "youtube.", "tiktok.", "pinterest.", "yelp.",
                 "tripadvisor.", "justdial.", "zomato.", "swiggy.", "practo.", "lybrate.", "wanderlog.", "deliveroo.",
                 "ubereats.", "doordash.", "google.", "bing.", "wikipedia.", "wikidata.", "mapquest.", "foursquare.",
                 "yellowpages.", "sulekha.", "indiamart.", "doctorsfinder.", "mediyaar.", "dineawards", "booking.",
                 "agoda.", "makemytrip.", "amazon.", "flipkart.", "openstreetmap.", "apple.com/maps", "nhs.uk/services",
                 "healthgrades.", "webmd.", "yell.com", "cylex.", "kompass.", "waze.", "trustpilot.")
NOT_OWN_SITE = NOT_A_WEBSITE + tuple()  # LISTING_SITES is appended below, once defined

_cooldown: dict[str, tuple[float, str]] = {}


def _key(name: str) -> str:
    if PROVIDERS[name]["key"] is None:
        return "on" if os.getenv("DDGS_ENABLED", "1") != "0" else ""
    return os.getenv(PROVIDERS[name]["key"], "").strip()


def configured() -> list[str]:
    return [n for n in ORDER if _key(n)]


def _limit(name: str) -> int:
    try:
        return int(os.getenv(f"{name.upper()}_MONTHLY_LIMIT", str(PROVIDERS[name]["default_limit"])))
    except ValueError:
        return PROVIDERS[name]["default_limit"]


def _month() -> str:
    return time.strftime("%Y-%m", time.gmtime())


def _reserve(name: str) -> bool:
    """Count one call BEFORE making it; False once this month's allowance is used up."""
    try:
        with engine.begin() as conn:
            row = conn.execute(text(
                "INSERT INTO api_usage (provider, kind, month, calls) VALUES (:p, 'lookup', :m, 1) "
                "ON CONFLICT (provider, kind, month) DO UPDATE SET calls = api_usage.calls + 1 "
                "WHERE api_usage.calls < :limit RETURNING calls"),
                {"p": name, "m": _month(), "limit": _limit(name)}).first()
        return row is not None
    except Exception:
        return False


def _refund(name: str) -> None:
    try:
        with engine.begin() as conn:
            conn.execute(text("UPDATE api_usage SET calls = GREATEST(calls - 1, 0) "
                              "WHERE provider = :p AND kind = 'lookup' AND month = :m"), {"p": name, "m": _month()})
    except Exception:
        pass


def status() -> list[dict]:
    out = []
    for name in configured():
        try:
            with engine.connect() as conn:
                used = conn.execute(text("SELECT calls FROM api_usage WHERE provider = :p AND kind = 'lookup' "
                                         "AND month = :m"), {"p": name, "m": _month()}).scalar() or 0
        except Exception:
            used = 0
        until, reason = _cooldown.get(name, (0, ""))
        out.append({"provider": name, "used": used, "limit": _limit(name), "period": "month",
                    "paused": reason if time.time() < until else ""})
    return out


def _norm(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (name or "").lower()).strip()


def _number(value) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _best_match(candidates: list[dict], name: str, lat: float, lng: float) -> dict | None:
    """The candidate that is the same place: similar name and within MAX_KM."""
    want = _norm(name)
    best, best_score = None, 0.0
    for c in candidates:
        found = _norm(c.get("name"))
        if not found or c.get("lat") is None or c.get("lng") is None:
            continue
        distance = _haversine_km(lat, lng, c["lat"], c["lng"])
        if distance > MAX_KM:
            continue
        similarity = difflib.SequenceMatcher(None, want, found).ratio()
        if len(want) >= 4 and (want in found or found in want):
            similarity = max(similarity, 0.9)
        score = similarity - distance
        if similarity >= 0.6 and score > best_score:
            best, best_score = c, score
    return best


def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


# ---------------------------------------------------------------------------
# The two providers: each returns a list of {name, lat, lng, rating, rating_count, phone, website, address}
# ---------------------------------------------------------------------------
def _serper(query: str, lat: float, lng: float) -> list[dict]:
    resp = httpx.post(os.getenv("SERPER_BASE_URL", PROVIDERS["serper"]["base"]).rstrip("/") + "/places",
                      headers={"X-API-KEY": _key("serper"), "Content-Type": "application/json"},
                      json={"q": query, "ll": f"@{lat},{lng},16z"}, timeout=SEARCH_TIMEOUT_S)
    resp.raise_for_status()
    out = []
    for p in resp.json().get("places", []):
        out.append({"name": p.get("title"), "lat": _number(p.get("latitude")), "lng": _number(p.get("longitude")),
                    "rating": _number(p.get("rating")), "rating_count": int(_number(p.get("ratingCount")) or 0),
                    "phone": p.get("phoneNumber") or "", "website": p.get("website") or "", "address": p.get("address") or "",
                    "cid": p.get("cid") or "", "place_id": p.get("placeId") or "",   # the ids the reviews call needs
                    "opening_hours": hours_from_google(
                        p.get("openingHours") or p.get("hours") or p.get("workingHours"))})
    return out


def _serpapi(query: str, lat: float, lng: float) -> list[dict]:
    resp = httpx.get(os.getenv("SERPAPI_BASE_URL", PROVIDERS["serpapi"]["base"]).rstrip("/") + "/search.json",
                     params={"engine": "google_maps", "q": query, "ll": f"@{lat},{lng},16z", "type": "search",
                             "api_key": _key("serpapi")}, timeout=SEARCH_TIMEOUT_S)
    resp.raise_for_status()
    out = []
    for p in resp.json().get("local_results", []) or []:
        gps = p.get("gps_coordinates") or {}
        out.append({"name": p.get("title"), "lat": _number(gps.get("latitude")), "lng": _number(gps.get("longitude")),
                    "rating": _number(p.get("rating")), "rating_count": int(_number(p.get("reviews")) or 0),
                    "phone": p.get("phone") or "", "website": p.get("website") or "", "address": p.get("address") or "",
                    "data_id": p.get("data_id") or "",   # the id the reviews / hours calls need
                    "opening_hours": hours_from_google(p.get("operating_hours"))})
    return out


def _here(query: str, lat: float, lng: float) -> list[dict]:
    resp = httpx.get(os.getenv("HERE_BASE_URL", PROVIDERS["here"]["base"]).rstrip("/") + "/v1/discover",
                     params={"at": f"{lat},{lng}", "q": query, "limit": 5, "apiKey": _key("here")}, timeout=SEARCH_TIMEOUT_S)
    resp.raise_for_status()
    out = []
    for p in resp.json().get("items", []) or []:
        pos = p.get("position") or {}

        def first(kind: str) -> str:
            for contact in p.get("contacts") or []:
                for entry in contact.get(kind) or []:
                    if entry.get("value"):
                        return entry["value"]
            return ""
        out.append({"name": p.get("title"), "lat": _number(pos.get("lat")), "lng": _number(pos.get("lng")),
                    "rating": None, "rating_count": 0, "phone": first("phone"), "website": first("www"),
                    "email": first("email"), "address": (p.get("address") or {}).get("label") or ""})
    return out


def _tomtom(query: str, lat: float, lng: float) -> list[dict]:
    resp = httpx.get(os.getenv("TOMTOM_BASE_URL", PROVIDERS["tomtom"]["base"]).rstrip("/") +
                     "/search/2/poiSearch/" + quote(query) + ".json",
                     params={"key": _key("tomtom"), "lat": lat, "lon": lng, "limit": 5, "radius": 1000}, timeout=SEARCH_TIMEOUT_S)
    resp.raise_for_status()
    out = []
    for p in resp.json().get("results", []) or []:
        poi, pos = p.get("poi") or {}, p.get("position") or {}
        site = poi.get("url") or ""
        out.append({"name": poi.get("name"), "lat": _number(pos.get("lat")), "lng": _number(pos.get("lon")),
                    "rating": None, "rating_count": 0, "phone": poi.get("phone") or "",
                    "website": site if re.match(r"^https?://", site, re.I) or not site else "https://" + site,
                    "email": "", "address": (p.get("address") or {}).get("freeformAddress") or ""})
    return out


def _foursquare(query: str, lat: float, lng: float) -> list[dict]:
    resp = httpx.get(os.getenv("FOURSQUARE_BASE_URL", PROVIDERS["foursquare"]["base"]).rstrip("/") + "/places/search",
                     headers={"Authorization": f"Bearer {_key('foursquare')}", "Accept": "application/json",
                              "X-Places-Api-Version": os.getenv("FOURSQUARE_API_VERSION", "2025-06-17")},
                     params={"query": query, "ll": f"{lat},{lng}", "radius": 1000, "limit": 5,
                             "fields": "name,latitude,longitude,tel,website,email,rating,stats,location"},
                     timeout=SEARCH_TIMEOUT_S)
    resp.raise_for_status()
    out = []
    for p in resp.json().get("results", []) or []:
        main = (p.get("geocodes") or {}).get("main") or {}
        rating = _number(p.get("rating"))   # Foursquare rates out of 10
        out.append({"name": p.get("name"), "lat": _number(p.get("latitude")) or _number(main.get("latitude")),
                    "lng": _number(p.get("longitude")) or _number(main.get("longitude")),
                    "rating": round(rating / 2, 1) if rating else None,
                    "rating_count": int(_number((p.get("stats") or {}).get("total_ratings")) or 0),
                    "phone": p.get("tel") or "", "website": p.get("website") or "", "email": p.get("email") or "",
                    "address": (p.get("location") or {}).get("formatted_address") or ""})
    return out


GOOGLE_MAPS = ("serper", "serpapi")   # the tools that read Google Maps: the only ones with reviews
MAX_REVIEWS = 5


def _clean_reviews(items: list) -> list[dict]:
    """[{author, rating, text, date}] - only reviews that actually have a comment, newest/best first as
    the tool returned them, a few of them."""
    out = []
    for it in items or []:
        if not isinstance(it, dict):
            continue
        user = it.get("user") if isinstance(it.get("user"), dict) else {}
        snippet = it.get("snippet") or it.get("text") or ""
        if isinstance(it.get("extracted_snippet"), dict):
            snippet = it["extracted_snippet"].get("original") or snippet
        text_ = re.sub(r"\s+", " ", str(snippet)).strip()
        rating = _number(it.get("rating"))
        if not text_ or not rating or not 1 <= rating <= 5:
            continue
        out.append({"author": str(user.get("name") or it.get("name") or "A Google user")[:60],
                    "rating": int(round(rating)), "text": text_[:500],
                    "date": str(it.get("date") or it.get("iso_date") or it.get("isoDate") or "")[:40]})
        if len(out) >= MAX_REVIEWS:
            break
    return out


def _serper_reviews(match: dict) -> list[dict]:
    ident = {"cid": match["cid"]} if match.get("cid") else {"placeId": match.get("place_id")}
    if not any(ident.values()):
        return []
    resp = httpx.post(os.getenv("SERPER_BASE_URL", PROVIDERS["serper"]["base"]).rstrip("/") + "/reviews",
                      headers={"X-API-KEY": _key("serper"), "Content-Type": "application/json"},
                      json=ident, timeout=SEARCH_TIMEOUT_S)
    resp.raise_for_status()
    return _clean_reviews(resp.json().get("reviews"))


def _serpapi_reviews(match: dict) -> list[dict]:
    if not match.get("data_id"):
        return []
    resp = httpx.get(os.getenv("SERPAPI_BASE_URL", PROVIDERS["serpapi"]["base"]).rstrip("/") + "/search.json",
                     params={"engine": "google_maps_reviews", "data_id": match["data_id"], "hl": "en",
                             "sort_by": "qualityScore", "api_key": _key("serpapi")}, timeout=SEARCH_TIMEOUT_S)
    resp.raise_for_status()
    return _clean_reviews(resp.json().get("reviews"))


_REVIEWS = {"serper": _serper_reviews, "serpapi": _serpapi_reviews}


def _serpapi_hours(match: dict) -> str | None:
    """The weekly opening hours on the place's own Google Maps page (one extra SerpAPI call), as OSM text."""
    if not match.get("data_id"):
        return None
    resp = httpx.get(os.getenv("SERPAPI_BASE_URL", PROVIDERS["serpapi"]["base"]).rstrip("/") + "/search.json",
                     params={"engine": "google_maps", "type": "place", "data_id": match["data_id"], "hl": "en",
                             "api_key": _key("serpapi")}, timeout=SEARCH_TIMEOUT_S)
    resp.raise_for_status()
    place = resp.json().get("place_results") or {}
    return hours_from_google(place.get("operating_hours") or place.get("hours"))

RATING_FROM = {"serper": "Google Maps search results", "serpapi": "Google Maps search results",
               "foursquare": "Foursquare", "duckduckgo": "DuckDuckGo search results", "yahoo": "Yahoo search results",
               "bing": "Bing search results", "startpage": "Startpage search results"}
_CALL = {"serper": _serper, "serpapi": _serpapi, "here": _here, "tomtom": _tomtom, "foursquare": _foursquare}


# ---------------------------------------------------------------------------
# Keyless web search (DuckDuckGo through the ddgs library): finds a place's website only
# ---------------------------------------------------------------------------
_ddgs_lock = threading.Lock()
_ddgs_last = 0.0


def _ddgs_results(query: str, backend: str = "duckduckgo") -> list[dict]:   # one small function, so tests can replace it
    from ddgs import DDGS
    return DDGS().text(query, max_results=10, backend=backend)


PHONE_RE = re.compile(r"(?:phone|tel(?:ephone)?|call|contact|mobile|helpline|appointments?)\W{0,12}?"
                      r"(\+?\(?\d[\d\s().-]{6,17}\d)", re.I)
RATING_RES = (   # "Rated 4.5 based on 456 reviews", "4.3/5 (120 reviews)", "4.2 stars from 87 ratings"
    re.compile(r"(?:rated|rating)\D{0,12}(\d(?:\.\d)?)\D{0,40}?(\d[\d,]*)\s*(?:customer\s*)?(?:reviews?|ratings?|votes)", re.I),
    re.compile(r"(\d(?:\.\d)?)\s*(?:/\s*5|out of 5)\b\D{0,40}?(\d[\d,]*)\s*(?:reviews?|ratings?|votes)", re.I),
    re.compile(r"(\d(?:\.\d)?)\s*(?:stars?|★)\D{0,30}?(\d[\d,]*)\s*(?:reviews?|ratings?|votes)", re.I),
)


def _enough_name(words: list[str], hits: list[str], short_ok: bool = False) -> bool:
    """A result must match most of the place's distinctive name words; a one-word name must be a long,
    unusual word ("mark" would match any shop called Marks) - unless `short_ok`, used only together with
    a city/area check (a directory page for "Leaf Hospital" in Hyderabad)."""
    if not words:
        return False
    if len(words) == 1:
        return bool(hits) and (len(words[0]) >= 5 or (short_ok and len(words[0]) >= 4))
    return len(hits) >= max(2, (len(words) + 1) // 2)


# Directory sites with a page per place: not the place's own website, but a fair source of its address, hours
# and rating when it has no website of its own. Never used for the website field or for an email.
LISTING_SITES = ("hexahealth.", "practo.", "justdial.", "lybrate.", "credihealth.", "docprime.", "medindia.",
                 "sulekha.", "yellowpages.", "cylex.", "schooldekho.", "shiksha.", "careers360.", "collegedunia.",
                 "getmyuni.", "edufever.", "wikimapia.")
NOT_OWN_SITE = NOT_A_WEBSITE + LISTING_SITES   # (re-set now both tuples are defined; see the placeholder above)


def _about_this_place(r: dict, words: list[str], hint: str, short_ok: bool = False) -> bool:
    """A search result that is about this place: its title/address carries the name, and the city/area
    (when we know one) shows up too - so a branch in another city does not lend us its phone number."""
    url = r.get("href") or ""
    host = (re.match(r"^https?://([^/]+)", url, re.I) or [None, ""])[1].lower()
    text_ = f"{r.get('title') or ''} {r.get('body') or ''} {url}".lower()
    haystack = _squash(host + " " + (r.get("title") or "") + " " + url.split("/", 3)[-1])
    hits = [w for w in words if w in haystack]
    hint_words = [w for w in re.findall(r"[a-z]{4,}", (hint or "").lower())]
    if not _enough_name(words, hits, short_ok=bool(short_ok and hint_words)):
        return False
    return not hint_words or any(w in text_ for w in hint_words)


def _facts_from_snippet(r: dict) -> dict:
    """Phone, email and rating written in one search result's title/snippet."""
    text_ = f"{r.get('title') or ''}. {r.get('body') or ''}"
    out = {"phone": "", "email": "", "rating": None, "rating_count": 0}
    m = PHONE_RE.search(text_)
    if m and (phone := _phone_ok(m.group(1))):
        out["phone"] = phone
    for e in EMAIL_RE.findall(text_):
        ok = _email_ok(e)
        if ok and not any(bad in ok.rsplit("@", 1)[1] for bad in NOT_A_WEBSITE):   # not a directory's own address
            out["email"] = ok
            break
    for pattern in RATING_RES:
        m = pattern.search(text_)
        if m:
            try:
                value, count = float(m.group(1)), int(m.group(2).replace(",", ""))
            except ValueError:
                continue
            if 1 <= value <= 5 and count > 0:
                out["rating"], out["rating_count"] = round(value, 1), count
                break
    return out


def _ddgs_lookup(name: str, hint: str, need: set, backend: str = "duckduckgo") -> dict | None:
    """A keyless web search (one engine: DuckDuckGo, Yahoo, Bing...): the place's own website, and the
    phone, email and rating that directory pages (Practo, Justdial...) and its own site show in their
    search snippets. Only what is in `need` is looked for. Every fact is used only from a result that is
    about this place (see _about_this_place)."""
    failures, attempts = [], []

    def search(query: str) -> list[dict]:
        global _ddgs_last
        attempts.append(query)
        with _ddgs_lock:
            wait = DDGS_MIN_INTERVAL_S - (time.time() - _ddgs_last)
            if wait > 0:
                time.sleep(wait)
            _ddgs_last = time.time()
            try:
                return _ddgs_results(query, backend)
            except Exception as exc:   # "No results found" for one odd query must not lose the other query's answer
                log.info("%s search %r gave nothing: %s", backend, query, exc)
                failures.append(exc)
                return []

    words = _name_words([name])
    found = {"website": "", "phone": "", "email": "", "rating": None, "rating_count": 0, "address": "", "listing": ""}
    site_results = search(f"{name} {hint} official website".strip()) if need & {"website", "listing"} else []
    for r in site_results:
        url = r.get("href") or ""
        host = (re.match(r"^https?://([^/]+)", url, re.I) or [None, ""])[1].lower()
        if not host or any(bad in url.lower() for bad in NOT_A_WEBSITE):
            continue
        squashed_host = _squash(host)
        main_word = max(words, key=len) if words else ""
        hits = [w for w in words if w in squashed_host]
        # the place's own site has the name IN ITS DOMAIN: its most distinctive word, and (for a short
        # word) more than that alone - a directory or an unrelated company merely mentioning it does not count
        if main_word in squashed_host and (len(main_word) >= 5 or len(hits) >= 2):
            found["website"] = url
            break

    info_results: list[dict] = []
    if need & {"phone", "email", "rating"} and hint:   # without a city/area a namesake elsewhere cannot be ruled out
        info_results = search(f"{name} {hint} phone number email rating reviews".strip())
        site_host = _squash((re.match(r"^https?://([^/]+)", found["website"], re.I) or [None, ""])[1])
        for r in site_results + info_results:
            if not _about_this_place(r, words, hint):
                continue
            facts = _facts_from_snippet(r)
            domain = _squash(facts["email"].rsplit("@", 1)[-1]) if facts["email"] else ""
            if facts["email"] and not (domain and (domain == site_host or any(w in domain for w in words))):
                facts["email"] = ""   # an address on somebody else's domain (an aggregator, another company)
            for key in ("phone", "email"):
                found[key] = found[key] or facts[key]
            if found["rating"] is None and facts["rating"]:
                found["rating"], found["rating_count"] = facts["rating"], facts["rating_count"]
    if not found["website"] and "listing" in need and hint:
        # no official website: a directory page about this very place (name + city both in the result)
        for r in site_results + info_results:
            url = r.get("href") or ""
            if any(site in url.lower() for site in LISTING_SITES) and _about_this_place(r, words, hint, short_ok=True):
                found["listing"] = url
                break

    if not any(found[k] for k in ("website", "phone", "email", "rating", "listing")):
        if attempts and len(failures) == len(attempts):
            raise failures[-1]   # every search this engine was asked failed (blocked or rate-limited): let the next engine try
        return None
    return found

def _guarded(provider: str, call):
    """Runs `call()` for a tool that counts against a monthly allowance, with the same rules as lookup_place:
    skipped while paused or out of calls; a limit / permission / network error pauses it and returns None."""
    until, _reason = _cooldown.get(provider, (0, ""))
    if time.time() < until or not _key(provider):
        return None
    if not _reserve(provider):
        _cooldown[provider] = (time.time() + 3600, "monthly allowance used up")
        return None
    try:
        return call()
    except httpx.HTTPStatusError as exc:
        _refund(provider)
        code = exc.response.status_code
        _cooldown[provider] = (time.time() + (3600 if code in (401, 402, 403, 429) else 300), f"HTTP {code}")
        log.warning("Search tool %s answered HTTP %s, trying the next one", provider, code)
    except (httpx.HTTPError, ValueError) as exc:
        _refund(provider)
        _cooldown[provider] = (time.time() + 300, f"unreachable ({exc.__class__.__name__})")
    except Exception as exc:   # the keyless library can fail in ways of its own
        _refund(provider)
        _cooldown[provider] = (time.time() + 1800, f"failed ({exc.__class__.__name__})")
        log.warning("Search tool %s failed: %s", provider, exc)
    return None


def _serper_web(query: str) -> list[dict]:
    resp = httpx.post(os.getenv("SERPER_BASE_URL", PROVIDERS["serper"]["base"]).rstrip("/") + "/search",
                      headers={"X-API-KEY": _key("serper"), "Content-Type": "application/json"},
                      json={"q": query, "num": 10}, timeout=SEARCH_TIMEOUT_S)
    resp.raise_for_status()
    data = resp.json()
    out = []
    site = (data.get("knowledgeGraph") or {}).get("website")   # Google's own panel for the place
    if site:
        out.append({"href": site, "title": (data.get("knowledgeGraph") or {}).get("title") or "", "body": ""})
    out += [{"href": o.get("link") or "", "title": o.get("title") or "", "body": o.get("snippet") or ""}
            for o in data.get("organic", []) or []]
    return out


def _serpapi_web(query: str) -> list[dict]:
    resp = httpx.get(os.getenv("SERPAPI_BASE_URL", PROVIDERS["serpapi"]["base"]).rstrip("/") + "/search.json",
                     params={"engine": "google", "q": query, "num": 10, "api_key": _key("serpapi")}, timeout=SEARCH_TIMEOUT_S)
    resp.raise_for_status()
    data = resp.json()
    out = []
    site = (data.get("knowledge_graph") or {}).get("website")
    if site:
        out.append({"href": site, "title": (data.get("knowledge_graph") or {}).get("title") or "", "body": ""})
    out += [{"href": o.get("link") or "", "title": o.get("title") or "", "body": o.get("snippet") or ""}
            for o in data.get("organic_results", []) or []]
    return out


def web_search(query: str) -> list[dict]:
    """Ordinary web-search results [{href, title, body}] for `query`, from the first tool that answers:
    Google through Serper, Google through SerpAPI (free keys), then DuckDuckGo, Yahoo, Bing, Startpage (no key).
    A tool that is out of calls or blocked is skipped, so the next one is used."""
    for provider, call in (("serper", _serper_web), ("serpapi", _serpapi_web)):
        results = _guarded(provider, lambda c=call: c(query))
        if results:
            return results
    global _ddgs_last
    for provider in KEYLESS:
        if not _key(provider):
            continue

        def keyless(backend=PROVIDERS[provider]["backend"]):
            global _ddgs_last
            with _ddgs_lock:
                wait = DDGS_MIN_INTERVAL_S - (time.time() - _ddgs_last)
                if wait > 0:
                    time.sleep(wait)
                _ddgs_last = time.time()
                return _ddgs_results(query, backend)
        results = _guarded(provider, keyless)
        if results:
            return results
    return []


def _web_url(url: str) -> str:
    """Only an http(s) address is kept."""
    return url if re.match(r"^https?://", url or "", re.I) else ""


def lookup_place(name: str, lat: float, lng: float, hint: str = "", need: set | None = None) -> dict | None:
    """{website, phone, email, rating, rating_count, rating_from, address, provider(s)} for the place, or
    None when no tool is set up / has calls left / finds this exact place. `need` says which of "website",
    "phone", "email", "rating" the caller lacks (default: all); "reviews" asks for the comments on the
    place's Google Maps listing (Serper / SerpAPI only), returned as `reviews`. Tools are tried in order; a tool that finds
    the place but not everything does not stop the search: the next tool (finally DuckDuckGo) fills the gaps."""
    query = " ".join(x for x in [name, hint] if x).strip()
    need = set(need) if need else {"website", "phone", "email", "rating"}
    merged: dict = {"website": "", "phone": "", "email": "", "rating": None, "rating_count": 0, "rating_from": "",
                    "address": "", "opening_hours": "", "listing": "", "providers": [], "reviews": []}
    google_match: tuple[str, dict] | None = None   # (tool, its Google Maps listing of this place)

    def still_needed() -> set:
        have = {k for k in ("website", "phone", "email", "address", "opening_hours") if merged[k]} | ({"rating"} if merged["rating"] else set())
        if merged["website"]:
            have.add("listing")   # an official website beats a directory page
        return need - {"reviews"} - have

    keyless_tried = 0
    for provider in configured():
        wants_google = "reviews" in need and google_match is None   # comments only exist on Google Maps
        if not still_needed() and not wants_google:
            break
        if not still_needed() and provider not in GOOGLE_MAPS:
            continue   # only a Google Maps tool can still add something (the comments)
        until, _reason = _cooldown.get(provider, (0, ""))
        if time.time() < until:
            continue
        if provider in KEYLESS and (keyless_tried >= MAX_KEYLESS_PER_LOOKUP or not (still_needed() - {"address", "opening_hours"})):
            continue   # enough slow keyless searches for one place (and they cannot supply an address or hours)
        if not _reserve(provider):
            _cooldown[provider] = (time.time() + 3600, "monthly allowance used up")
            continue
        try:
            if provider in KEYLESS:
                keyless_tried += 1
                match = _ddgs_lookup(name, hint, still_needed(), PROVIDERS[provider]["backend"])
            else:
                match = _best_match(_CALL[provider](query, lat, lng), name, lat, lng)
        except httpx.HTTPStatusError as exc:
            _refund(provider)
            code = exc.response.status_code
            _cooldown[provider] = (time.time() + (3600 if code in (401, 402, 403, 429) else 300), f"HTTP {code}")
            log.warning("Search tool %s answered HTTP %s, trying the next one", provider, code)
            continue
        except (httpx.HTTPError, ValueError) as exc:
            _refund(provider)
            _cooldown[provider] = (time.time() + 300, f"unreachable ({exc.__class__.__name__})")
            continue
        except Exception as exc:   # the keyless library can fail in ways of its own (rate limits, changed pages)
            _refund(provider)
            _cooldown[provider] = (time.time() + 1800, f"failed ({exc.__class__.__name__})")
            log.warning("Search tool %s failed: %s", provider, exc)
            continue
        if not match:
            continue
        if provider in GOOGLE_MAPS and google_match is None:
            google_match = (provider, match)
        if (provider == "serpapi" and "opening_hours" in still_needed() and not match.get("opening_hours")
                and not merged["opening_hours"] and match.get("data_id") and _reserve(provider)):
            try:   # the search list has no weekly hours for this place: ask its own Google Maps page
                match["opening_hours"] = _serpapi_hours(match)
            except Exception as exc:
                _refund(provider)
                log.warning("Opening hours from %s could not be read: %s", provider, exc)
        merged["providers"].append(provider)
        for key in ("website", "phone", "email", "address", "opening_hours", "listing"):
            merged[key] = merged[key] or (_web_url(match.get(key, "")) if key in ("website", "listing") else (match.get(key) or ""))
        if match.get("opening_hours") and not merged.get("hours_from"):
            merged["hours_from"] = provider
        if merged["rating"] is None and match.get("rating"):
            merged["rating"], merged["rating_count"] = match["rating"], match.get("rating_count", 0)
            merged["rating_from"] = RATING_FROM.get(provider) or f"{provider.title()} search results"

    if google_match and "reviews" in need:   # the comments people left on the Google Maps listing we matched
        provider, listing = google_match
        if _reserve(provider):
            try:
                merged["reviews"] = _REVIEWS[provider](listing)
            except Exception as exc:   # comments are a bonus: never lose the rest because they failed
                _refund(provider)
                log.warning("Reviews from %s could not be read: %s", provider, exc)
    if not merged["providers"]:
        return None
    merged["provider"] = merged["providers"][0]
    return merged
