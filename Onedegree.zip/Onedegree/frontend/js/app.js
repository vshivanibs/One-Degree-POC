/* One Degree UI clone - shared logic (no real backend, localStorage only) */

/* Opening hours: OpenStreetMap text -> a week table in 12-hour time, and "today" / "open now" worked
   out in the place's own time zone (from /api/timezone), not the computer's. */
const OdHours = (function () {
  const DAY_ABBR = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];
  const DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  const DAY_RE = "(?:Mo|Tu|We|Th|Fr|Sa|Su)";
  const DAY_SPEC = "(?:" + DAY_RE + "(?:-" + DAY_RE + ")?)";
  const RULE_RE = new RegExp("^(" + DAY_SPEC + "(?:\\s*,\\s*" + DAY_SPEC + ")*)?\\s*(.*)$");
  const TIME_RANGE = "\\d{1,2}:\\d{2}\\s*-\\s*\\d{1,2}:\\d{2}";
  const TIMES_RE = new RegExp("^" + TIME_RANGE + "(?:\\s*,\\s*" + TIME_RANGE + ")*$");

  function expandDays(spec) {
    const out = [];
    spec.split(",").forEach(function (part) {
      const m = part.trim().match(new RegExp("^(" + DAY_RE + ")(?:-(" + DAY_RE + "))?$"));
      const from = DAY_ABBR.indexOf(m[1]);
      const to = m[2] ? DAY_ABBR.indexOf(m[2]) : from;
      for (let i = from; ; i = (i + 1) % 7) {
        if (out.indexOf(i) === -1) out.push(i);
        if (i === to) break;
      }
    });
    return out;
  }

  /* "18:30" -> "6:30 PM" ; "00:00" -> "12:00 AM" ; "24:00" -> "12:00 AM" */
  function time12(hhmm) {
    const p = hhmm.split(":");
    const h = parseInt(p[0], 10) % 24;
    return ((h % 12) || 12) + ":" + p[1] + " " + (h < 12 ? "AM" : "PM");
  }

  /* every hh:mm in a piece of text becomes 12-hour time */
  function text12(text) {
    return String(text || "").replace(/\b(\d{1,2}):(\d{2})\b/g, function (m) { return time12(m); });
  }

  /* -> ["07:00–21:00", "Closed", ..., null] for Monday..Sunday (24-hour, internal), or null if the text uses
     syntax we do not handle (then the original text is shown as it is). */
  function parse(raw) {
    const s = (raw || "").trim();
    if (!s) return null;
    if (/^24\/7$/i.test(s)) return DAY_ABBR.map(function () { return "Open 24 hours"; });
    const days = [null, null, null, null, null, null, null];
    const rules = s.split(";");
    for (let r = 0; r < rules.length; r++) {
      const rule = rules[r].trim();
      if (!rule || /^(PH|SH)\b/i.test(rule)) continue;  // public / school holidays are not shown
      const m = rule.match(RULE_RE);
      if (!m) return null;
      const rest = (m[2] || "").trim();
      let value;
      if (/^(off|closed)$/i.test(rest)) value = "Closed";
      else if (/^24\/7$/i.test(rest)) value = "Open 24 hours";
      else if (TIMES_RE.test(rest)) value = rest.replace(/\s*,\s*/g, ", ").replace(/\s*-\s*/g, "–");
      else return null;
      (m[1] ? expandDays(m[1]) : [0, 1, 2, 3, 4, 5, 6]).forEach(function (i) { days[i] = value; });
    }
    return days.some(function (d) { return d; }) ? days : null;
  }

  /* a day's text for display, in 12-hour time */
  function show(value) {
    return value ? text12(value).replace(/–/g, " – ") : "";
  }

  /* {day: 0=Monday..6, minutes since midnight} right now in a time zone (this computer's when unknown) */
  function nowIn(timeZone) {
    let d = new Date();
    if (timeZone) {
      try {
        const parts = {};
        new Intl.DateTimeFormat("en-US", { timeZone: timeZone, weekday: "short", hour: "2-digit", minute: "2-digit", hourCycle: "h23" })
          .formatToParts(d).forEach(function (p) { parts[p.type] = p.value; });
        return { day: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].indexOf(parts.weekday),
                 minutes: (parseInt(parts.hour, 10) % 24) * 60 + parseInt(parts.minute, 10) };
      } catch (e) { /* unknown zone: fall through */ }
    }
    return { day: (d.getDay() + 6) % 7, minutes: d.getHours() * 60 + d.getMinutes() };
  }

  function minutes(hhmm) {
    const p = hhmm.split(":");
    return parseInt(p[0], 10) * 60 + parseInt(p[1], 10);
  }

  function ranges(value) {
    if (!value || value === "Closed") return [];
    if (value === "Open 24 hours") return [[0, 24 * 60]];
    return value.split(", ").map(function (t) {
      const p = t.split("–");
      return [minutes(p[0]), minutes(p[1])];
    });
  }

  /* true / false */
  function isOpen(days, now) {
    const yesterday = (now.day + 6) % 7;
    let open = false;
    ranges(days[now.day]).forEach(function (r) {
      if (r[1] > r[0] ? (now.minutes >= r[0] && now.minutes < r[1]) : now.minutes >= r[0]) open = true;   // "22:00-02:00" runs past midnight
    });
    ranges(days[yesterday]).forEach(function (r) {
      if (r[1] <= r[0] && now.minutes < r[1]) open = true;
    });
    return open;
  }

  return { DAY_NAMES: DAY_NAMES, parse: parse, show: show, text12: text12, nowIn: nowIn, isOpen: isOpen };
})();

const OD_CATEGORIES = {
  urgent:      { label: "Urgent",           icon: "⚠",  class: "urgent",     items: ["Emergency financial assistance","Medical emergency","Domestic violence support","Suicide & crisis hotlines","Disaster relief","Homeless shelters"] },
  family:      { label: "Family & Household", icon: "\u{1F9CD}", class: "family", items: ["Adoption","Childcare","Parenting classes","Foster care","Support groups","Senior services"] },
  food:        { label: "Food",             icon: "\u{1F374}", class: "food",      items: ["Grocery & meal deliveries","Food pantries","School meals","WIC","SNAP / CalFresh","Community gardens"] },
  health:      { label: "Health",           icon: "➕",  class: "health",     items: ["Dental health","Adult daycare","Mental health","Health insurance","Substance use treatment","Vision care"] },
  housing:     { label: "Housing",          icon: "\u{1F3E0}", class: "housing",   items: ["Housing search","Section 8","Emergency shelter","Rent assistance","Utility assistance","Home repair"] },
  education:   { label: "Education",        icon: "\u{1F393}", class: "education", items: ["Books & supplies","ESL classes","Financial aid","Job & college prep","Preschool & K-12","Tutoring"] },
  legal:       { label: "Legal",            icon: "✍",  class: "legal",      items: ["Debt collection","Declaring bankruptcy","Immigration law","Tenant rights","Family law","Criminal record"] },
  employment:  { label: "Employment",       icon: "\u{1F4BC}", class: "employment", items: ["Job placement support","Apprenticeship","Internships","Job readiness training","Resume help","Career counseling"] },
  money:       { label: "Money",            icon: "$",        class: "money",     items: ["Financial literacy","Banking & credit unions","Tax preparation","Credit counseling","Financial coaching","Benefits enrollment"] }
};

const OD_USER_KEY = "od_user";

function odGetUser() {
  try {
    return JSON.parse(localStorage.getItem(OD_USER_KEY));
  } catch (e) {
    return null;
  }
}

function odSetUser(user) {
  localStorage.setItem(OD_USER_KEY, JSON.stringify(user));
}

function odLogout() {
  localStorage.removeItem(OD_USER_KEY);
  localStorage.removeItem("od_token");
  window.location.href = "index.html";
}

/* ---------- Backend API (FastAPI + PostgreSQL) ---------- */
function odApiPost(path, body) {
  return fetch("/api/" + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  }).then(function (res) {
    return res.json().catch(function () { return {}; }).then(function (data) {
      if (!res.ok) {
        let msg = data.detail;
        if (Array.isArray(msg)) msg = msg.map(function (d) { return d.msg; }).join(", ");
        throw new Error(msg || "Something went wrong. Please try again.");
      }
      return data;
    });
  });
}

function odSaveSession(result) {
  localStorage.setItem("od_token", result.token);
  odSetUser(result.user);
}

/* Both return a promise; the caller redirects on success. */
function odEmailSignUp(profile, password) {
  return odApiPost("signup", {
    first_name: profile.firstName,
    middle_name: profile.middleName,
    last_name: profile.lastName,
    email: profile.email,
    phone: profile.phone,
    password: password
  }); // no session is saved: the user must log in after signing up
}

function odEmailLogIn(email, password) {
  return odApiPost("login", { email: email, password: password }).then(odSaveSession);
}

/* ---------- generic dropdown toggling ---------- */
function odInitDropdowns() {
  document.querySelectorAll("[data-dropdown-toggle]").forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      const dropdown = btn.closest(".dropdown");
      const wasOpen = dropdown.classList.contains("open");
      document.querySelectorAll(".dropdown.open").forEach(function (d) {
        d.classList.remove("open");
      });
      if (!wasOpen) dropdown.classList.add("open");
    });
  });

  document.addEventListener("click", function () {
    document.querySelectorAll(".dropdown.open").forEach(function (d) {
      d.classList.remove("open");
    });
    document.querySelectorAll(".flyout.open").forEach(function (f) {
      f.classList.remove("open");
    });
  });
}

/* ---------- Instant Answers floating widget ---------- */
function odInitInstantAnswers() {
  const btn = document.getElementById("instantAnswersBtn");
  const panel = document.getElementById("instantAnswersPanel");
  if (!btn || !panel) return;
  btn.addEventListener("click", function (e) {
    e.stopPropagation();
    panel.classList.toggle("open");
  });
  document.addEventListener("click", function (e) {
    if (!panel.dataset.sticky && !panel.contains(e.target) && e.target !== btn) {
      panel.classList.remove("open");
    }
  });
}

/* ---------- Browse resources menu (only options that have results near the user) ---------- */
const OD_MENU_KEY = "od_menu_v2";
const OD_MENU_MAX_AGE_MS = 30 * 60 * 1000;

function odMenuLocationKey(loc) {
  return loc.lat.toFixed(2) + "," + loc.lon.toFixed(2);
}

function odSaveMenu(loc, categories, done) {
  try {
    localStorage.setItem(OD_MENU_KEY, JSON.stringify({
      key: odMenuLocationKey(loc), time: Date.now(), done: done, categories: categories
    }));
  } catch (e) { /* storage unavailable: the menu still works, it just is not cached */ }
}

/* Cached menu categories for the current location key (or null). */
function odReadMenu(loc) {
  try {
    const m = JSON.parse(localStorage.getItem(OD_MENU_KEY));
    if (m && (!loc || m.key === odMenuLocationKey(loc)) && Date.now() - m.time < OD_MENU_MAX_AGE_MS) return m;
  } catch (e) { /* ignore a corrupt cache entry */ }
  return null;
}

function odMenuMessage(container, text, retry) {
  container.innerHTML = "";
  const box = document.createElement("div");
  box.className = "menu-status";
  box.textContent = text;
  if (retry) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "menu-retry";
    b.textContent = "Try again";
    b.addEventListener("click", function (e) { e.stopPropagation(); retry(); });
    box.appendChild(b);
  }
  container.appendChild(box);
}

function odBuildBrowseMenu(container, categories, footerText) {
  container.innerHTML = "";
  categories.forEach(function (cat) {
    const fly = document.createElement("div");
    fly.className = "flyout";

    const trigger = document.createElement("div");
    trigger.className = "drop-item has-children";
    const label = document.createElement("span");
    label.textContent = cat.icon + "  " + cat.label;
    trigger.appendChild(label);
    fly.appendChild(trigger);

    function openFlyout() {
      container.querySelectorAll(".flyout.open").forEach(function (f) {
        if (f !== fly) f.classList.remove("open");
      });
      fly.classList.add("open");
    }
    trigger.addEventListener("mouseenter", openFlyout);
    trigger.addEventListener("click", function (e) {  // also works on touch screens
      e.stopPropagation();
      openFlyout();
    });

    const panel = document.createElement("div");
    panel.className = "dropdown-panel small";
    cat.items.forEach(function (item) {
      const a = document.createElement("a");
      a.href = "search.html?cat=" + encodeURIComponent(cat.label) + "&tag=" + encodeURIComponent(item.name);
      a.textContent = item.name;
      panel.appendChild(a);
    });
    fly.appendChild(panel);
    container.appendChild(fly);
  });

  if (footerText) {
    const foot = document.createElement("div");
    foot.className = "menu-status";
    foot.textContent = footerText;
    container.appendChild(foot);
  }
}

/* One shared, location-checked menu state feeds both the "Browse resources" dropdown and the
   "Browse Resources" tab on the home page, so the (slow) availability check only runs once.
   status: idle | loading | partial | done | empty | error */
const odMenuState = { status: "idle", categories: [], progress: 0, message: "", loc: null };
const odMenuListeners = [];

function odSetMenuState(patch) {
  Object.assign(odMenuState, patch);
  odMenuListeners.forEach(function (fn) { fn(odMenuState); });
}

function odSubscribeMenu(fn) {
  odMenuListeners.push(fn);
  fn(odMenuState);
  if (odMenuState.status === "idle") odStartMenuCheck();
}

function odRetryMenu() {
  odMenuState.status = "idle";
  odStartMenuCheck();
}

function odStartMenuCheck() {
  odSetMenuState({ status: "loading", categories: [], progress: 0, message: "" });

  odResolveLocation().then(function (loc) {
    odSetMenuState({ loc: loc });
    const cached = odReadMenu(loc);
    if (cached && cached.done && cached.categories.length) {
      odSetMenuState({ status: "done", categories: cached.categories, progress: 1 });
      return;
    }

    function poll() {
      odApiRequest("GET", "menu?lat=" + loc.lat + "&lng=" + loc.lon).then(function (data) {
        let status = "loading";
        if (data.categories.length) status = data.done ? "done" : "partial";
        else if (data.done) status = data.failed ? "error" : "empty";
        odSetMenuState({
          status: status,
          categories: data.categories,
          progress: data.progress || 0,
          message: data.failed ? "Could not check nearby resources right now."
            : "No resources were found near your location."
        });
        if (data.done) {
          if (!data.failed) odSaveMenu(loc, data.categories, true);
        } else {
          setTimeout(poll, 3000);
        }
      }).catch(function (err) {
        odSetMenuState({ status: "error", message: err.message });
      });
    }
    poll();
  }).catch(function (err) {
    odSetMenuState({ status: "error", message: err.message });
  });
}

function odMenuProgressText(state) {
  return Math.round((state.progress || 0) * 100) + "%";
}

/* ----- dropdown view ----- */
function odLoadBrowseMenu() {
  const container = document.getElementById("browseMenuAuthed");
  if (!container || !odGetUser()) return;

  let lastSignature = "";
  odSubscribeMenu(function (state) {
    const signature = state.status + ":" + state.categories.length;
    if (state.categories.length) {
      // rebuild only when something changed, so an open sub-menu is not closed on every poll
      if (signature === lastSignature) return;
      lastSignature = signature;
      odBuildBrowseMenu(container, state.categories,
        state.status === "partial" ? "Checking for more nearby... " + odMenuProgressText(state) : "");
    } else if (state.status === "error" || state.status === "empty") {
      lastSignature = signature;
      odMenuMessage(container, state.message, state.status === "error" ? odRetryMenu : null);
    } else {
      lastSignature = "";
      odMenuMessage(container, "Checking what is available near you... " + odMenuProgressText(state));
    }
  });
}

/* ----- "Browse Resources" tab view: one box per category, listing its options ----- */
function odLoadBrowseTab() {
  const grid = document.getElementById("browseGrid");
  const status = document.getElementById("browseStatus");
  if (!grid || !status || !odGetUser()) return;

  let lastSignature = "";
  odSubscribeMenu(function (state) {
    status.innerHTML = "";
    const where = state.loc ? " near " + state.loc.label : " near you";

    if (state.status === "error" || state.status === "empty") {
      status.textContent = state.message + " ";
      if (state.status === "error") {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "retry-btn";
        b.textContent = "Try again";
        b.addEventListener("click", odRetryMenu);
        status.appendChild(b);
      }
    } else if (state.status === "done") {
      const n = state.categories.reduce(function (sum, c) { return sum + c.items.length; }, 0);
      status.textContent = "Showing " + n + " resource types available" + where + ".";
    } else {
      status.textContent = "Checking what is available" + where + "... " + odMenuProgressText(state);
    }

    const signature = state.status + ":" + state.categories.length;
    if (signature === lastSignature) return;
    lastSignature = signature;
    grid.innerHTML = "";
    state.categories.forEach(function (cat) {
      const box = document.createElement("div");
      box.className = "dash-card browse-card";

      const title = document.createElement("h3");
      title.textContent = cat.icon + " " + cat.label;
      box.appendChild(title);

      const list = document.createElement("ul");
      list.className = "browse-list";
      cat.items.forEach(function (item) {
        const li = document.createElement("li");
        const a = document.createElement("a");
        a.href = "search.html?cat=" + encodeURIComponent(cat.label) + "&tag=" + encodeURIComponent(item.name);
        a.textContent = item.name;
        li.appendChild(a);
        list.appendChild(li);
      });
      box.appendChild(list);
      grid.appendChild(box);
    });
  });
}

/* ---------- Typed location -> coordinates ----------
   The server looks the place up (free OpenStreetMap / GeoNames data) and fixes spelling mistakes:
   "Hyderbad" -> Hyderabad. Resolves to { lat, lon, label, correctedTo } (correctedTo only if fixed). */
function odGeocode(text) {
  let near = "";
  try {
    const cached = JSON.parse(localStorage.getItem(OD_LOC_KEY));
    if (cached) near = "&near_lat=" + cached.lat + "&near_lng=" + cached.lon;  // prefer places close to the user
  } catch (e) { /* no cached location: fine */ }

  return odApiRequest("GET", "geocode?q=" + encodeURIComponent(text) + near).then(function (r) {
    if (!odInIndiaBox(r.lat, r.lon)) throw new Error("“" + text.trim() + "” is outside India. " + OD_TYPE_INDIA_MESSAGE);
    return { lat: r.lat, lon: r.lon, label: r.label, correctedTo: r.corrected_to || null };
  });
}
/* ---------- Header search box: type a need (and optionally a place), press Find / Enter ---------- */
function odInitHeaderSearch() {
  const input = document.getElementById("headerSearchText");
  const locInput = document.getElementById("searchLocation");
  const button = document.querySelector("#authedHeader .search-btn");
  if (!input || !button) return;

  if (locInput) {
    locInput.addEventListener("input", function () { locInput.dataset.touched = "1"; });
  }

  /* Resolves to a place chosen by the user, or null meaning "use my current location". */
  function chosenPlace() {
    if (!locInput) return Promise.resolve(null);
    const typed = locInput.value.trim();
    const detected = locInput.dataset.detected || "";
    if (!typed || typed === detected) return Promise.resolve(null);
    if (locInput.dataset.manual === "1" && locInput.dataset.geoLabel === typed) {  // already looked up
      return Promise.resolve({ lat: +locInput.dataset.geoLat, lon: +locInput.dataset.geoLon, label: typed });
    }
    return odGeocode(typed);
  }

  let busy = false;
  function go() {
    const text = input.value.trim();
    // On a results page opened from the menu (?cat=Food&tag=Bakeries) an empty search box means
    // "same service, new place": keep the service and only change the location.
    const current = new URLSearchParams(window.location.search);
    const keptTag = current.get("tag");
    if (!text && !keptTag) { input.focus(); return; }
    if (busy) return;
    busy = true;
    button.disabled = true;

    /* A whole sentence ("schools near kondapur for my child") is understood by the server: it returns the
       service to search for and, when the sentence names one, the place. If it cannot be reached or
       understands nothing, the text is searched as typed. */
    const understood = text
      ? odApiRequest("POST", "chat/parse", { message: text }).catch(function () { return null; })
      : Promise.resolve(null);

    understood.then(function (parsed) {
      const query = parsed && parsed.query ? parsed.query : text;
      const sentencePlace = parsed && parsed.place ? parsed.place : "";
      // a place written in the sentence wins over what is in the location box
      const placeLookup = sentencePlace ? odGeocode(sentencePlace) : chosenPlace();
      return placeLookup.then(function (place) { return { place: place, query: query, typedPlace: sentencePlace || (locInput ? locInput.value.trim() : "") }; });
    }).then(function (found) {
      const place = found.place;
      let url = found.query
        ? "search.html?q=" + encodeURIComponent(found.query)
        : "search.html?cat=" + encodeURIComponent(current.get("cat") || "") + "&tag=" + encodeURIComponent(keptTag);
      if (place) {
        url += "&lat=" + place.lat + "&lng=" + place.lon + "&place=" + encodeURIComponent(place.label);
        if (place.correctedTo) url += "&fixed=" + encodeURIComponent(found.typedPlace);
      }
      window.location.href = url;  // without a place, the results page uses the current location
    }).catch(function (err) {
      odShowToast(err.message, true);
      if (locInput) locInput.focus();
      busy = false;
      button.disabled = false;
    });
  }
  button.addEventListener("click", go);
  [input, locInput].forEach(function (field) {
    if (!field) return;
    field.addEventListener("keydown", function (e) {
      if (e.key === "Enter") { e.preventDefault(); go(); }
    });
  });
}
/* ---------- Ratings, the heart (save to My Plan) and resource helpers ---------- */
const OD_HEART_SVG = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" stroke-width="2" stroke-linejoin="round"/></svg>';

/* "★★★★☆" for an average rating */
function odStars(avg) {
  const full = Math.max(0, Math.min(5, Math.round(avg || 0)));
  return "\u2605".repeat(full) + "\u2606".repeat(5 - full);
}

/* Small "★★★★☆ 4.5 (2 ratings)" element, or "No ratings yet". */
function odRatingElement(avg, count) {
  const wrap = document.createElement("span");
  wrap.className = "rating-line";
  if (!count) {
    wrap.textContent = "No ratings yet";
    wrap.classList.add("none");
    return wrap;
  }
  const stars = document.createElement("span");
  stars.className = "stars";
  stars.textContent = odStars(avg);
  wrap.appendChild(stars);
  wrap.appendChild(document.createTextNode(" " + Number(avg).toFixed(1) + " (" + count + (count === 1 ? " rating)" : " ratings)")));
  return wrap;
}

/* The details page opens instantly with what the results list already knows. */
function odStoreSnapshot(resource) {
  try { sessionStorage.setItem("od_res_" + resource.id, JSON.stringify(resource)); } catch (e) { /* ignore */ }
}

function odDetailsUrl(id) {
  return "resource.html?id=" + encodeURIComponent(id);
}

function odSavePayload(r) {
  return {
    resource_id: r.id, name: r.name, category: r.category || null, service: r.service || null,
    address: r.address || null, lat: r.lat == null ? null : r.lat, lng: r.lng == null ? null : r.lng,
    phone: r.phone || null, email: r.email || null, website: r.website || null,
    opening_hours: r.opening_hours || null, source: r.source || null
  };
}

/* A heart button that saves the resource to My Plan (and removes it again on the next click). */
function odMakeHeart(resource, initiallySaved, onChange) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "heart-btn";
  btn.innerHTML = OD_HEART_SVG;
  let saved = !!initiallySaved;

  function paint() {
    btn.classList.toggle("saved", saved);
    btn.setAttribute("aria-pressed", String(saved));
    btn.title = saved ? "Saved to My Plan - click to remove" : "Save to My Plan";
    btn.setAttribute("aria-label", btn.title);
  }
  paint();

  btn.addEventListener("click", function (e) {
    e.preventDefault();
    e.stopPropagation();
    if (btn.disabled) return;
    btn.disabled = true;
    const want = !saved;
    const request = want
      ? odApiRequest("POST", "plan", odSavePayload(resource))
      : odApiRequest("DELETE", "plan?id=" + encodeURIComponent(resource.id));
    request.then(function () {
      saved = want;
      resource.saved = want;
      paint();
      odShowToast(want ? "Saved to My Plan." : "Removed from My Plan.");
      if (onChange) onChange(saved);
    }).catch(function (err) {
      odShowToast(err.message, true);
    }).then(function () { btn.disabled = false; });
  });

  btn.setSaved = function (value) { saved = !!value; paint(); };
  return btn;
}

/* ---------- My Plan tab: everything the user saved with the heart ---------- */
function odLoadPlanTab() {
  const list = document.getElementById("planList");
  const status = document.getElementById("planStatus");
  if (!list || !status || !odGetUser()) return;

  status.textContent = "Loading your saved resources...";
  list.innerHTML = "";

  odApiRequest("GET", "plan").then(function (data) {
    const items = data.items || [];
    if (!items.length) {
      status.textContent = "Your plan is empty. Tap the heart on any result to save it here.";
      return;
    }
    function updateCount() {
      const n = list.children.length;
      status.textContent = n ? n + " saved resource" + (n === 1 ? "" : "s") + "." :
        "Your plan is empty. Tap the heart on any result to save it here.";
    }
    items.forEach(function (item) {
      const card = document.createElement("article");
      card.className = "dash-card plan-card";

      const title = document.createElement("h3");
      const link = document.createElement("a");
      link.href = odDetailsUrl(item.id);
      link.textContent = item.name;
      link.addEventListener("click", function () { odStoreSnapshot(item); });
      title.appendChild(link);
      card.appendChild(title);

      const tags = document.createElement("div");
      tags.className = "rc-tags";
      [item.category, item.service].forEach(function (text, i) {
        if (!text) return;
        const tag = document.createElement("span");
        tag.className = "tag" + (i ? " alt" : "");
        tag.textContent = text;
        tags.appendChild(tag);
      });
      card.appendChild(tags);

      [["\u{1F4CD} ", item.address || "Address not listed"], ["\u260E ", item.phone]].forEach(function (row) {
        if (!row[1]) return;
        const p = document.createElement("p");
        p.className = "plan-line";
        p.textContent = row[0] + row[1];
        card.appendChild(p);
      });

      const actions = document.createElement("div");
      actions.className = "rc-actions";
      const view = document.createElement("a");
      view.className = "rc-btn primary";
      view.href = odDetailsUrl(item.id);
      view.textContent = "View details";
      view.addEventListener("click", function () { odStoreSnapshot(item); });
      actions.appendChild(view);
      actions.appendChild(odMakeHeart(item, true, function (saved) {
        if (!saved) { card.remove(); updateCount(); }  // removed from the plan: it leaves the list
      }));
      card.appendChild(actions);

      const rating = document.createElement("div");
      rating.className = "rc-rating";
      rating.appendChild(odRatingElement(item.rating, item.rating_count));
      card.appendChild(rating);

      list.appendChild(card);
    });
    updateCount();
  }).catch(function (err) {
    status.textContent = err.message + " ";
    const b = document.createElement("button");
    b.type = "button";
    b.className = "retry-btn";
    b.textContent = "Try again";
    b.addEventListener("click", odLoadPlanTab);
    status.appendChild(b);
  });
}

/* ---------- Home page tabs: Home | Browse Resources | My Plan ---------- */
function odInitTabs() {
  const tabs = document.querySelectorAll(".tabs [data-tab]");
  const panels = {
    home: document.getElementById("tabHome"),
    browse: document.getElementById("tabBrowse"),
    plan: document.getElementById("tabPlan")
  };
  if (!tabs.length || !panels.home || !panels.browse) return;

  function fromHash() {
    const name = window.location.hash.replace("#", "");
    return panels[name] ? name : "home";
  }

  function show(name) {
    if (!panels[name]) name = "home";
    Object.keys(panels).forEach(function (k) { if (panels[k]) panels[k].style.display = k === name ? "block" : "none"; });
    tabs.forEach(function (t) { t.classList.toggle("active", t.dataset.tab === name); });
    if (name === "browse") odLoadBrowseTab();
    if (name === "plan") odLoadPlanTab();
  }

  tabs.forEach(function (t) {
    t.addEventListener("click", function (e) {
      e.preventDefault();
      history.replaceState(null, "", t.dataset.tab === "home" ? window.location.pathname : "#" + t.dataset.tab);
      show(t.dataset.tab);
    });
  });
  document.querySelectorAll("[data-open-tab]").forEach(function (l) {
    l.addEventListener("click", function (e) { e.preventDefault(); show(l.dataset.openTab); });
  });
  window.addEventListener("hashchange", function () {  // e.g. the header's Menu > My Plan link
    show(fromHash());
  });
  show(fromHash());
}
/* ---------- Hero category tiles ---------- */
function odBuildCategoryTiles(container, inCategoryEl, defaultKey) {
  if (!container) return;
  Object.keys(OD_CATEGORIES).forEach(function (key) {
    const cat = OD_CATEGORIES[key];
    const btn = document.createElement("button");
    btn.className = "category-tile " + cat.class + (key === defaultKey ? " active" : "");
    btn.dataset.key = key;
    btn.innerHTML = '<span class="icon">' + cat.icon + "</span><span>" + cat.label + "</span>";
    btn.addEventListener("click", function () {
      container.querySelectorAll(".category-tile").forEach(function (t) {
        t.classList.remove("active");
      });
      btn.classList.add("active");
      odRenderInCategory(inCategoryEl, key);
    });
    container.appendChild(btn);
  });
  if (defaultKey) odRenderInCategory(inCategoryEl, defaultKey);
}

function odRenderInCategory(el, key) {
  if (!el) return;
  const cat = OD_CATEGORIES[key];
  const shown = cat.items.slice(0, 4);
  const remaining = cat.items.length - shown.length;
  let html = "<b>In this category:</b> ";
  html += shown.map(function (i) { return '<a href="#">' + i + "</a>"; }).join('<span class="sep">|</span>');
  if (remaining > 0) {
    html += '<span class="sep">|</span><a href="#">And ' + remaining + " more...</a>";
  }
  el.innerHTML = html;
}

/* ---------- Explore resources grid ---------- */
function odBuildExploreGrid(container) {
  if (!container) return;
  Object.keys(OD_CATEGORIES).forEach(function (key) {
    const cat = OD_CATEGORIES[key];
    const card = document.createElement("div");
    card.className = "explore-card";
    const shown = cat.items.slice(0, 2);
    card.innerHTML =
      "<h3>" + cat.icon + " " + cat.label + "</h3>" +
      shown.map(function (i) { return '<a href="#">' + i + "</a>"; }).join("") +
      '<a href="#">See more...</a>';
    container.appendChild(card);
  });
}

/* ---------- Header rendering based on auth state ---------- */
function odRenderHeader() {
  const user = odGetUser();
  const publicHeader = document.getElementById("publicHeader");
  const authedHeader = document.getElementById("authedHeader");
  const guestHome = document.getElementById("guestHome");
  const memberHome = document.getElementById("memberHome");

  if (user) {
    if (publicHeader) publicHeader.style.display = "none";
    if (authedHeader) authedHeader.style.display = "block";
    if (guestHome) guestHome.style.display = "none";
    if (memberHome) memberHome.style.display = "block";

    const nameEl = document.getElementById("userFirstName");
    if (nameEl) nameEl.textContent = user.name;
    const accountNameEl = document.getElementById("accountName");
    if (accountNameEl) accountNameEl.textContent = user.name;
  } else {
    if (publicHeader) publicHeader.style.display = "block";
    if (authedHeader) authedHeader.style.display = "none";
    if (guestHome) guestHome.style.display = "block";
    if (memberHome) memberHome.style.display = "none";
  }
}

/* ---------- Current location (browser geolocation + OpenStreetMap Nominatim reverse geocode) ---------- */
const OD_LOC_KEY = "od_location";
const OD_LOC_MAX_AGE_MS = 2 * 60 * 1000;  // short, so the location follows the user when they move

/* ---------- Place names for coordinates, and coordinates for place names ----------
   Free, key-less services are tried in turn because each one can rate-limit or be down. */
function odJson(url) {
  return fetch(url, { headers: { "Accept": "application/json" } }).then(function (r) {
    if (!r.ok) throw new Error("HTTP " + r.status);
    return r.json();
  });
}

function odJoinLabel(parts) {
  return parts.filter(Boolean).join(", ");
}

/* This service covers India only. A box around India rules out most of the world; the country from the reverse
   geocoder decides the rest (the box also holds parts of Pakistan, Nepal, Bangladesh, Sri Lanka...). */
const OD_INDIA_BOX = { minLat: 6.0, maxLat: 37.6, minLon: 68.0, maxLon: 97.6 };
const OD_OUTSIDE_INDIA_MESSAGE = "Your current location is outside India. Please type a place in India in the search box.";
const OD_TYPE_INDIA_MESSAGE = "Please type a place in India.";
function odInIndiaBox(lat, lon) {
  return lat >= OD_INDIA_BOX.minLat && lat <= OD_INDIA_BOX.maxLat && lon >= OD_INDIA_BOX.minLon && lon <= OD_INDIA_BOX.maxLon;
}
function odIsIndia(lat, lon, countryCode) {
  if (!odInIndiaBox(lat, lon)) return false;
  return countryCode ? String(countryCode).toUpperCase() === "IN" : true;   // no country known: the box decides
}

/* Resolves to { label, country } - a place name like "Hyderabad, Telangana, IN" and its country code - or
   { label: "", country: "" } if every service failed. */
function odReverseGeocode(lat, lon) {
  const services = [
    function () {  // OpenStreetMap Nominatim
      return odJson("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10&lat=" + lat + "&lon=" + lon)
        .then(function (data) {
          const a = data.address || {};
          return { label: odJoinLabel([a.city || a.town || a.village || a.county || a.suburb,
                              a.state, a.country_code && a.country_code.toUpperCase()]),
                   country: (a.country_code || "").toUpperCase() };
        });
    },
    function () {  // BigDataCloud (free client-side reverse geocoding)
      return odJson("https://api.bigdatacloud.net/data/reverse-geocode-client?localityLanguage=en&latitude=" +
        lat + "&longitude=" + lon).then(function (d) {
          return { label: odJoinLabel([d.city || d.locality, d.principalSubdivision, d.countryCode]),
                   country: (d.countryCode || "").toUpperCase() };
        });
    },
    function () {  // Photon (OpenStreetMap data)
      return odJson("https://photon.komoot.io/reverse?lat=" + lat + "&lon=" + lon).then(function (d) {
        const p = (d.features && d.features[0] && d.features[0].properties) || {};
        return { label: odJoinLabel([p.city || p.name || p.district, p.state, p.countrycode]),
                 country: (p.countrycode || "").toUpperCase() };
      });
    }
  ];
  const none = { label: "", country: "" };
  return services.reduce(function (chain, service) {
    return chain.then(function (found) {
      return found.label ? found : service().catch(function () { return none; });
    });
  }, Promise.resolve(none));
}

/* Resolves to { lat, lon, label }. Reuses a recent result to avoid repeat lookups. */
function odResolveLocation() {
  try {
    const cached = JSON.parse(localStorage.getItem(OD_LOC_KEY));
    if (cached && Date.now() - cached.time < OD_LOC_MAX_AGE_MS && odInIndiaBox(cached.lat, cached.lon)) return Promise.resolve(cached);
  } catch (e) { /* ignore a corrupt cache entry */ }

  return new Promise(function (resolve, reject) {
    if (!navigator.geolocation) {
      reject(new Error("Location not supported by this browser"));
      return;
    }
    navigator.geolocation.getCurrentPosition(function (pos) {
      const lat = pos.coords.latitude;
      const lon = pos.coords.longitude;
      const coords = lat.toFixed(4) + ", " + lon.toFixed(4);
      odReverseGeocode(lat, lon).then(function (found) {
        if (!odIsIndia(lat, lon, found.country)) {   // India only: ask the person to type a place in India instead
          try { localStorage.removeItem(OD_LOC_KEY); } catch (e) { /* ignore */ }
          const outside = new Error(OD_OUTSIDE_INDIA_MESSAGE);
          outside.code = "OUTSIDE_INDIA";
          reject(outside);
          return;
        }
        const label = found.label;
        const named = !!label;
        const loc = { lat: lat, lon: lon, label: label || coords, time: Date.now() };
        // a coordinates-only label is not cached, so the next call tries to look the name up again
        if (named) {
          try { localStorage.setItem(OD_LOC_KEY, JSON.stringify(loc)); } catch (e) { /* ignore */ }
        }
        resolve(loc);
      });
    }, function (err) {
      reject(new Error(err.code === 1
        ? "Location permission denied - please allow location access"
        : "Unable to detect your location"));
    }, { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 });
  });
}

/* Fills the home-page location box and the logged-in search bar's location field. */
function odInitCurrentLocation() {
  const box = document.getElementById("currentLocation");
  const input = document.getElementById("searchLocation");
  if (!box && !input) return;

  // A place the person typed on the search page stays in the search box on the pages opened from there (a result's
  // details page, for example) instead of going back to the current location.
  let manual = null;
  try { manual = JSON.parse(sessionStorage.getItem("od_manual_place")); } catch (e) { /* none remembered */ }
  if (manual && input && manual.label && isFinite(manual.lat) && isFinite(manual.lon) && odInIndiaBox(manual.lat, manual.lon)) {
    input.value = manual.label;
    input.dataset.manual = "1";
    input.dataset.geoLabel = manual.label;
    input.dataset.geoLat = manual.lat;
    input.dataset.geoLon = manual.lon;
    if (box) box.textContent = "\u{1F4CD} " + manual.label;
    return;
  }

  odResolveLocation().then(function (loc) {
    if (box) box.textContent = "\u{1F4CD} " + loc.label;
    if (input) {
      input.dataset.detected = loc.label;
      if (input.dataset.manual !== "1" && input.dataset.touched !== "1") input.value = loc.label;
    }
  }).catch(function (err) {
    if (box) box.textContent = err.message;
    if (input) {
      input.placeholder = err.code === "OUTSIDE_INDIA" ? OD_TYPE_INDIA_MESSAGE : err.message;
      if (err.code === "OUTSIDE_INDIA") {
        input.value = "";
        input.dataset.detected = "";
        odShowToast(err.message, true);
        input.focus();
      }
    }
  });
}
/* ---------- Guest front page: any interaction redirects to login ---------- */
function odInitGuestRedirect() {
  if (odGetUser() || !document.getElementById("guestHome")) return;
  document.addEventListener("click", function (e) {
    const target = e.target.closest("a, button, input, .explore-card, .category-tile");
    if (!target) return;
    if (target.closest('a[href="signup.html"], a[href="login.html"]')) return;
    e.preventDefault();
    e.stopPropagation();
    window.location.href = "login.html";
  }, true);
}

/* ---------- Profile popup (view/update account details) ---------- */
function odApiRequest(method, path, body) {
  return fetch("/api/" + path, {
    method: method,
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + (localStorage.getItem("od_token") || "")
    },
    body: body ? JSON.stringify(body) : undefined
  }).then(function (res) {
    return res.json().catch(function () { return {}; }).then(function (data) {
      if (res.status === 401) {
        odLogout();
        throw new Error("Session expired. Please log in again.");
      }
      if (!res.ok) {
        let msg = data.detail;
        if (Array.isArray(msg)) msg = msg.map(function (d) { return d.msg; }).join(", ");
        throw new Error(msg || "Something went wrong. Please try again.");
      }
      return data;
    });
  });
}

/* ---------- Success message (auto-hides, closable with x) ---------- */
let odToastTimer = null;

function odShowToast(message, isError) {
  const toast = document.getElementById("toast");
  const text = document.getElementById("toastText");
  if (!toast || !text) return;
  toast.classList.toggle("toast-error", !!isError);
  text.textContent = message;
  toast.style.display = "block";
  clearTimeout(odToastTimer);
  odToastTimer = setTimeout(odHideToast, 5000);
}

function odHideToast() {
  const toast = document.getElementById("toast");
  if (toast) toast.style.display = "none";
}

function odInitProfileModal() {
  const toastClose = document.getElementById("toastClose");
  if (toastClose) toastClose.addEventListener("click", odHideToast);

  const link = document.getElementById("profileLink");
  const modal = document.getElementById("profileModal");
  if (!link || !modal) return;

  const $ = function (id) { return document.getElementById(id); };
  const errorEl = $("profileError");
  const okEl = $("profileSuccess");

  function fill(u) {
    $("profFirst").value = u.firstName || "";
    $("profMiddle").value = u.middleName || "";
    $("profLast").value = u.lastName || "";
    $("profEmail").value = u.email || "";
    $("profPhone").value = u.phone || "";
    $("profCurrentPw").value = "";
    $("profNewPw").value = "";
    $("profNewPw2").value = "";
  }

  function close() { modal.style.display = "none"; }

  link.addEventListener("click", function (e) {
    e.preventDefault();
    errorEl.textContent = "";
    okEl.textContent = "";
    fill(odGetUser() || {});
    modal.style.display = "flex";
    // refresh from the database so the form shows the latest saved values
    odApiRequest("GET", "profile").then(function (data) {
      odSetUser(data.user);
      fill(data.user);
    }).catch(function () {});
  });

  $("profileClose").addEventListener("click", close);
  modal.addEventListener("mousedown", function (e) { if (e.target === modal) close(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });

  $("profileForm").addEventListener("submit", function (e) {
    e.preventDefault();
    errorEl.textContent = "";
    okEl.textContent = "";

    const newPw = $("profNewPw").value;
    if (newPw || $("profNewPw2").value) {
      if (newPw !== $("profNewPw2").value) {
        errorEl.textContent = "New passwords do not match.";
        return;
      }
      if (!$("profCurrentPw").value) {
        errorEl.textContent = "Enter your current password to set a new one.";
        return;
      }
    }

    odApiRequest("PUT", "profile", {
      first_name: $("profFirst").value.trim(),
      middle_name: $("profMiddle").value.trim(),
      last_name: $("profLast").value.trim(),
      phone: $("profPhone").value.trim(),
      current_password: $("profCurrentPw").value || null,
      new_password: newPw || null
    }).then(function (data) {
      odSetUser(data.user);
      fill(data.user);
      close();
      odShowToast("Profile changed successfully.");
      const nameEl = document.getElementById("userFirstName");
      if (nameEl) nameEl.textContent = data.user.name;
    }).catch(function (err) {
      errorEl.textContent = err.message;
    });
  });
}

/* Re-check login state whenever a page is shown, including restores from the
   back/forward cache, so the header always matches the current login state. */
window.addEventListener("pageshow", function (e) {
  if (e.persisted) {
    window.location.reload();
    return;
  }
  odRedirectIfLoggedInOnAuthPage();
});

/* A logged-in user has no reason to see the login/signup forms. */
function odRedirectIfLoggedInOnAuthPage() {
  const onAuthPage = document.getElementById("loginForm") || document.getElementById("signupForm");
  if (onAuthPage && odGetUser()) window.location.replace("index.html");
}

document.addEventListener("DOMContentLoaded", function () {
  odInitGuestRedirect();
  odInitProfileModal();
  odInitCurrentLocation();
  odRenderHeader();
  odInitDropdowns();
  odInitInstantAnswers();

  odLoadBrowseMenu();
  odInitHeaderSearch();
  odInitTabs();

  const tiles = document.getElementById("categoryTiles");
  const inCategory = document.getElementById("inCategoryLine");
  odBuildCategoryTiles(tiles, inCategory, "employment");

  const exploreGrid = document.getElementById("exploreGrid");
  odBuildExploreGrid(exploreGrid);

  const logoutLink = document.getElementById("logoutLink");
  if (logoutLink) {
    logoutLink.addEventListener("click", function (e) {
      e.preventDefault();
      odLogout();
    });
  }
});
