/* Home-page chat: the person describes what they need ("hi i am looking for some schools near kondapur"),
   the server works out the service and the place, and the search results page opens for it.
   Loaded by index.html only. */
(function () {
  const form = document.getElementById("chatForm");
  const input = document.getElementById("chatInput");
  const log = document.getElementById("chatLog");
  const sendBtn = document.getElementById("chatSend");
  if (!form || !input || !log || typeof odGetUser !== "function" || !odGetUser()) return;

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  function add(kind, text) {
    const m = el("div", "hc-msg " + kind, text);
    log.appendChild(m);
    log.scrollTop = log.scrollHeight;
    return m;
  }

  function handle(message) {
    add("user", message);
    const status = add("bot", "Understanding your request...");
    let parsed;
    let opening = false;

    odApiRequest("POST", "chat/parse", { message: message }).then(function (p) {
      parsed = p;
      if (!parsed.query) {
        throw new Error("I couldn’t tell what service you need. Try something like “schools near Kondapur” or “clinic near me”.");
      }
      status.textContent = "Looking for " + parsed.query.toLowerCase() + (parsed.place ? " near " + parsed.place : " near you") + "...";
      // a place named in the message is looked up; otherwise the results page uses the current location
      return parsed.place ? odGeocode(parsed.place) : null;
    }).then(function (place) {
      let url = "search.html?q=" + encodeURIComponent(parsed.query);
      if (place) {
        url += "&lat=" + place.lat + "&lng=" + place.lon + "&place=" + encodeURIComponent(place.label);
        if (place.correctedTo) url += "&fixed=" + encodeURIComponent(parsed.place);
      }
      status.textContent = "Opening results for " + parsed.query.toLowerCase() + " near " + (place ? place.label : "you") + "...";
      opening = true;
      window.location.href = url;
    }).catch(function (err) {
      status.textContent = err.message || "Something went wrong. Please try again.";
    }).then(function () {
      if (opening) return;   // the page is changing: keep the button off
      sendBtn.disabled = false;
      input.focus();
    });
  }

  const panel = document.getElementById("instantAnswersPanel");
  const closeBtn = document.getElementById("chatClose");
  if (panel) panel.classList.add("open");   // the chat window is open when the home page loads
  if (closeBtn) closeBtn.addEventListener("click", function () { panel.classList.remove("open"); });

  add("bot", "Hi " + (odGetUser().name || "there") + "! \u{1F44B} How can I help you today?");

  /* the box grows with what is typed (up to its max height, then it scrolls) */
  function grow() {
    input.style.height = "40px";
    input.style.height = Math.min(input.scrollHeight, 150) + "px";
  }
  input.addEventListener("input", grow);
  input.addEventListener("keydown", function (e) {   // Enter sends, Shift+Enter starts a new line
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); }
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    const message = input.value.trim();
    if (!message || sendBtn.disabled) return;
    input.value = "";
    grow();
    sendBtn.disabled = true;
    handle(message);
  });
})();
