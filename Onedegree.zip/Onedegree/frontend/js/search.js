/* Search results page: reads ?cat=&tag=, uses the user's current location,
   asks the backend (OpenStreetMap / Overpass) and shows cards + a map. */
(function () {
  const params = new URLSearchParams(window.location.search);
  let category = params.get("cat") || "";
  let option = params.get("tag") || "";
  const typed = (params.get("q") || "").trim();  // text typed in the header search box

  /* A place typed by the user (looked up on the previous page) replaces the current location. */
  const urlLat = parseFloat(params.get("lat"));
  const urlLng = parseFloat(params.get("lng"));
  const urlPlace = (params.get("place") || "").trim();
  const manualLoc = (isFinite(urlLat) && isFinite(urlLng) && Math.abs(urlLat) <= 90 &&
                     Math.abs(urlLng) <= 180 && urlPlace)
    ? { lat: urlLat, lon: urlLng, label: urlPlace } : null;
  const locationParams = manualLoc
    ? "&lat=" + manualLoc.lat + "&lng=" + manualLoc.lon + "&place=" + encodeURIComponent(manualLoc.label) : "";

  // remember the typed place for the pages opened from here (a result's details page shows it in its search box too);
  // a search that used the current location forgets it again
  try {
    if (manualLoc) sessionStorage.setItem("od_manual_place", JSON.stringify(manualLoc));
    else sessionStorage.removeItem("od_manual_place");
  } catch (e) { /* storage blocked: the place is simply not remembered */ }

  const locBox = document.getElementById("searchLocation");
  if (manualLoc && locBox) {  // show the chosen place in the header box, marked so it is not overwritten
    locBox.value = manualLoc.label;
    locBox.dataset.manual = "1";
    locBox.dataset.geoLabel = manualLoc.label;
    locBox.dataset.geoLat = manualLoc.lat;
    locBox.dataset.geoLon = manualLoc.lon;
  }

  const $ = function (id) { return document.getElementById(id); };
  const listEl = $("resultsList");
  const statusEl = $("searchStatus");

  let map = null;
  let markerLayer = null;
  const markersById = {};

  /* ----- guard: must be logged in ----- */
  if (!odGetUser()) {
    window.location.replace("login.html");
    return;
  }

  $("backBtn").addEventListener("click", function (e) {   // works like the browser's Back button
    if (window.history.length > 1) { e.preventDefault(); window.history.back(); }
  });
  $("searchTitle").textContent = typed ? "Results for “" + typed + "”" : (option ? option : "Search resources");
  if (typed && $("headerSearchText")) $("headerSearchText").value = typed;

  /* ----- helpers (all text is set with textContent: OSM data is untrusted) ----- */
  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  function safeUrl(u) {
    if (!u) return "";
    const withProto = /^https?:\/\//i.test(u) ? u : "https://" + u;
    try {
      const parsed = new URL(withProto);
      return (parsed.protocol === "http:" || parsed.protocol === "https:") ? parsed.href : "";
    } catch (e) { return ""; }
  }

  function showStatus(message, retry) {
    statusEl.innerHTML = "";
    if (!message) return;
    statusEl.appendChild(el("p", "", message));
    if (retry) {
      const b = el("button", "retry-btn", "Try again");
      b.type = "button";
      b.addEventListener("click", retry);
      statusEl.appendChild(b);
    }
  }

  /* ----- sibling options in the same category ----- */
  function renderChips(state) {
    const chips = $("siblingChips");
    chips.innerHTML = "";
    if (manualLoc) return;  // the menu was checked for the user's current location, not this place
    const cats = (state && state.categories) || [];
    const cat = cats.filter(function (c) { return c.label === category; })[0];
    if (!cat) return;
    cat.items.forEach(function (it) {
      const item = it.name;
      const a = el("a", "chip" + (item === option ? " active" : ""), item);
      a.href = "search.html?cat=" + encodeURIComponent(category) + "&tag=" + encodeURIComponent(item) + locationParams;
      chips.appendChild(a);
    });
  }

  /* ----- map ----- */
  /* Drop any typed place and search again around where the user really is now. */
  function useCurrentLocation() {
    try { localStorage.removeItem(OD_LOC_KEY); } catch (e) { /* ignore */ }  // force a fresh location lookup
    const next = new URLSearchParams(window.location.search);
    ["lat", "lng", "place", "fixed", "page"].forEach(function (k) { next.delete(k); });
    const query = next.toString();
    window.location.href = "search.html" + (query ? "?" + query : "");
  }

  function initMap(loc) {
    if (typeof L === "undefined") return;
    map = L.map("map").setView([loc.lat, loc.lon], 13);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: "&copy; OpenStreetMap contributors"
    }).addTo(map);
    markerLayer = L.layerGroup().addTo(map);
    // "Use my current location" button under the zoom buttons
    const LocateControl = L.Control.extend({
      options: { position: "topleft" },
      onAdd: function () {
        const bar = L.DomUtil.create("div", "leaflet-bar leaflet-control");
        const a = L.DomUtil.create("a", "map-locate", bar);
        a.href = "#";
        a.title = "Use my current location";
        a.setAttribute("role", "button");
        a.setAttribute("aria-label", "Use my current location");
        a.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">' +
          '<circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/>' +
          '<path d="M12 2v4M12 18v4M2 12h4M18 12h4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
        L.DomEvent.disableClickPropagation(bar);
        L.DomEvent.on(a, "click", function (e) {
          L.DomEvent.preventDefault(e);
          useCurrentLocation();
        });
        return bar;
      }
    });
    map.addControl(new LocateControl());

    // blue = your current location, orange = a place you typed
    const colour = manualLoc ? "#e8710a" : "#1a73e8";
    L.circleMarker([loc.lat, loc.lon], {
      radius: 8, color: colour, fillColor: colour, fillOpacity: 0.9
    }).addTo(map).bindTooltip(manualLoc ? "Searching here: " + loc.label : "You are here");
  }

  function highlight(id) {
    document.querySelectorAll(".result-card.active").forEach(function (c) { c.classList.remove("active"); });
    const card = document.querySelector('.result-card[data-id="' + id + '"]');
    if (card) {
      card.classList.add("active");
      card.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  }

  /* Today's hours in 12-hour time, by the clock of the searched area (the places are all near it). */
  let searchZone = "";
  function hoursToday(raw) {
    const days = OdHours.parse(raw);
    if (!days) return OdHours.text12(raw);
    const now = OdHours.nowIn(searchZone);
    const today = days[now.day];
    if (!today) return OdHours.text12(raw);
    return OdHours.DAY_NAMES[now.day].slice(0, 3) + ": " + OdHours.show(today) +
      (searchZone && days.every(function (d) { return d; }) ? (OdHours.isOpen(days, now) ? " · Open now" : " · Closed now") : "");
  }

  /* ----- result card ----- */
  function renderCard(r, index) {
    const card = el("article", "result-card");
    card.dataset.id = r.id;

    const head = el("div", "rc-head");
    head.appendChild(el("span", "rc-num", String(index + 1)));
    head.appendChild(el("h3", "rc-name", r.name));
    card.appendChild(head);

    const tags = el("div", "rc-tags");
    tags.appendChild(el("span", "tag", r.category || "Resource"));
    tags.appendChild(el("span", "tag alt", r.service));
    tags.appendChild(el("span", "rc-dist", r.distance_km + " km away"));
    card.appendChild(tags);

    if (r.description) card.appendChild(el("p", "rc-desc", r.description));

    const info = el("ul", "rc-info");
    info.appendChild(el("li", "addr-line", "\u{1F4CD} " + (r.address || "Address not listed")));
    if (r.opening_hours) info.appendChild(el("li", "", "\u{1F552} " + hoursToday(r.opening_hours)));
    if (r.phone) info.appendChild(el("li", "", "\u{260E} " + r.phone));
    if (safeUrl(r.website)) {  // shown only once the site has been checked (see checkWebsites below)
      const li = el("li", "site-line muted", "\u{1F310} Checking website...");
      info.appendChild(li);
    } else {   // OpenStreetMap has no website: the web search looks for it (see checkWebsites below)
      info.appendChild(el("li", "site-line muted", "\u{1F310} Looking for website..."));
    }
    if (r.email) info.appendChild(el("li", "", "\u{2709} " + r.email));
    card.appendChild(info);

    const actions = el("div", "rc-actions");
    const view = el("a", "rc-btn primary", "View details");
    view.href = odDetailsUrl(r.id);
    view.addEventListener("click", function () {
      odStoreSnapshot(r);
      try { sessionStorage.setItem("od_back", window.location.pathname.split("/").pop() + window.location.search); } catch (e) { /* ignore */ }
    });  // the details page opens instantly
    actions.appendChild(view);  // the only button: phone, website and the rest are on the details page
    actions.appendChild(odMakeHeart(r, r.saved));  // save to My Plan
    card.appendChild(actions);

    card.appendChild(el("div", "rc-source", "Source: " + r.source));

    card.addEventListener("click", function (e) {
      if (e.target.closest("a, button")) return;
      highlight(r.id);
      const m = markersById[r.id];
      if (m && map) { map.setView(m.getLatLng(), Math.max(map.getZoom(), 15)); m.openPopup(); }
    });
    return card;
  }

  function addMarker(r, index) {
    if (!map) return;
    const m = L.circleMarker([r.lat, r.lng], {
      radius: 9, color: "#0f5f6b", fillColor: "#2a8f9d", fillOpacity: 0.9, weight: 2
    }).addTo(markerLayer);
    const pop = el("div", "");
    pop.appendChild(el("strong", "", (index + 1) + ". " + r.name));
    pop.appendChild(el("div", "", r.address || "Address not listed"));
    m.bindPopup(pop);
    m.on("click", function () { highlight(r.id); });
    markersById[r.id] = m;
  }

  /* ----- run the search ----- */
  function run() {
    listEl.innerHTML = "";
    showStatus("Finding your location...");
    let loc;

    (manualLoc ? Promise.resolve(manualLoc) : odResolveLocation()).then(function (l) {
      loc = l;
      if (!map) initMap(loc);
      $("searchMeta").textContent = (manualLoc ? "Around the place you typed: " : "Near your current location: ") + loc.label;
      showStatus("Searching OpenStreetMap for " + (typed || option) +
        (manualLoc ? " around " + loc.label : " near you") + "... this can take up to a minute.");
      const q = (typed ? "search?q=" + encodeURIComponent(typed)
                       : "search?option=" + encodeURIComponent(option) + "&category=" + encodeURIComponent(category)) +
        "&lat=" + loc.lat + "&lng=" + loc.lon;
      return Promise.all([odApiRequest("GET", q),
        odApiRequest("GET", "timezone?lat=" + loc.lat + "&lng=" + loc.lon).catch(function () { return null; })]);
    }).then(function (both) {
      const data = both && both[0];
      searchZone = (both && both[1] && both[1].timezone) || "";
      if (!data) return;
      showStatus("");
      if (typed && data.matched_option) {  // what was typed maps to a known service: show its details
        option = data.matched_option;
        category = data.category;
        renderChips(odMenuState);
      }
      // tell the user when a spelling mistake was corrected
      const notes = [];
      if (params.get("fixed") && manualLoc) {
        notes.push("Showing results for “" + manualLoc.label + "” (you typed “" + params.get("fixed") + "”).");
      }
      if (typed && data.corrected_to) {
        notes.push("Showing results for “" + data.corrected_to + "” instead of “" + typed + "”.");
      }
      const noteEl = $("searchNote");
      if (noteEl) {
        noteEl.textContent = notes.join(" ");
        noteEl.style.display = notes.length ? "block" : "none";
      }

      // a very busy area can have more places than the list holds: say so instead of implying it is complete
      const capped = data.count >= 100;
      $("searchMeta").textContent = (capped ? "Nearest " : "") + data.count + " result" + (data.count === 1 ? "" : "s") +
        (typed && data.matched_option ? " for " + data.matched_option : "") +
        " within " + data.radius_km + " km of " + (manualLoc ? "the place you typed: " : "your current location: ") + loc.label +
        (data.fallback ? " (quick search - the detailed map server is busy, so some places may be missing)" : "");

      allResults = data.results;
      loc_ = loc;
      const wanted = parseInt(params.get("page"), 10);
      showPage(wanted >= 1 ? wanted : 1, false);

      if (!data.results.length) {
        showStatus(typed
          ? "Nothing matching “" + typed + "” was found in OpenStreetMap near you. Try a different word, " +
            "such as “clinic”, “school” or “bank”."
          : "No " + option.toLowerCase() + " were found in OpenStreetMap near you. Try another option above.");
      }
    }).catch(function (err) {
      showStatus(err.message, err.code === "OUTSIDE_INDIA" ? null : run);   // no "try again": type a place in India instead
    });
  }

  /* ----- pagination: 10 results at a time ----- */
  const PAGE_SIZE = 10;
  let allResults = [];
  let loc_ = null;

  function showPage(page, scroll) {
    const pages = Math.max(1, Math.ceil(allResults.length / PAGE_SIZE));
    page = Math.min(Math.max(page, 1), pages);
    const start = (page - 1) * PAGE_SIZE;
    const slice = allResults.slice(start, start + PAGE_SIZE);

    listEl.innerHTML = "";
    if (markerLayer) markerLayer.clearLayers();
    Object.keys(markersById).forEach(function (k) { delete markersById[k]; });
    slice.forEach(function (r, i) {
      listEl.appendChild(renderCard(r, start + i));
      addMarker(r, start + i);
    });
    checkWebsites(slice);
    if (map && slice.length) {
      const pts = slice.map(function (r) { return [r.lat, r.lng]; });
      if (loc_) pts.push([loc_.lat, loc_.lon]);
      map.fitBounds(pts, { padding: [30, 30], maxZoom: 15 });
    }

    const next = new URLSearchParams(window.location.search);
    if (page > 1) next.set("page", page); else next.delete("page");
    try { history.replaceState(null, "", "search.html?" + next.toString()); } catch (e) { /* ignore */ }

    renderPager(page, pages);
    if (scroll) window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function renderPager(page, pages) {
    const bar = $("pager");
    if (!bar) return;
    bar.innerHTML = "";
    if (pages <= 1) return;
    function button(label, target, disabled, current) {
      const b = el("button", "pg-btn" + (current ? " current" : ""), label);
      b.type = "button";
      b.disabled = !!disabled;
      if (current) b.setAttribute("aria-current", "page");
      b.addEventListener("click", function () { showPage(target, true); });
      bar.appendChild(b);
    }
    button("‹ Previous", page - 1, page === 1);
    for (let p = 1; p <= pages; p++) button(String(p), p, false, p === page);
    button("Next ›", page + 1, page === pages);
    bar.appendChild(el("span", "pg-info", "Showing " + ((page - 1) * PAGE_SIZE + 1) + "–" +
      Math.min(page * PAGE_SIZE, allResults.length) + " of " + allResults.length));
  }

  /* Each card's website is checked before it is shown: does it load, and does it mention this place?
     The same read also finds phone numbers and emails for places that had none. Cards are checked as they
     scroll into view, two at a time, and website reading is free (no search-tool credits are spent). */
  function checkWebsites(results) {
    const byId = {};
    results.forEach(function (r) { byId[r.id] = r; });
    const queue = [];
    let active = 0;

    function finish(card, r, web) {
      const info = card.querySelector(".rc-info");
      const line = info.querySelector(".site-line");
      const check = web.website_check || null;
      const site = safeUrl(web.website || r.website);
      if (line) line.remove();
      if (site && !(check && check.status === "unreachable")) {   // a broken link is never shown
        const li = el("li", "site-line");
        li.appendChild(document.createTextNode("\u{1F310} "));
        const a = el("a", "", new URL(site).hostname.replace(/^www\./, ""));
        a.href = site; a.target = "_blank"; a.rel = "noopener noreferrer";
        li.appendChild(a);
        if (check && check.status === "ok") li.appendChild(el("span", "site-ok", " \u2713"));
        else if (check && check.status === "unmatched") li.appendChild(el("span", "site-warn", " \u26A0 may not be this place\u2019s website"));
        else li.appendChild(el("span", "muted", " (not checked)"));
        info.appendChild(li);
      }
      if (!r.address && web.address) {   // OpenStreetMap has no address: the place's own website does
        r.address = web.address;
        const line = card.querySelector(".addr-line");
        if (line) line.textContent = "\u{1F4CD} " + web.address;
      }
      if (!r.phone && web.phones && web.phones.length) {
        r.phone = web.phones[0];
        info.appendChild(el("li", "from-web", "\u260E " + web.phones.slice(0, 2).join(", ") + " (from website)"));
      }
      if (!r.email && web.emails && web.emails.length) {   // only when OpenStreetMap had none (like phone, above)
        info.appendChild(el("li", "from-web", "\u2709 " + web.emails[0] + " (from website)"));
      }
    }

    function run(card) {
      const r = byId[card.dataset.id];
      return odApiRequest("GET", "resource/web?id=" + encodeURIComponent(r.id) + (safeUrl(r.website) ? "&search=false" : ""))
        .then(function (web) { finish(card, r, web); })
        .catch(function () {   // could not check: leave the site out rather than show an unchecked link
          const line = card.querySelector(".site-line");
          if (line) line.remove();
        });
    }

    function pump() {
      while (active < 2 && queue.length) {
        active++;
        run(queue.shift()).then(function () { active--; pump(); });
      }
    }

    const observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          observer.unobserve(e.target);
          queue.push(e.target);
          pump();
        }
      });
    }, { rootMargin: "300px" });

    document.querySelectorAll(".result-card").forEach(function (card) {
      if (byId[card.dataset.id] && card.querySelector(".site-line")) observer.observe(card);
    });
  }
  odSubscribeMenu(renderChips);  // chips fill in as soon as the location-checked menu is available
  if (!option && !typed) {
    showStatus("Type what you need in the search box, or choose an option from the Browse resources menu.");
  } else {
    run();
  }
})();
