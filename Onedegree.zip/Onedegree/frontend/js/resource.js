/* Resource details page: ?id=node/123
   Shows everything OpenStreetMap knows about one place, a map with only that place,
   and the ratings and comments of our users. All text is set with textContent
   (map data and comments are untrusted). */
(function () {
  const $ = function (id) { return document.getElementById(id); };
  const params = new URLSearchParams(window.location.search);
  const id = (params.get("id") || "").trim();

  if (!odGetUser()) {
    window.location.replace("login.html");
    return;
  }

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = text;
    return n;
  }

  function safeUrl(u) {
    if (!u) return "";
    const withProto = /^https?:\/\//i.test(u) ? u : "https://" + u;
    try {
      const parsed = new URL(withProto);
      return (parsed.protocol === "http:" || parsed.protocol === "https:") ? parsed.href : "";
    } catch (e) { return ""; }
  }

  function showError(message, retry) {
    const box = $("resError");
    box.innerHTML = "";
    if (!message) return;
    box.appendChild(el("p", "", message));
    if (retry) {
      const b = el("button", "retry-btn", "Try again");
      b.type = "button";
      b.addEventListener("click", retry);
      box.appendChild(b);
    }
  }

  if (!/^(node|way|relation)\/\d{1,15}$/.test(id)) {  // an OpenStreetMap id such as node/123
    $("resTitle").textContent = "Resource not found";
    showError("This link is not valid. Go back to the results and open the resource again.");
    return;
  }

  function directionsUrl(res) {
    return "https://www.openstreetmap.org/directions?to=" + res.lat + "%2C" + res.lng;
  }

  /* ---------------------------------------------------------------- state */
  let resource = null;   // merged details: what we know about the place
  let heartBtn = null;
  let map = null;

  function readSnapshot() {
    try { return JSON.parse(sessionStorage.getItem("od_res_" + id)); } catch (e) { return null; }
  }

  /* ---------------------------------------------------------- opening hours */
  /* 12-hour times; "today" and "open now" use the time zone of the place itself (OdHours, in app.js) */
  let placeZone = null;

  function loadZone(res) {
    if (res.lat == null || placeZone !== null) return Promise.resolve();
    return odApiRequest("GET", "timezone?lat=" + res.lat + "&lng=" + res.lng)
      .then(function (z) { placeZone = (z && z.timezone) || ""; renderHours(res); })
      .catch(function () { placeZone = ""; });
  }

  function renderHours(res) {
    const box = $("resHours");
    box.innerHTML = "";
    $("openNow").textContent = "";
    const raw = res.opening_hours || (res.tags && res.tags.opening_hours) || "";
    if (!raw && res.webDone !== true) {   // still looking (website, Google Maps): show that, not "nothing"
      box.appendChild(loadingNode("Looking up the opening hours…"));
      return;
    }
    if (!raw) {
      box.appendChild(el("p", "muted", "Opening hours were not found for this place. Please call to check."));
      return;
    }
    const days = OdHours.parse(raw);
    if (!days) {
      box.appendChild(el("p", "", OdHours.text12(raw)));
      box.appendChild(el("p", "muted", "Shown as listed on OpenStreetMap."));
      return;
    }
    const now = OdHours.nowIn(placeZone);
    const table = el("table", "hours-table");
    OdHours.DAY_NAMES.forEach(function (name, i) {
      const tr = el("tr", i === now.day ? "today" : "");
      tr.appendChild(el("th", "", name));
      tr.appendChild(el("td", days[i] ? "" : "muted", days[i] ? OdHours.show(days[i]) : "Not listed"));
      table.appendChild(tr);
    });
    box.appendChild(table);

    if (placeZone && days.every(function (d) { return d; })) {   // only when the place's own time is known
      const open = OdHours.isOpen(days, now);
      $("openNow").appendChild(el("span", "open-badge " + (open ? "open" : "closed"), open ? "Open now" : "Closed now"));
    }
  }


  function distanceKm(lat1, lon1, lat2, lon2) {
    const rad = Math.PI / 180;
    const a = Math.sin((lat2 - lat1) * rad / 2) ** 2 +
      Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin((lon2 - lon1) * rad / 2) ** 2;
    return 12742 * Math.asin(Math.sqrt(a));
  }

  /* ------------------------------------------------------------ detail rows */
  const LABELS = {
    wheelchair: "Wheelchair access", "toilets:wheelchair": "Accessible toilet", operator: "Operated by",
    brand: "Brand", network: "Network", fee: "Fee", charge: "Charge", capacity: "Capacity",
    level: "Floor / level", cuisine: "Cuisine", "healthcare:speciality": "Speciality",
    internet_access: "Internet access", note: "Note", check_date: "Last checked", start_date: "Open since",
    "opening_hours:note": "Hours note", denomination: "Denomination", religion: "Religion",
    "social_facility:for": "Serves", "payment:cash": "Pays by cash", "payment:cards": "Pays by card"
  };
  // shown elsewhere on the page, so left out of "More information" and "All details"
  const SHOWN = ["name", "name:en", "description", "description:en", "phone", "contact:phone", "email",
    "contact:email", "website", "contact:website", "url", "opening_hours", "facebook", "contact:facebook",
    "instagram", "contact:instagram", "twitter", "contact:twitter", "whatsapp", "contact:whatsapp",
    "fax", "contact:fax"];

  function humanKey(k) {
    if (LABELS[k]) return LABELS[k];
    const s = k.replace(/[:_]+/g, " ").trim();
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  function humanValue(v) {
    const map = { yes: "Yes", no: "No", limited: "Limited", designated: "Yes (designated)" };
    return map[v] || v;
  }

  function addRow(dl, label, valueNode) {
    dl.appendChild(el("dt", "", label));
    const dd = el("dd");
    dd.appendChild(valueNode);
    dl.appendChild(dd);
  }

  function textNode(text) { return document.createTextNode(text); }

  function linkNode(href, text, external) {
    const a = el("a", "", text);
    a.href = href;
    if (external) { a.target = "_blank"; a.rel = "noopener noreferrer"; }
    return a;
  }

  function multi(value) {  // OSM separates several values with ";"
    return String(value).split(";").map(function (s) { return s.trim(); }).filter(Boolean);
  }

  /* a small spinner with a few words, shown while a detail is still being looked up */
  function loadingNode(text) {
    const wrap = el("span", "inline-loading");
    wrap.setAttribute("role", "status");
    wrap.appendChild(el("span", "spinner spinner-sm"));
    wrap.appendChild(el("span", "muted", text));
    return wrap;
  }

  function renderContact(res) {
    const dl = $("resContact");
    dl.innerHTML = "";
    const tags = res.tags || {};
    const pending = res.webDone !== true;   // the website / Google Maps lookup has not finished yet

    const addr = el("span");
    if (!res.address && pending) addr.appendChild(loadingNode("Looking up the address…"));
    else addr.appendChild(textNode(res.address || "Address not listed"));
    if (res.address && res.addressSource) {   // an address OpenStreetMap lacked, read from elsewhere
      const from = /^https?:\/\//.test(res.addressSource) ? "the place’s own website" : res.addressSource;
      addr.appendChild(el("span", "muted small", "  · from " + from));
    }
    if (res.lat != null) {
      addr.appendChild(el("br"));
      addr.appendChild(linkNode(directionsUrl(res), "Get directions", true));
    }
    addRow(dl, "Address", addr);

    const phones = multi(res.phone || tags.phone || tags["contact:phone"] || "");
    if (phones.length) {
      const span = el("span");
      phones.forEach(function (p, i) {
        if (i) span.appendChild(textNode(", "));
        span.appendChild(linkNode("tel:" + p.replace(/[^\d+]/g, ""), p));
      });
      addRow(dl, "Phone", span);
    } else {
      addRow(dl, "Phone", pending ? loadingNode("Looking up…") : el("span", "muted", "Not listed"));
    }

    const emails = multi(res.email || tags.email || tags["contact:email"] || "");
    if (emails.length) {
      const span = el("span");
      emails.forEach(function (m, i) {
        if (i) span.appendChild(textNode(", "));
        span.appendChild(/^[^\s@]+@[^\s@]+$/.test(m) ? linkNode("mailto:" + m, m) : textNode(m));
      });
      addRow(dl, "Email", span);
    } else {
      addRow(dl, "Email", pending ? loadingNode("Looking up…") : el("span", "muted", "Not listed"));
    }

    const site = safeUrl(res.website || tags.website || tags["contact:website"] || tags.url || "");
    const shortSite = site.replace(/^https?:\/\//, "").replace(/\/$/, "");
    const check = res.websiteCheck;
    if (!site) {
      addRow(dl, "Website", pending ? loadingNode("Looking up…") : el("span", "muted", "Not listed"));
    } else if (res.webChecking) {
      addRow(dl, "Website", el("span", "muted", "Checking that the website works..."));
    } else if (check && check.status === "unreachable") {   // a broken link is not shown as a link
      addRow(dl, "Website", el("span", "muted", "The website listed for this place (" + shortSite + ") could not be reached."));
    } else {
      const span = el("span");
      span.appendChild(linkNode(site, shortSite, true));
      if (check && check.status === "ok") span.appendChild(el("span", "site-ok", "  \u2713 checked: it loads"));
      else if (check && check.status === "unmatched") span.appendChild(el("span", "site-warn", "  \u26A0 It loads, but nothing on it mentions this place. It may not be the right website."));
      else if (check && check.status === "blocked") span.appendChild(el("span", "muted", "  (this website does not allow automatic checks)"));
      else span.appendChild(el("span", "muted", "  (not checked)"));
      addRow(dl, "Website", span);
    }

    if (res.listing && res.listing.url && safeUrl(res.listing.url) && !site) {   // no website of its own: a directory page about it
      const span = el("span");
      span.appendChild(linkNode(safeUrl(res.listing.url), "Listed on " + res.listing.host, true));
      span.appendChild(el("span", "muted small", "  (a directory page, not the place’s own website)"));
      addRow(dl, "Listing", span);
    }

    [["facebook", "Facebook"], ["instagram", "Instagram"], ["twitter", "Twitter / X"],
     ["whatsapp", "WhatsApp"], ["fax", "Fax"]].forEach(function (pair) {
      const v = tags[pair[0]] || tags["contact:" + pair[0]];
      if (!v) return;
      const link = /^(facebook|instagram|twitter)$/.test(pair[0]) ? safeUrl(v) : "";
      addRow(dl, pair[1], link ? linkNode(link, v, true) : textNode(v));
    });

    if (res.webRating) {   // only when a rating was actually found (on the place's own site or by a web search)
      const span = el("span");
      span.appendChild(el("span", "stars", odStars(res.webRating.value)));
      span.appendChild(textNode(" " + Number(res.webRating.value).toFixed(1) + " / 5"));
      if (res.webRating.count) {
        span.appendChild(textNode(" (" + res.webRating.count + (res.webRating.count === 1 ? " rating" : " ratings") + ")"));
      }
      span.appendChild(el("span", "muted small", "  · from " + res.webRating.source));
      addRow(dl, "Rating", span);
    }
  }

  function renderMore(res) {
    const tags = res.tags || {};
    const dl = $("resMore");
    dl.innerHTML = "";
    let shownCount = 0;
    Object.keys(LABELS).forEach(function (k) {
      if (tags[k]) { addRow(dl, LABELS[k], textNode(humanValue(tags[k]))); shownCount++; }
    });
    $("secMore").style.display = shownCount ? "block" : "none";

    // every remaining tag, so nothing OpenStreetMap knows about this place is hidden
    const all = $("resAll");
    all.innerHTML = "";
    const rest = Object.keys(tags).filter(function (k) {
      return SHOWN.indexOf(k) === -1 && !LABELS[k] && !/^addr:/.test(k);
    }).sort();
    rest.forEach(function (k) { addRow(all, humanKey(k), textNode(humanValue(tags[k]))); });
    $("secAll").style.display = rest.length ? "block" : "none";
  }

  $("backBtn").addEventListener("click", function (e) {   // works like the browser's Back button
    if (window.history.length > 1) { e.preventDefault(); window.history.back(); }
  });

  /* ----------------------------------------------------------------- page */
  function renderMain(res, basicOnly) {
    document.title = res.name + " | One Degree";
    $("resTitle").textContent = res.name;

    /* the back arrow: the browser's Back button; with no history (page opened from a link) it goes to the
       results list for this kind of place, or the home page */
    let backUrl = "index.html";
    if (res.service) {
      try { backUrl = sessionStorage.getItem("od_back") || ""; } catch (e) { backUrl = ""; }
      if (!/^search\.html\?/.test(backUrl)) {
        backUrl = "search.html?cat=" + encodeURIComponent(res.category || "") + "&tag=" + encodeURIComponent(res.service);
      }
    }
    $("backBtn").href = backUrl;

    const tags = $("resTags");
    tags.innerHTML = "";
    if (res.category) tags.appendChild(el("span", "tag", res.category));
    if (res.service) tags.appendChild(el("span", "tag alt", res.service));

    const description = res.description || (res.tags && (res.tags.description || res.tags["description:en"])) || "";
    $("secAbout").style.display = description ? "block" : "none";
    $("resDescription").textContent = description;

    renderContact(res);
    renderHours(res);
    loadZone(res);
    renderMore(res);

    $("resSource").textContent = res.source ? "Source: " + res.source : "";
    const links = $("resLinks");
    links.innerHTML = "";
    if (res.lat != null) links.appendChild(linkNode(directionsUrl(res), "Get directions", true));
    if (res.osm_url) links.appendChild(linkNode(res.osm_url, "View on OpenStreetMap", true));
    if (!basicOnly && res.osm_url) {
      links.appendChild(linkNode("https://www.openstreetmap.org/edit?" + id.replace("/", "=") ,
        "Fix or add information", true));
    }

    $("resLayout").style.display = "grid";
    drawMap(res);
    drawActions(res);
    if (!basicOnly) loadWebDetails(res);   // after the full OpenStreetMap details are shown
  }

  function drawMap(res) {
    if (map) { map.remove(); map = null; }
    if (typeof L === "undefined" || res.lat == null) return;
    // the mouse wheel scrolls the page over the map (zoom with the + / - buttons); otherwise the map traps
    // the wheel and the right-hand column cannot be scrolled while the pointer is on it
    map = L.map("detailMap", { scrollWheelZoom: false }).setView([res.lat, res.lng], 16);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19, attribution: "&copy; OpenStreetMap contributors"
    }).addTo(map);
    const pop = el("div");
    pop.appendChild(el("strong", "", res.name));
    pop.appendChild(el("div", "", res.address || ""));
    L.circleMarker([res.lat, res.lng], {
      radius: 11, color: "#0f5f6b", fillColor: "#2a8f9d", fillOpacity: 0.95, weight: 3
    }).addTo(map).bindPopup(pop).openPopup();
  }

  function drawActions(res) {
    const box = $("resActions");
    box.innerHTML = "";
    heartBtn = odMakeHeart(res, res.saved);
    heartBtn.classList.add("big");
    const label = el("span", "heart-label", "Save to My Plan");
    heartBtn.addEventListener("click", function () { /* label follows the state below */ });
    box.appendChild(heartBtn);
    box.appendChild(label);
    const sync = function () { label.textContent = heartBtn.classList.contains("saved") ? "Saved to My Plan" : "Save to My Plan"; };
    sync();
    new MutationObserver(sync).observe(heartBtn, { attributes: true, attributeFilter: ["class"] });
  }

  /* ------------------------------------------------- details from the place's own website */
  /* the comments people left on the place's Google Maps listing (text only, set with textContent) */
  function renderGoogleReviews(reviews, source) {
    const section = $("secGReviews");
    const list = $("gReviewList");
    list.innerHTML = "";
    if (!reviews.length) { section.style.display = "none"; return; }
    reviews.forEach(function (r) {
      const item = el("div", "review-item");
      const head = el("div", "review-head");
      head.appendChild(el("span", "stars", odStars(r.rating)));
      head.appendChild(el("strong", "", " " + (r.author || "A Google user")));
      if (r.date) head.appendChild(el("span", "muted", "  " + r.date));
      item.appendChild(head);
      item.appendChild(el("p", "review-text", r.text));
      list.appendChild(item);
    });
    section.querySelector("h2").textContent = "Reviews from " + source;
    section.style.display = "block";
  }

  let webRequestedFor = null;

  function loadWebDetails(res) {
    if (webRequestedFor === res.id) return;
    const tags = res.tags || {};
    const status = $("webStatus");
    webRequestedFor = res.id;
    res.webChecking = !!(res.website || tags.website || tags["contact:website"] || tags.url);
    if (res.webChecking) renderContact(res);   // shows "Checking that the website works..."
    status.textContent = "Looking for this place\u2019s website, phone, email and opening hours...";
    showFormsLoading(res);   // spinner under the map until the forms are known

    odApiRequest("GET", "resource/web?id=" + encodeURIComponent(res.id)).then(function (web) {
      res.websiteCheck = web.website_check || null;
      res.webChecking = false;
      res.webDone = true;   // the lookup finished: anything still missing really is "Not listed"
      const got = [];
      const src = web.sources || {};
      const viaSearch = (web.search && web.search.fields) || [];   // found by a web-search tool, not on the website
      const digits = function (s) { return String(s).replace(/\D/g, ""); };
      const knownPhones = String(res.phone || tags.phone || tags["contact:phone"] || "").split(";")
        .map(digits).filter(Boolean);
      const newPhones = (web.phones || []).filter(function (p) {   // numbers OpenStreetMap does not already have
        return knownPhones.every(function (k) { return digits(p).slice(-9) !== k.slice(-9); });
      });
      if (newPhones.length) {
        res.phone = (String(res.phone || tags.phone || tags["contact:phone"] || "").trim() ?
          String(res.phone || tags.phone || tags["contact:phone"]).trim() + "; " : "") + newPhones.join("; ");
        got.push([(knownPhones.length ? "more phone numbers" : "phone") + (viaSearch.indexOf("phone") >= 0 ? " (web search)" : ""), src.phones]);
      }
      if (!res.email && !tags.email && !tags["contact:email"] && web.emails && web.emails.length) {
        res.email = web.emails.join("; "); got.push(["email" + (viaSearch.indexOf("email") >= 0 ? " (web search)" : ""), src.emails]);
      }
      if (!res.opening_hours && !tags.opening_hours && web.opening_hours) {
        res.opening_hours = web.opening_hours;
        got.push([web.hours_by_ai ? "opening hours (read by an AI model - please confirm)"
                  : "opening hours" + (src.opening_hours === "Google Maps" ? " (Google Maps)" : ""), src.opening_hours]);
      }
      if (!res.website && web.website) {
        res.website = web.website;
        if (viaSearch.indexOf("website") >= 0) got.push(["website (web search)", web.website]);
      }
      if (web.rating) {   // shown as a "Rating" row in the Contact & location box, with where it came from
        res.webRating = { value: web.rating, count: web.rating_count || 0,
                          source: web.rating_source || "the place’s own website" };
      }
      if (web.listing) res.listing = web.listing;
      if (!res.address && !(tags["addr:full"] || tags["addr:street"]) && web.address) {   // OpenStreetMap has none
        res.address = web.address;
        res.addressSource = web.address_source || "the place’s own website";
      }
      renderGoogleReviews(web.reviews || [], web.reviews_source || "Google Maps");
      renderContact(res);
      renderHours(res);

      status.innerHTML = "";
      if (got.length) {
        status.appendChild(document.createTextNode("Found online: "));
        got.forEach(function (g, i) {
          if (i) status.appendChild(document.createTextNode(", "));
          const link = safeUrl(g[1] || "");
          status.appendChild(link ? linkNode(link, g[0], true) : document.createTextNode(g[0]));
        });
        status.appendChild(document.createTextNode("."));
      } else if (web.problem) {
        status.textContent = "Could not read more from the website: " + web.problem + ".";
      } else {
        status.textContent = "The place\u2019s website was read, but it lists nothing more than is shown here.";
      }

      loadAppointmentInfo(res);   // now that the website (OpenStreetMap, Wikidata or search) is known
    }).catch(function () {
      webRequestedFor = null;
      res.webChecking = false;
      res.webDone = true;
      renderContact(res);
      renderHours(res);
      status.textContent = "";
      loadAppointmentInfo(res);
    });
  }

  /* ------------------------------------------------- the form assistant: a real chat, bottom-right */
  const chatBody = $("apptList");
  const composer = $("chatComposer");
  const composerInput = $("chatInput");
  let onComposerSend = null;   // what to do with the text the person types
  let chatRun = 0;             // bumped when a new conversation starts, so a slow answer from an old one is ignored

  function apptSetStep(title, subtitle) {
    $("apptTitle").textContent = title;
    $("apptSubtitle").textContent = subtitle || "";
  }

  function scrollChat() { chatBody.scrollTop = chatBody.scrollHeight; }

  function chatRow(kind) {
    const row = el("div", "msg " + kind);
    if (kind.indexOf("bot") === 0) row.appendChild(el("div", "msg-avatar", "✦"));
    chatBody.appendChild(row);
    return row;
  }

  /* the assistant says something: text, or a list of nodes */
  function botSay(content) {
    const row = chatRow("bot");
    const bubble = el("div", "bubble");
    [].concat(content).forEach(function (part) {
      bubble.appendChild(typeof part === "string" ? document.createTextNode(part) : part);
    });
    row.appendChild(bubble);
    scrollChat();
    return bubble;
  }

  function userSay(text) {
    const row = chatRow("user");
    row.appendChild(el("div", "bubble", text));
    scrollChat();
  }

  /* three bouncing dots while something is being worked out; returns a function that removes them */
  function showTyping() {
    const row = chatRow("bot typing");
    const bubble = el("div", "bubble");
    for (let i = 0; i < 3; i++) bubble.appendChild(el("span", "dot"));
    row.appendChild(bubble);
    scrollChat();
    return function () { if (row.parentNode) row.parentNode.removeChild(row); };
  }

  /* a short pause with the dots, then the message - so it reads like someone answering */
  function botSayLater(content, then) {
    const run = chatRun;
    const stop = showTyping();
    setTimeout(function () {
      stop();
      if (run !== chatRun) return;
      botSay(content);
      if (then) then();
    }, 450);
  }

  /* quick-reply buttons under the last message; picking one shows it as what the person "said" */
  function quickReplies(options) {
    const row = el("div", "chips-row");
    options.forEach(function (opt) {
      const b = el("button", "chip" + (opt.secondary ? " chip-secondary" : ""), opt.label);
      b.type = "button";
      b.addEventListener("click", function () {
        if (row.parentNode) row.parentNode.removeChild(row);
        if (opt.say !== false) userSay(opt.say || opt.label);
        opt.onClick();
      });
      row.appendChild(b);
    });
    chatBody.appendChild(row);
    scrollChat();
  }

  function hideComposer() { composer.style.display = "none"; onComposerSend = null; composerInput.value = ""; }

  /* the message box at the bottom: shown only while the assistant is waiting for typed text */
  function askText(placeholder, type, onSend) {
    composerInput.type = type || "text";
    composerInput.placeholder = placeholder;
    composerInput.value = "";
    onComposerSend = onSend;
    composer.style.display = "flex";
    composerInput.focus();
  }

  composer.addEventListener("submit", function (e) {
    e.preventDefault();
    const text = composerInput.value.trim();
    if (!text || !onComposerSend) return;
    const send = onComposerSend;
    hideComposer();
    userSay(text);
    send(text);
  });

  function closeApptModal() { chatRun++; hideComposer(); closeActiveSession(); $("apptModal").style.display = "none"; }
  $("apptClose").addEventListener("click", closeApptModal);

  function startChat(title, subtitle) {
    chatRun++;
    chatBody.innerHTML = "";
    hideComposer();
    apptSetStep(title, subtitle);
    $("apptModal").style.display = "flex";
  }

  /* a question with the choices as buttons (specialty, doctor...) */
  function apptShowOptions(question, options) {
    botSay(question);
    quickReplies(options.map(function (opt) { return { label: opt.label, onClick: opt.onClick }; }));
  }

  /* Step 1: pick a specialty (skipped entirely if the site only had one generic booking link) */
  function openSpecialtyStep(res, appt) {
    const specialties = (appt.specialties || []).filter(function (s) {
      return s && s.name && (s.url || (s.doctors && s.doctors.length));
    });
    startChat("Book an appointment", "Form assistant");
    apptShowOptions("This place has separate booking pages. Which department are you booking for?",
      specialties.map(function (s) {
        return { label: s.name, onClick: function () { openDoctorStep(res, s); } };
      }));
  }

  /* Step 2: pick a doctor, if the site named individual ones for this specialty (at most 3) */
  function openDoctorStep(res, specialty) {
    const doctors = (specialty.doctors || []).filter(function (d) { return d && d.name; }).slice(0, 3);
    if (!doctors.length) {
      openFormStep(res, specialty.url, specialty.name, true);
      return;
    }
    const options = doctors.map(function (d) {
      return { label: d.name, onClick: function () { openFormStep(res, d.url || specialty.url, specialty.name + " – " + d.name, true); } };
    });
    if (specialty.url) {
      options.push({ label: "Any " + specialty.name + " doctor", onClick: function () { openFormStep(res, specialty.url, specialty.name, true); } });
    }
    apptShowOptions("Do you want a particular doctor in " + specialty.name + "?", options);
  }

  /* Step 3: the form crawler reads the chosen page, then the assistant talks the person through it */
  function openFormStep(res, url, label, continuing) {
    const href = safeUrl(url);
    if (!href) { closeApptModal(); return; }
    if (!continuing) startChat(label || "Form", "Form assistant");
    else apptSetStep(label || "Form", "Form assistant");
    const run = chatRun;
    if (!continuing) userSay("I’d like to fill in: " + (label || "this form"));
    const stop = showTyping();
    const qs = "id=" + encodeURIComponent(res.id) + "&url=" + encodeURIComponent(href) +
      (label ? "&label=" + encodeURIComponent(label) : "");
    odApiRequest("GET", "resource/form-crawl?" + qs)
      .then(function () { return odApiRequest("GET", "resource/form-prefill?" + qs); })
      .then(function (prefill) { stop(); if (run === chatRun) renderFormStep(res, href, label, prefill); })
      .catch(function () { stop(); if (run === chatRun) openManually(href); });   // the crawler failed: still let the person continue
  }

  /* The picture of the page after submitting. Clicking it downloads it (a data address with a file name, so the
     browser saves it straight away instead of trying to open it). */
  function screenshotNode(base64, alt) {
    const href = "data:image/png;base64," + base64;
    const stamp = new Date().toISOString().replace(/[-:]/g, "").replace("T", "-").slice(0, 15);
    const link = document.createElement("a");
    link.href = href;
    link.download = "form-submitted-" + stamp + ".png";
    link.title = "Click to download this picture";
    link.className = "appt-screenshot-link";
    const img = document.createElement("img");
    img.src = href;
    img.className = "appt-screenshot";
    img.alt = alt;
    link.appendChild(img);
    const wrap = document.createElement("div");
    wrap.appendChild(link);
    wrap.appendChild(el("div", "bubble-note", "Click the picture to download it."));
    return wrap;
  }

  const cleanLabel = function (f) { return String(f.label || f.name).replace(/\s*\*+\s*$/, "").trim(); };
  /* things that cannot be done from a chat: solve a captcha, type a code sent to a phone, attach a file, pick a radio button */
  // a one-time code sent to the person's own phone/email is not something to skip - it just cannot be known
  // ahead of time, so it is never asked up front; the chat asks for it once the site has actually sent it
  const isOtpField = function (f) { return /\botp\b|verification code|one[- ]time (code|password|pin)/i.test(f.label || f.name || ""); };
  const doneByHand = function (f) {
    if (isOtpField(f)) return false;
    return (f.type === "file" && /captcha|i am not a robot/i.test(f.label || f.name || "")) ||
      (f.type === "radio" && !(f.options || []).length) ||
      /captcha|i am not a robot/i.test(f.label || f.name || "");
  };
  /* a dropdown whose choices are not in the page yet: they load after an earlier one is chosen (city > hospital > doctor) */
  const isDependent = function (f) { return f.type === "select" && !(f.options || []).length; };
  const norm = function (s) { return String(s || "").toLowerCase().replace(/[*:?\s]+/g, "").replace(/[^a-z0-9]/g, ""); };

  /* Whatever THIS field's own rule is - the form's own wording (title) if it wrote one, else the length it asks
     for, else its own pattern if that is short enough to show as-is. Every field on every form is read on its own
     terms here: one field's rule (10 digits) says nothing about another's (a 12-character ID) on a different form. */
  function ruleHint(f) {
    if (f.title && f.title.trim()) return f.title.trim();
    const min = f.minlength || 0, max = f.maxlength || 0;
    if (min && max && min === max) return "exactly " + min + " characters";
    if (min && max) return "between " + min + " and " + max + " characters";
    if (max) return "up to " + max + " characters";
    if (min) return "at least " + min + " characters";
    if (f.pattern && f.pattern.length <= 40) return "must match: " + f.pattern;
    return "";
  }

  function renderFormStep(res, href, label, prefill) {
    const fields = (prefill.fields || []).filter(function (f) { return f.label || f.name; });
    if (!fields.length) {
      botSay("I opened this page but couldn’t see any questions on it that I can fill in.");
      quickReplies([{ label: "Open the page myself", say: false, onClick: function () { openManually(href); } }]);
      return;
    }
    // a file the person can attach in the chat (a CV, a photo): chosen here, passed to the form once it is open
    const fileFields = fields.filter(function (f) { return f.type === "file" && !doneByHand(f); });
    const files = {};   // field name -> { filename, content_base64 }: kept in this page only, never stored
    // a one-time code: never asked up front (nobody has it yet) and never a blocker either - the chat asks for
    // it, right in the chat, the moment the site actually sends one (see startSubmit/handleResult)
    const fillable = fields.filter(function (f) { return !doneByHand(f) && f.type !== "file" && !isOtpField(f); });
    const manual = fields.filter(function (f) { return doneByHand(f) && f.type !== "file"; }).concat(
      fields.filter(function (f) { return f.type === "file" && doneByHand(f); }));
    const answers = {};   // field name -> what will be typed into it
    const typed = {};     // field name -> what the person themselves typed or chose: kept for next time
    fillable.forEach(function (f) { if (f.value) answers[f.name] = f.value; });
    // dependent dropdowns are asked after the form is open (their choices only exist there)
    const dependent = fillable.filter(isDependent);
    const askable = fillable.filter(function (f) { return !isDependent(f); });
    // Only what the form REQUIRES is gone through, one question at a time; the optional ones are offered at the end.
    // (Some forms mark nothing as required: then every question counts.)
    const requiredList = askable.some(function (f) { return f.required; })
      ? askable.filter(function (f) { return f.required; }) : askable;
    const optionalList = askable.filter(function (f) { return requiredList.indexOf(f) < 0; });

    const lines = function (list) {
      const ul = el("ul", "bubble-list");
      const shown = {};
      list.forEach(function (f) {
        // the same thing twice (two "Name" boxes, or "Your Phone Number" and "Phone" with one answer) is listed once
        const key = (TWIN_KINDS.test(f.kind || "") ? f.kind : norm(cleanLabel(f))) + "|" + norm(answers[f.name]);
        if (shown[key]) return;
        shown[key] = true;
        const li = el("li");
        li.appendChild(el("span", "k", cleanLabel(f) + ": "));
        li.appendChild(document.createTextNode(answers[f.name]));
        ul.appendChild(li);
      });
      return ul;
    };

    botSay("I found the form. I’ll go through what it needs one question at a time – for each one you can accept what I have or change it.");

    /* a question whose answer is one of a list: buttons for a short list, a dropdown inside the chat for a long one.
       onTypeInstead (optional): the list may be wrong or incomplete, so there is always a way to type an answer instead. */
    function pickOne(question, opts, onPick, onTypeInstead) {
      opts = opts.filter(function (o, i) { return opts.indexOf(o) === i && o; });   // each choice once, none blank
      botSay(question);
      if (!opts.length) {   // nothing usable came through: go straight to typing rather than show an empty question
        if (onTypeInstead) onTypeInstead();
        return;
      }
      if (opts.length <= 8) {
        const chips = opts.map(function (o) { return { label: o, onClick: function () { onPick(o); } }; });
        if (onTypeInstead) chips.push({ label: "Type it myself", secondary: true, say: false, onClick: onTypeInstead });
        quickReplies(chips);
        return;
      }
      const select = document.createElement("select");
      select.className = "chat-select";
      const blank = document.createElement("option");
      blank.value = ""; blank.textContent = "Choose…";
      select.appendChild(blank);
      opts.forEach(function (o) { const opt = document.createElement("option"); opt.value = o; opt.textContent = o; select.appendChild(opt); });
      select.addEventListener("change", function () {
        if (!select.value) return;
        const picked = select.value;
        select.disabled = true;
        userSay(picked);
        onPick(picked);
      });
      botSay([select]);
      if (onTypeInstead) quickReplies([{ label: "Type it myself", secondary: true, say: false, onClick: onTypeInstead }]);
    }

    /* asks one question, then calls done() */
    function ask(f, done, errorText, freeOnly) {   // errorText: why the form rejected the earlier value, when re-asking
      // freeOnly: skip the list of earlier answers and go straight to typing a new one
      const name = cleanLabel(f);
      // why we are asking again: the form requires it, or it would not accept what was given
      const why = function (text) {
        return /requires/i.test(text) ? "The form requires “" + name + "”." : "“" + name + "” wasn’t accepted (" + text + ").";
      };
      const store = function (value, fromProfile) {
        answers[f.name] = value;
        if (!fromProfile) typed[f.name] = { label: cleanLabel(f), value: value, type: f.type };
        else delete typed[f.name];
        // the same thing asked twice on the form ("Name" twice, "Your Phone Number" and "Phone"): both get the new answer
        if (TWIN_KINDS.test(f.kind || "")) {
          fillable.forEach(function (x) {
            if (x === f || x.kind !== f.kind || isDependent(x)) return;
            if ((x.options || []).length) {
              // x is its own dropdown/radio: only copy the value in if it is actually one of X's choices -
              // sharing a "kind" does not mean two dropdowns share the same list (a branch's "City" and a
              // correspondence address's "City" are not the same question just because both are cities)
              const match = x.options.filter(function (o) { return String(o).trim().toLowerCase() === String(value).trim().toLowerCase(); })[0];
              if (!match) return;   // not one of its choices: leave it to be asked normally, never silently skipped
              answers[x.name] = match; delete typed[x.name];
              return;
            }
            answers[x.name] = value; delete typed[x.name];
          });
        }
        done();
      };
      const askFree = function () {
        if (f.type === "checkbox") {   // e.g. "I agree to the terms": ticked only if the person says yes here
          botSay("The form asks: “" + name + "”. Do you agree?");
          quickReplies([{ label: "Yes, I agree", onClick: function () { store("yes"); } },
                        { label: "No", secondary: true, onClick: function () {
                            delete answers[f.name];
                            if (f.required) botSay("The form needs this to go ahead, so I can’t submit it without it.");
                            done();
                          } }]);
          return;
        }
        if (f.type !== "checkbox" && (f.options || []).length) {   // any question with choices: show them, whatever HTML tag the site used
          const opts = f.options.filter(function (o) { return !/^(select|choose|--)/i.test(o); });
          pickOne(errorText ? (why(errorText) + " Which one?") : "Which one for “" + name + "”?",
                  opts, function (o) { store(o); }, function () {
                    botSay("What should “" + name + "” be?");
                    askText(name, "text", function (typed) { store(typed); });
                    if (!f.required) quickReplies([{ label: "Skip", secondary: true, onClick: function () { hideComposer(); done(); } }]);
                  });
          return;
        }
        const hint = ruleHint(f);
        botSay((errorText ? (why(errorText) + " What should it be?")
          : f.required ? "What’s the " + name + "?" : "What’s the " + name + "? (optional)")
          + (hint ? " (" + hint + ")" : ""));
        const isDate = f.type === "date" || /^(preferred_date|date_of_birth)$/.test(f.kind || "") || /date/i.test(f.name || "");
        const type = isDate ? "date" : (f.type === "email" || f.type === "tel") ? f.type : "text";
        askText(name, type, store);
        if (!f.required) quickReplies([{ label: "Skip", secondary: true, onClick: function () { hideComposer(); done(); } }]);
      };
      // everything this person has used before for this kind of question (sign-up details and earlier forms)
      const earlier = (f.alternatives || []).filter(Boolean);
      const earlierOptions = function () {
        return earlier.map(function (v) {
          return { label: v === f.suggestion ? "It’s me: " + v : v, onClick: function () { store(v, v === f.suggestion); } };
        });
      };
      if (f.source === "needs_confirmation" && !errorText && !freeOnly) {   // "Student Name", "Parent's Email"...: whose details is it?
        botSay("“" + name + "” could be you or someone else, so I won’t guess." + (earlier.length ? " Pick one you’ve used before, or type a new one." : ""));
        const options = earlierOptions();
        if (f.suggestion && earlier.indexOf(f.suggestion) < 0) options.unshift({ label: "It’s me: " + f.suggestion, onClick: function () { store(f.suggestion, true); } });
        options.push({ label: earlier.length ? "Type a new one" : "Someone else – I’ll type it", secondary: true, onClick: askFree });
        quickReplies(options);
      } else if (earlier.length && !errorText && !freeOnly && f.type !== "checkbox" && !((f.options || []).length)) {
        botSay("Which “" + name + "” should I use?");
        quickReplies(earlierOptions().concat([{ label: "Type a new one", secondary: true, onClick: askFree }]));
      } else {
        askFree();
      }
    }

    /* a file field (CV, photo...): the person picks a file here; it goes to the form once the form is open */
    function askFile(f, done) {
      const name = cleanLabel(f);
      botSay("The form lets you attach a file for “" + name + "” (for example your CV). Would you like to attach one? (PDF, Word or image, up to 5 MB)");
      const input = document.createElement("input");
      input.type = "file";
      input.style.display = "none";
      input.addEventListener("change", function () {
        const file = input.files && input.files[0];
        if (!file) return;
        if (file.size > 5000000) { botSay("That file is over 5 MB. Please pick a smaller one."); return; }
        const reader = new FileReader();
        reader.onload = function () {
          files[f.name] = { filename: file.name, content_base64: String(reader.result).split(",")[1] || "" };
          userSay(file.name);
          done();
        };
        reader.readAsDataURL(file);
      });
      document.body.appendChild(input);
      quickReplies([{ label: "Choose a file", say: false, onClick: function () { input.click(); } },
                    { label: f.required ? "I’ll do it on their page" : "Skip", secondary: true, onClick: function () {
                        if (f.required) { openManually(href); } else { done(); } } }]);
    }

    function filesThenReview() {
      (function nextFile(i) {
        if (i >= fileFields.length) { review(); return; }
        if (files[fileFields[i].name]) { nextFile(i + 1); return; }
        askFile(fileFields[i], function () { nextFile(i + 1); });
      })(0);
    }

    /* the summary, and what to do next */
    function review() {
      const filled = fillable.filter(function (f) { return answers[f.name]; });
      const parts = [filled.length ? "Here’s what I’ll submit:" : "I don’t have anything to fill in yet."];
      if (filled.length) parts.push(lines(filled));
      const attached = fileFields.filter(function (f) { return files[f.name]; });
      if (attached.length) {
        parts.push(el("div", "bubble-note", "Attached: " + attached.map(function (f) {
          return cleanLabel(f) + " – " + files[f.name].filename; }).join("; ")));
      }
      if (dependent.length) {
        parts.push(el("div", "bubble-note", "I’ll ask you for these once the form is open, because their choices depend on the earlier ones: " +
          dependent.map(function (f) { return cleanLabel(f).slice(0, 40); }).join("; ") + "."));
      }
      if (manual.some(function (f) { return f.required; })) {
        parts.push(el("div", "bubble-note", "This form also needs: " +
          manual.filter(function (f) { return f.required; }).map(function (f) { return cleanLabel(f).slice(0, 60); }).join("; ") +
          " – I can’t do that from here."));
      }
      botSay(parts);
      const options = [];
      if (filled.length) options.push({ label: "Submit the form", onClick: startSubmit });
      if (fillable.some(function (f) { return !isDependent(f); })) options.push({ label: "Change an answer", secondary: true, onClick: changeOne });
      options.push({ label: "Open the page myself", secondary: true, say: false, onClick: function () { openManually(href); } });
      quickReplies(options);
    }

    function changeOne() {
      botSay("Which one would you like to change?");
      quickReplies(fillable.filter(function (f) { return !isDependent(f); }).map(function (f) {
        return { label: cleanLabel(f), secondary: true, onClick: function () { ask(f, review); } };
      }));
    }

    /* ---- submitting: the form is opened and filled in a browser window, submitted when the person says so, and
       if the form rejects something the assistant asks for a new value here in the chat and submits again ---- */
    const noMoreHelp = function () {
      quickReplies([{ label: "Open the page myself", secondary: true, say: false, onClick: function () { openManually(href); } },
                    { label: "Close", secondary: true, say: false, onClick: closeApptModal }]);
    };

    function cancelSubmit() {
      closeActiveSession();
      botSay("Okay, I’ve closed the form window. Nothing was submitted.");
      quickReplies([{ label: "Close chat", secondary: true, say: false, onClick: closeApptModal }]);
    }

    /* ask the dropdowns whose choices only exist inside the open form, one after another (city > hospital > doctor) */
    function askDependents(i, then) {
      if (i >= dependent.length) { then(); return; }
      const f = dependent[i];
      const name = cleanLabel(f);
      const run = chatRun;
      const stop = showTyping();
      const setAndNext = function (value) {
        answers[f.name] = value;
        const values = {};
        values[f.name] = value;
        odApiRequest("POST", "resource/form-session/" + activeSession + "/set", { values: values })
          .catch(function () { /* the submit step will report it if it did not take */ })
          .then(function () { askDependents(i + 1, then); });
      };
      // its choices never loaded, or reading them failed: never leave the person with a question and no way to
      // answer it - they can always type it themselves (and skip it if the form does not require it)
      const typeItMyself = function (why) {
        botSay(why + " What should “" + name + "” be?");
        askText(name, "text", setAndNext);
        if (!f.required) quickReplies([{ label: "Skip", secondary: true, onClick: function () { hideComposer(); askDependents(i + 1, then); } }]);
      };
      odApiRequest("POST", "resource/form-session/" + activeSession + "/options", { name: f.name })
        .then(function (r) {
          stop();
          if (run !== chatRun) return;
          const opts = (r && r.options) || [];
          if (!opts.length) { typeItMyself("“" + name + "”’s choices haven’t loaded yet, so I can’t list them."); return; }
          pickOne("Which one for “" + name + "”?", opts, setAndNext,
                  function () { typeItMyself("Okay."); });
        })
        .catch(function () { stop(); if (run !== chatRun) return; typeItMyself("I couldn’t read “" + name + "”’s choices."); });
    }

    /* The form is read again right now and every answer is checked against ITS OWN rules before anything is
       submitted: formats are reshaped silently (dates, phone numbers, the spelling of a choice), and whatever the form
       would reject - or requires and has no answer yet, even a question the first read did not know about - is asked
       here first. So the form is not rejected after submitting. */
    function preflight(round) {
      const run = chatRun;
      const stop = showTyping();
      odApiRequest("POST", "resource/form-session/" + activeSession + "/preflight", { values: answers })
        .then(function (r) {
          stop();
          if (run !== chatRun) return;
          const problems = (r && r.problems) || [];
          if (!problems.length || round >= 3) {
            brokenCaptcha = !!(r && r.captcha_broken);
            if (brokenCaptcha) {   // nobody can tick it: let the person choose between trying anyway and doing it by hand
              botSay("This form has an “I’m not a robot” box that is broken on the place’s own website, so it can’t be ticked here. " +
                "I can fill the form in for you in a browser window, or you can complete it yourself on their page.");
              quickReplies([{ label: "Fill it in for me – I’ll tick and submit", onClick: handOff },
                            { label: "I’ll do it on their page", secondary: true, say: false, onClick: function () { openManually(href); } }]);
              return;
            }
            if (r && r.captcha && !r.captcha_broken) { captchaStep(function () { submit({}); }); return; }
            submit({});
            return;
          }
          botSay("Before I submit, the form needs a little more:");
          askCorrections(problems, function (asked) {
            if (asked === null) { noMoreHelp(); return; }   // a required dropdown that offers no choices: stop here
            preflight(round + 1);
          });
        })
        .catch(function () { stop(); submit({}); });   // the check itself failed: let the form speak for itself
    }

    /* the person finishes the form themselves: it is opened filled in, in a real window, and they tick the captcha and press Submit */
    function handOff() {
      const run = chatRun;
      const stop = showTyping();
      odApiRequest("POST", "resource/form-session/" + activeSession + "/handoff", { values: answers })
        .then(function () {
          stop();
          if (run !== chatRun) return;
          botSay(["I’ve opened the form in a new browser window on this computer, filled in with your answers.",
            el("div", "bubble-note", "Please tick the “I’m not a robot” box in that window and press Submit yourself. " +
              "I can’t see what happens there, so check the place’s reply.")]);
          quickReplies([{ label: "Done", secondary: true, say: false, onClick: closeApptModal }]);
        })
        .catch(function (err) {
          stop();
          if (run !== chatRun) return;
          botSay("I couldn’t open the window (" + err.message + "). You can open the place’s own page instead.");
          quickReplies([{ label: "Open the page myself", say: false, onClick: function () { openManually(href); } }]);
        });
    }

    /* the site's own "I'm not a robot" box is broken (nobody can tick it, on any browser) */
    function captchaBroken() {
      botSay(["This form’s “I’m not a robot” check is broken on the place’s own website (it shows “Invalid domain for site key”), " +
        "so nobody can send this form from any browser right now.",
        el("div", "bubble-note", "Please contact the place directly by phone or email instead" +
          (function () {
            const tg = res.tags || {};
            const bits = [res.phone || tg.phone || tg["contact:phone"], res.email || tg.email || tg["contact:email"]].filter(Boolean);
            return bits.length ? ": " + bits.join(" · ") : "";
          })() + ".")]);
      quickReplies([{ label: "Open the page myself", say: false, onClick: function () { openManually(href); } },
                    { label: "Cancel", secondary: true, say: false, onClick: cancelSubmit }]);
    }

    /* The form has an "I'm not a robot" box. It is never solved for the person: they see the box here and click on
       it themselves; each click is passed on to the real box and a fresh picture comes back. */
    function captchaStep(then) {
      const run = chatRun;
      const holder = el("div", "captcha-box");
      const note = el("div", "bubble-note", "Click on the picture exactly as you would on the page. Any picture puzzle will appear here too.");
      botSay(["The form has an “I’m not a robot” check. Please tick it here:", holder, note]);
      quickReplies([{ label: "I’d rather do it in a browser window", secondary: true, onClick: handOff }]);
      const draw = function (r) {
        holder.textContent = "";
        if (!r || !r.image_base64) return;
        const img = document.createElement("img");
        img.className = "captcha-img";
        img.alt = "The form’s “I’m not a robot” box";
        img.src = "data:image/png;base64," + r.image_base64;
        img.addEventListener("click", function (ev) {
          const box = img.getBoundingClientRect();
          holder.classList.add("busy");
          send({ x: (ev.clientX - box.left) / box.width, y: (ev.clientY - box.top) / box.height });
        });
        holder.appendChild(img);
      };
      const send = function (click) {
        odApiRequest("POST", "resource/form-session/" + activeSession + "/captcha", click || {})
          .then(function (r) {
            if (run !== chatRun) return;
            holder.classList.remove("busy");
            if (r && (r.solved || !r.present)) {
              holder.remove(); note.remove();
              botSay("✅ Thank you – the check is done. Submitting now…");
              then();
              return;
            }
            draw(r);
          })
          .catch(function (err) {
            holder.classList.remove("busy");
            botSay("I couldn’t show the check here, so please do it yourself on the place’s own page: " + err.message);
            quickReplies([{ label: "Open the page myself", say: false, onClick: function () { openManually(href); } }]);
          });
      };
      send(null);
    }

    /* a one-time code the site just sent (to the person's own phone or email, once Submit was pressed): nobody
       but them has it, so it is never guessed or asked for up front - the chat asks for it here, the moment the
       site actually shows an empty box for it, types it in, and presses Submit again on its own */
    function otpStep(r) {
      const run = chatRun;
      const field = r.field || {};
      const name = cleanLabel({ label: field.label, name: field.name });
      const parts = ["The site just sent a one-time code for “" + name + "”. Please check your phone or email and enter it here."];
      if (r.screenshot_base64) parts.push(screenshotNode(r.screenshot_base64, "The page right now"));
      botSay(parts);
      askText(name, "text", function (code) {
        const values = {};
        values[field.name] = code;
        const stop = showTyping();
        odApiRequest("POST", "resource/form-session/" + activeSession + "/set", { values: values })
          .then(function () { stop(); if (run === chatRun) submit({}); })
          .catch(function (err) {
            stop();
            if (run !== chatRun) return;
            botSay("I couldn’t enter the code: " + err.message);
            quickReplies([{ label: "Try again", onClick: function () { otpStep(r); } },
                          { label: "Open the page myself", secondary: true, say: false, onClick: function () { openManually(href); } }]);
          });
      });
    }

    /* asks for a new value for each problem field, one by one, then calls after(true) (after(false) if none can be asked) */
    function askCorrections(errs, after) {
      const items = [];
      errs.forEach(function (e) {
        // the question the form is complaining about: by its name, else by how it is worded
        let f = fillable.filter(function (x) { return x.name === e.name; })[0] ||
                fillable.filter(function (x) { return norm(cleanLabel(x)) === norm(e.label); })[0];
        if (!f && e.field) {   // a question the first read did not know about: it exists on the form as it is now
          f = { name: e.name, label: e.label, type: e.field.type, options: e.field.options || [],
                required: !!e.field.required, kind: e.field.kind, source: "needs_input" };
          fillable.push(f);
        }
        if (f && !items.some(function (m) { return m.f === f; })) items.push({ f: f, message: e.message });
      });
      if (!items.length) { after(false); return; }
      (function askNext(i) {
        if (i >= items.length) { after(true); return; }
        const it = items[i];
        const askIt = function () { ask(it.f, function () { askNext(i + 1); }, it.message); };
        if (it.f.type === "select") {
          // Always read the dropdown's choices fresh here, even if some were already known: the form just
          // rejected this answer, so whatever this question thought its choices were (empty, or a stale list
          // from before the earlier ones were picked) is exactly what cannot be trusted right now.
          const stop = showTyping();
          odApiRequest("POST", "resource/form-session/" + activeSession + "/options", { name: it.f.name })
            .then(function (r) {
              stop();
              const opts = (r && r.options) || [];
              if (opts.length) { it.f.options = opts; askIt(); return; }
              // still nothing to choose from: let the person type it, rather than leave them with no way to answer
              botSay("“" + cleanLabel(it.f) + "”’s choices didn’t load. What should it be?");
              askText(cleanLabel(it.f), "text", function (typed) {
                answers[it.f.name] = typed;
                askNext(i + 1);
              });
              if (!it.f.required) quickReplies([{ label: "Skip", secondary: true, onClick: function () { hideComposer(); askNext(i + 1); } }]);
            })
            .catch(function () { stop(); askIt(); });   // could not even ask: fall back to whatever ask() can do with it
          return;
        }
        askIt();
      })(0);
    }

    function startSubmit() {
      const run = chatRun;
      // a captcha, a code sent to a phone, a file or a radio choice cannot be done from a chat window
      const blockers = manual.filter(function (f) { return f.required; });
      if (blockers.length) {
        botSay("This form needs something I can’t do from here: " +
          blockers.map(function (f) { return cleanLabel(f).slice(0, 60); }).join("; ") +
          ". Please complete it on the place’s own page.");
        noMoreHelp();
        return;
      }
      const saving = saveTypedAnswers(answers, typed);
      rememberValues(fillable, answers);
      botSay("Opening the form and filling it in…");
      const stop = showTyping();
      odApiRequest("POST", "resource/form-session", {
        resource_id: res.id, url: href, label: label, values: answers,
        fields: fields.map(function (f) { return { name: f.name, label: cleanLabel(f), kind: f.kind || null }; })
      })
        .then(function (s) {
          stop();
          if (run !== chatRun) return;
          activeSession = s.session_id;
          saving.then(function (count) { savedCount = count || 0; });
          // the files the person picked go into the open form first (kept in memory only)
          const attach = fileFields.filter(function (f) { return files[f.name]; }).reduce(function (chain, f) {
            return chain.then(function () {
              return odApiRequest("POST", "resource/form-session/" + s.session_id + "/file",
                { name: f.name, filename: files[f.name].filename, content_base64: files[f.name].content_base64 })
                .then(function (r) {
                  if (r && r.status === "error") botSay("I couldn’t attach “" + files[f.name].filename + "”: " + r.message);
                }).catch(function (err) { botSay("I couldn’t attach “" + files[f.name].filename + "”: " + err.message); });
            });
          }, Promise.resolve());
          attach.then(function () { askDependents(0, function () { preflight(0); }); });
        })
        .catch(function (err) {
          stop();
          if (run !== chatRun) return;
          botSay("I couldn’t open the form: " + err.message);
          noMoreHelp();
        });
    }

    let savedCount = 0;
    let brokenCaptcha = false;   // the place's own "I'm not a robot" box is misconfigured (shows an error in the picture)
    let firstSubmit = true;

    function submit(updates) {
      const run = chatRun;
      if (firstSubmit) {
        firstSubmit = false;
        botSay(el("div", "bubble-note", "Some sites answer in a second, others take a while - I’ll keep watching " +
          "and only say it went through once the page itself confirms it, however long that takes."));
      }
      const stop = showTyping();
      odApiRequest("POST", "resource/form-session/" + activeSession + "/submit", { values: updates })
        .then(function (r) { stop(); if (run === chatRun) handleResult(r); })
        .catch(function (err) {
          stop();
          if (run !== chatRun) return;
          botSay("Something went wrong while submitting: " + err.message);
          quickReplies([{ label: "Try again", onClick: function () { submit({}); } },
                        { label: "Open the page myself", secondary: true, say: false, onClick: function () { openManually(href); } }]);
        });
    }

    function handleResult(r) {
      if (r.status === "success") return showSuccess(r);
      if (r.status === "errors") return fixErrors(r);
      if (r.status === "captcha") {
        if (r.broken) { captchaBroken(); return; }
        captchaStep(function () { submit({}); });
        return;
      }
      if (r.status === "otp_required") { otpStep(r); return; }
      if (r.status === "unknown") {
        // waited as long as it reasonably could (up to a few minutes) for the site's own confirmation - none came,
        // so this is never reported as "submitted": the person sees exactly what the page looks like now and decides
        botSay([(r.message || "I pressed Submit, but the page didn’t say whether it went through") + ".",
          el("div", "bubble-note", "You can check on the place’s own page, or try submitting again.")].concat(
          r.screenshot_base64 ? [screenshotNode(r.screenshot_base64, "The page after pressing Submit")] : []));
        quickReplies([{ label: "It went through", onClick: function () { showSuccess({ confirmed: false, screenshot_base64: r.screenshot_base64 }); } },
                      { label: "Submit again", secondary: true, onClick: function () { submit({}); } },
                      { label: "Open the page myself", secondary: true, say: false, onClick: function () { openManually(href); } }]);
        return;
      }
      botSay(r.message || "I couldn’t submit the form.");
      quickReplies([{ label: "Try again", onClick: function () { submit({}); } },
                    { label: "Open the page myself", secondary: true, say: false, onClick: function () { openManually(href); } }]);
    }

    function showSuccess(r) {
      const filled = fillable.filter(function (f) { return answers[f.name]; });
      const unconfirmed = r.confirmed === false;   // the person themselves said it went through - the page never did
      const parts = [(unconfirmed ? "The form was submitted with this data:" : "✅ The form was submitted with this data:"), lines(filled)];
      if (r.screenshot_base64) parts.push(screenshotNode(r.screenshot_base64, "The page after submitting"));
      else if (unconfirmed) parts.push(el("div", "bubble-note", "(no picture of the page was kept from that check)"));
      botSay(parts);
      if (savedCount) botSay("I’ve saved your " + (savedCount === 1 ? "new answer" : savedCount + " new answers") + " so I won’t ask again next time.");
      quickReplies([{ label: "Done", secondary: true, say: false, onClick: closeApptModal }]);
    }

    /* the form rejected something: say what, ask for a new value here, and submit again */
    function fixErrors(r) {
      const errs = r.errors || [];
      const list = el("ul", "bubble-list");
      errs.forEach(function (e) {
        const li = el("li");
        li.appendChild(el("span", "k", String(e.label || e.name).replace(/\s*\*+\s*$/, "") + ": "));
        li.appendChild(document.createTextNode(e.message));
        list.appendChild(li);
      });
      (r.alerts || []).forEach(function (a) { list.appendChild(el("li", "", a)); });
      // what the page itself looks like right now, so it is clear which field the form is complaining about
      botSay(["The form didn’t accept it:", list].concat(r.screenshot_base64 ? [screenshotNode(r.screenshot_base64, "The form after pressing Submit")] : []));

      askCorrections(errs, function (asked) {
        if (!asked) {   // nothing I can ask about (a captcha, a tick box, or a general message)
          botSay("That isn’t something I can correct from here (a captcha, a tick box or a general message from the form).");
          quickReplies([{ label: "Try submitting again", onClick: function () { submit({}); } },
                        { label: "Open the page myself", secondary: true, say: false, onClick: function () { openManually(href); } },
                        { label: "Cancel", secondary: true, say: false, onClick: cancelSubmit }]);
          return;
        }
        submit(answers);   // the corrected answers go back into the form, then it is submitted again
      });
    }
    /* something I already know (from the profile or an earlier answer): shown on its own, to accept or change */
    function confirmKnown(f, done) {
      botSay(["“" + cleanLabel(f) + "”: ", el("strong", "", answers[f.name]), " – shall I use this?"]);
      // with earlier answers to choose from, "Change it" lists them; otherwise it goes straight to typing
      quickReplies([{ label: "Yes, use this", onClick: done },
                    { label: "Change it", secondary: true, onClick: function () { ask(f, done, undefined, (f.alternatives || []).length < 2); } }]);
    }

    // the same thing asked twice on one form ("Your Phone Number" and "Phone"): the first answer is used for both
    const TWIN_KINDS = /^(first_name|last_name|full_name|email|phone|date_of_birth|address|city|state|postal_code|country)$/;

    function next(i) {
      if (i >= requiredList.length) { offerOptional(); return; }
      const f = requiredList[i];
      // a field with its own fixed choices (dropdown/radio/datalist) is never silently skipped by the "twin" shortcut,
      // and never shortcut-confirmed either - it always goes through ask(), which shows those choices as buttons
      const hasOwnChoices = (f.options || []).length > 0;
      const twin = !hasOwnChoices && TWIN_KINDS.test(f.kind || "")
        ? requiredList.slice(0, i).filter(function (x) { return x.kind === f.kind && answers[x.name]; })[0] : null;
      if (twin) { answers[f.name] = answers[twin.name]; delete typed[f.name]; next(i + 1); return; }
      if (answers[f.name]) {
        // several values known for this (the sign-up name and one used on another form): pick one or type a new one
        if (hasOwnChoices || (f.alternatives || []).length > 1) ask(f, function () { next(i + 1); });
        else confirmKnown(f, function () { next(i + 1); });
        return;
      }
      ask(f, function () { next(i + 1); });
    }

    /* the questions the form does not require: offered together, filled only if the person wants */
    function offerOptional() {
      const todo = optionalList.filter(function (f) { return !answers[f.name]; });   // known ones are already filled in
      if (!todo.length) { filesThenReview(); return; }
      botSay("There " + (todo.length === 1 ? "is 1 optional question" : "are " + todo.length + " optional questions") + ": " +
        todo.map(function (f) { return cleanLabel(f).slice(0, 40); }).join(", ") + ". Do you want to fill " +
        (todo.length === 1 ? "it" : "them") + " in?");
      quickReplies([{ label: "No, skip " + (todo.length === 1 ? "it" : "them"), onClick: filesThenReview },
                    { label: "Yes, let’s do it", secondary: true, onClick: function () {
                        (function askOptional(i) {
                          if (i >= todo.length) { filesThenReview(); return; }
                          ask(todo[i], function () { askOptional(i + 1); });
                        })(0);
                      } }]);
    }
    next(0);
  }

  /* the extra answers the person gave in the chat go to their saved answers (table user_attributes), so the
     same question is not asked again. Their sign-up details are never changed by this. */
  function saveTypedAnswers(values, typed) {
    const items = Object.keys(typed || {}).filter(function (name) { return values[name] === typed[name].value; })
      .map(function (name) { return { label: typed[name].label, value: typed[name].value, type: typed[name].type || null }; });
    if (!items.length) return Promise.resolve(0);
    return odApiRequest("POST", "profile/attributes", { items: items })
      .then(function (r) { return (r && r.saved) || 0; })
      .catch(function () { return 0; });   // saving is a bonus: never block the form on it
  }

  /* every name, phone, email... used on the form is remembered (table user_field_values), so the next form can offer
     them all to pick from. Sensitive answers are never sent; the server refuses them too. */
  function rememberValues(fields, values) {
    const seen = {};
    const items = [];
    fields.forEach(function (f) {
      const v = String(values[f.name] || "").trim();
      if (!v || f.type === "checkbox" || f.type === "file") return;
      const key = (f.kind || "") + "|" + String(f.label || f.name) + "|" + v.toLowerCase();
      if (seen[key]) return;
      seen[key] = true;
      // the server decides what it is about (by the field's kind and wording) and refuses what must not be kept
      items.push({ kind: f.kind || null, label: String(f.label || f.name || ""), name: String(f.name || ""),
                   type: String(f.type || ""), value: v });
    });
    if (!items.length) return;
    odApiRequest("POST", "profile/field-values", { items: items }).catch(function () { /* saving is a bonus */ });
  }

  /* the browser window kept open for the form being submitted; closed with the chat */
  let activeSession = null;
  function closeActiveSession() {
    if (!activeSession) return;
    const id = activeSession;
    activeSession = null;
    odApiRequest("DELETE", "resource/form-session/" + id).catch(function () { /* already gone */ });
  }

  function openManually(href) {
    window.open(href, "_blank", "noopener,noreferrer");
    closeApptModal();
  }

  /* One button per web form the site crawler found on the place's website */
  function renderForms(res, appt) {
    const box = $("resBook");
    const forms = (appt.forms || []).filter(function (f) { return f && safeUrl(f.url); });
    if (appt.status === "unreachable" || appt.status === "blocked") return;
    if (!forms.length) {
      box.appendChild(el("p", "muted small", "No forms were found on this website."));
      return;
    }
    box.appendChild(el("h3", "res-forms-title", "Forms on this website (" + forms.length + ")"));
    const typeCount = {};   // how many forms of each type, to number repeats: "Contact form (2)"
    forms.forEach(function (f) { const t = f.type || "Form"; typeCount[t] = (typeCount[t] || 0) + 1; });
    const typeSeen = {};
    forms.forEach(function (f) {
      const type = f.type || "Form";
      typeSeen[type] = (typeSeen[type] || 0) + 1;
      const name = typeCount[type] > 1 ? type + " (" + typeSeen[type] + ")" : type;   // button = what kind of form it is
      const btn = el("button", "book-appt-btn form-btn", name);
      btn.type = "button";
      btn.title = f.label || name;
      f = Object.assign({}, f, { label: name });
      btn.addEventListener("click", function () { openFormStep(res, f.url, f.label); });
      box.appendChild(btn);
    });
  }

  function renderBook(res, appt) {
    const box = $("resBook");
    box.innerHTML = "";
    if (!appt || appt.status === "no_website") {
      box.style.display = "none";   // nothing to check: no website is known for this place
      return;
    }
    box.style.display = "block";
    box.appendChild(el("h2", "res-book-title", bookTitle(appt.appointments_checked)));
    renderForms(res, appt);
    // Is the booking page the same thing as a form already listed above (same address, or an "Appointment form")?
    // Then it is not shown a second time as a separate "Book Appointment" button.
    const sameUrl = function (a, b) {
      const clean = function (u) { return String(u || "").replace(/[#?].*$/, "").replace(/\/+$/, "").replace(/^https?:\/\/(www\.)?/, "").toLowerCase(); };
      return !!a && !!b && clean(a) === clean(b);
    };
    const listed = (appt.forms || []).filter(function (f) { return f && safeUrl(f.url); });
    const alreadyListed = listed.some(function (f) {
      return /appointment|booking/i.test(f.type || "") || sameUrl(f.url, appt.appointment_url);
    });
    if (appt.has_appointment && alreadyListed) {
      /* the appointment form is one of the buttons above */
    } else if (appt.has_appointment) {
      const btn = el("button", "book-appt-btn", "Book Appointment");
      btn.type = "button";
      btn.addEventListener("click", function () {
        const specialties = (appt.specialties || []).filter(function (s) {
          return s && s.name && (s.url || (s.doctors && s.doctors.length));
        });
        if (specialties.length) {
          openSpecialtyStep(res, appt);
        } else {
          openFormStep(res, appt.appointment_url, null);
        }
      });
      box.appendChild(el("h3", "res-forms-title res-book-gap", "Book an appointment"));
      box.appendChild(btn);
    } else if (!appt.appointments_checked) {
      /* not a healthcare place: appointment booking does not apply, so only the forms above are shown */
    } else if (appt.status === "unreachable" || appt.status === "blocked") {
      box.appendChild(el("p", "muted small", "This website could not be checked for online appointment booking."));
    } else {
      box.appendChild(el("p", "muted small", "No online appointment booking was found on this website."));
    }
  }

  let apptRequestedFor = null;

  function bookTitle(withAppointments) { return withAppointments ? "Forms & appointments" : "Forms"; }

  function showFormsLoading(res) {
    const box = $("resBook");
    box.style.display = "block";
    box.innerHTML = "";
    box.appendChild(el("h2", "res-book-title", bookTitle(res && res.category === "Healthcare")));
    const row = el("div", "forms-loading");
    row.setAttribute("role", "status");
    row.appendChild(el("span", "spinner"));
    row.appendChild(el("span", "muted small", "Looking for forms on this website... this can take a little while."));
    box.appendChild(row);
  }

  function loadAppointmentInfo(res) {
    if (apptRequestedFor === res.id) return;
    apptRequestedFor = res.id;
    showFormsLoading(res);
    odApiRequest("GET", "resource/site-crawl?id=" + encodeURIComponent(res.id))
      .then(function (appt) { renderBook(res, appt); })
      .catch(function (err) {
        apptRequestedFor = null;
        const box = $("resBook");
        box.innerHTML = "";
        box.appendChild(el("h2", "res-book-title", bookTitle(res.category === "Healthcare")));
        box.appendChild(el("p", "muted small", "Could not check for online appointment booking: " + err.message));
      });
  }

  /* ------------------------------------------- saved state and the header rating (no review box on the page) */
  function renderReviews(payload) {
    resource.saved = payload.saved;
    if (heartBtn) heartBtn.setSaved(payload.saved);
  }

  function loadReviews() {
    return odApiRequest("GET", "resource/reviews?id=" + encodeURIComponent(id)).then(renderReviews)
      .catch(function () { /* the heart and rating simply stay as they were */ });
  }

  /* ----------------------------------------------------------------- load */
  function load() {
    showError("");
    const snapshot = readSnapshot();
    if (snapshot) {  // paint at once with what the results list already knew
      resource = Object.assign({ tags: {} }, snapshot);
      renderMain(resource, true);
    } else {
      $("resTitle").textContent = "Loading...";
    }

    const reviewsDone = loadReviews();
    odApiRequest("GET", "resource?id=" + encodeURIComponent(id)).then(function (full) {
      // the full details win; keep the saved/rating state we already know
      resource = Object.assign({}, snapshot || {}, full, { saved: resource ? resource.saved : false });
      $("resNotice").style.display = "none";
      renderMain(resource, false);
      return reviewsDone.then(function () { if (heartBtn) heartBtn.setSaved(resource.saved); });
    }).catch(function (err) {
      if (snapshot) {
        const note = $("resNotice");
        note.textContent = "Showing the basic details we already have. The full details could not be loaded right now. ";
        const b = el("button", "link-btn", "Try again");
        b.type = "button";
        b.addEventListener("click", load);
        note.appendChild(b);
        note.style.display = "block";
        resource.webDone = true;   // nothing more is coming: stop the loading spinners
        renderContact(resource);
        renderHours(resource);
      } else {
        $("resTitle").textContent = "Resource not available";
        showError(err.message, load);
      }
    });
  }

  load();
})();
